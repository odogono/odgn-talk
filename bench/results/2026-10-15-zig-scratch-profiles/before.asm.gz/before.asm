000000010000ac94 <_heap.ArenaAllocator.reset>:
10000ac94: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10000ac98: a9015ff8    	stp	x24, x23, [sp, #0x10]
10000ac9c: a90257f6    	stp	x22, x21, [sp, #0x20]
10000aca0: a9034ff4    	stp	x20, x19, [sp, #0x30]
10000aca4: a9047bfd    	stp	x29, x30, [sp, #0x40]
10000aca8: 910103fd    	add	x29, sp, #0x40
10000acac: aa1e03f4    	mov	x20, x30
10000acb0: aa0003f3    	mov	x19, x0
10000acb4: f9400801    	ldr	x1, [x0, #0x10]
10000acb8: b40003a1    	cbz	x1, 0x10000ad2c <_heap.ArenaAllocator.reset+0x98>
10000acbc: d2800008    	mov	x8, #0x0                ; =0
10000acc0: aa0103e9    	mov	x9, x1
10000acc4: f940012a    	ldr	x10, [x9]
10000acc8: 927ff94a    	and	x10, x10, #0xfffffffffffffffe
10000accc: f100614a    	subs	x10, x10, #0x18
10000acd0: 540011c3    	b.lo	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000acd4: ab0a0108    	adds	x8, x8, x10
10000acd8: 54001182    	b.hs	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000acdc: f9400929    	ldr	x9, [x9, #0x10]
10000ace0: b5ffff29    	cbnz	x9, 0x10000acc4 <_heap.ArenaAllocator.reset+0x30>
10000ace4: b1006116    	adds	x22, x8, #0x18
10000ace8: 1a9f37f7    	cset	w23, hs
10000acec: f9400e68    	ldr	x8, [x19, #0x18]
10000acf0: b4000268    	cbz	x8, 0x10000ad3c <_heap.ArenaAllocator.reset+0xa8>
10000acf4: d2800009    	mov	x9, #0x0                ; =0
10000acf8: f940010a    	ldr	x10, [x8]
10000acfc: 927ff94a    	and	x10, x10, #0xfffffffffffffffe
10000ad00: f100614a    	subs	x10, x10, #0x18
10000ad04: 54001023    	b.lo	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad08: ab0a0129    	adds	x9, x9, x10
10000ad0c: 54000fe2    	b.hs	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad10: f9400908    	ldr	x8, [x8, #0x10]
10000ad14: b5ffff28    	cbnz	x8, 0x10000acf8 <_heap.ArenaAllocator.reset+0x64>
10000ad18: b1006138    	adds	x24, x9, #0x18
10000ad1c: 1a9f37f9    	cset	w25, hs
10000ad20: dac143f4    	xpaci	x20
10000ad24: b5000141    	cbnz	x1, 0x10000ad4c <_heap.ArenaAllocator.reset+0xb8>
10000ad28: 1400004a    	b	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ad2c: 52800017    	mov	w23, #0x0               ; =0
10000ad30: 52800316    	mov	w22, #0x18              ; =24
10000ad34: f9400e68    	ldr	x8, [x19, #0x18]
10000ad38: b5fffde8    	cbnz	x8, 0x10000acf4 <_heap.ArenaAllocator.reset+0x60>
10000ad3c: 52800019    	mov	w25, #0x0               ; =0
10000ad40: 52800318    	mov	w24, #0x18              ; =24
10000ad44: dac143f4    	xpaci	x20
10000ad48: b4000841    	cbz	x1, 0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ad4c: f9400828    	ldr	x8, [x1, #0x10]
10000ad50: b40001c8    	cbz	x8, 0x10000ad88 <_heap.ArenaAllocator.reset+0xf4>
10000ad54: aa0803f5    	mov	x21, x8
10000ad58: a9402260    	ldp	x0, x8, [x19]
10000ad5c: f9400029    	ldr	x9, [x1]
10000ad60: f9400d08    	ldr	x8, [x8, #0x18]
10000ad64: 927ff922    	and	x2, x9, #0xfffffffffffffffe
10000ad68: 52800063    	mov	w3, #0x3                ; =3
10000ad6c: aa1403e4    	mov	x4, x20
10000ad70: d63f0100    	blr	x8
10000ad74: f9400aa8    	ldr	x8, [x21, #0x10]
10000ad78: aa1503e1    	mov	x1, x21
10000ad7c: b5fffec8    	cbnz	x8, 0x10000ad54 <_heap.ArenaAllocator.reset+0xc0>
10000ad80: 36000097    	tbz	w23, #0x0, 0x10000ad90 <_heap.ArenaAllocator.reset+0xfc>
10000ad84: 14000061    	b	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad88: aa0103f5    	mov	x21, x1
10000ad8c: 37000bf7    	tbnz	w23, #0x0, 0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad90: f94002a8    	ldr	x8, [x21]
10000ad94: 927ff902    	and	x2, x8, #0xfffffffffffffffe
10000ad98: 927ffad6    	and	x22, x22, #0xfffffffffffffffe
10000ad9c: f10062df    	cmp	x22, #0x18
10000ada0: 54000121    	b.ne	0x10000adc4 <_heap.ArenaAllocator.reset+0x130>
10000ada4: a9402260    	ldp	x0, x8, [x19]
10000ada8: f9400d08    	ldr	x8, [x8, #0x18]
10000adac: aa1503e1    	mov	x1, x21
10000adb0: 52800063    	mov	w3, #0x3                ; =3
10000adb4: aa1403e4    	mov	x4, x20
10000adb8: d63f0100    	blr	x8
10000adbc: f9000a7f    	str	xzr, [x19, #0x10]
10000adc0: 14000024    	b	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000adc4: f90006bf    	str	xzr, [x21, #0x8]
10000adc8: f9000a75    	str	x21, [x19, #0x10]
10000adcc: eb16005f    	cmp	x2, x22
10000add0: 54000400    	b.eq	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000add4: a9402260    	ldp	x0, x8, [x19]
10000add8: f9400508    	ldr	x8, [x8, #0x8]
10000addc: aa1503e1    	mov	x1, x21
10000ade0: aa0203fa    	mov	x26, x2
10000ade4: 52800063    	mov	w3, #0x3                ; =3
10000ade8: aa1603e4    	mov	x4, x22
10000adec: aa1403e5    	mov	x5, x20
10000adf0: d63f0100    	blr	x8
10000adf4: 36000060    	tbz	w0, #0x0, 0x10000ae00 <_heap.ArenaAllocator.reset+0x16c>
10000adf8: f90002b6    	str	x22, [x21]
10000adfc: 14000015    	b	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ae00: a9402260    	ldp	x0, x8, [x19]
10000ae04: f9400108    	ldr	x8, [x8]
10000ae08: aa1603e1    	mov	x1, x22
10000ae0c: 52800062    	mov	w2, #0x3                ; =3
10000ae10: aa1403e3    	mov	x3, x20
10000ae14: d63f0100    	blr	x8
10000ae18: b40001c0    	cbz	x0, 0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ae1c: aa0003f7    	mov	x23, x0
10000ae20: aa1a03e2    	mov	x2, x26
10000ae24: a9402260    	ldp	x0, x8, [x19]
10000ae28: f9400d08    	ldr	x8, [x8, #0x18]
10000ae2c: aa1503e1    	mov	x1, x21
10000ae30: 52800063    	mov	w3, #0x3                ; =3
10000ae34: aa1403e4    	mov	x4, x20
10000ae38: d63f0100    	blr	x8
10000ae3c: f2400aff    	tst	x23, #0x7
10000ae40: 540009a1    	b.ne	0x10000af74 <_heap.ArenaAllocator.reset+0x2e0>
10000ae44: a900feff    	stp	xzr, xzr, [x23, #0x8]
10000ae48: f90002f6    	str	x22, [x23]
10000ae4c: f9000a77    	str	x23, [x19, #0x10]
10000ae50: f9400e61    	ldr	x1, [x19, #0x18]
10000ae54: b4000841    	cbz	x1, 0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000ae58: f9400828    	ldr	x8, [x1, #0x10]
10000ae5c: b4000528    	cbz	x8, 0x10000af00 <_heap.ArenaAllocator.reset+0x26c>
10000ae60: aa0803f5    	mov	x21, x8
10000ae64: a9402260    	ldp	x0, x8, [x19]
10000ae68: f9400029    	ldr	x9, [x1]
10000ae6c: f9400d08    	ldr	x8, [x8, #0x18]
10000ae70: 927ff922    	and	x2, x9, #0xfffffffffffffffe
10000ae74: 52800063    	mov	w3, #0x3                ; =3
10000ae78: aa1403e4    	mov	x4, x20
10000ae7c: d63f0100    	blr	x8
10000ae80: f9400aa8    	ldr	x8, [x21, #0x10]
10000ae84: aa1503e1    	mov	x1, x21
10000ae88: b5fffec8    	cbnz	x8, 0x10000ae60 <_heap.ArenaAllocator.reset+0x1cc>
10000ae8c: 370003f9    	tbnz	w25, #0x0, 0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ae90: f94002a8    	ldr	x8, [x21]
10000ae94: 927ff902    	and	x2, x8, #0xfffffffffffffffe
10000ae98: 927ffb16    	and	x22, x24, #0xfffffffffffffffe
10000ae9c: f10062df    	cmp	x22, #0x18
10000aea0: 54000121    	b.ne	0x10000aec4 <_heap.ArenaAllocator.reset+0x230>
10000aea4: a9402260    	ldp	x0, x8, [x19]
10000aea8: f9400d08    	ldr	x8, [x8, #0x18]
10000aeac: aa1503e1    	mov	x1, x21
10000aeb0: 52800063    	mov	w3, #0x3                ; =3
10000aeb4: aa1403e4    	mov	x4, x20
10000aeb8: d63f0100    	blr	x8
10000aebc: f9000e7f    	str	xzr, [x19, #0x18]
10000aec0: 14000027    	b	0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000aec4: f90006bf    	str	xzr, [x21, #0x8]
10000aec8: f9000e75    	str	x21, [x19, #0x18]
10000aecc: eb16005f    	cmp	x2, x22
10000aed0: 54000460    	b.eq	0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000aed4: a9402260    	ldp	x0, x8, [x19]
10000aed8: f9400508    	ldr	x8, [x8, #0x8]
10000aedc: aa1503e1    	mov	x1, x21
10000aee0: aa0203f8    	mov	x24, x2
10000aee4: 52800063    	mov	w3, #0x3                ; =3
10000aee8: aa1603e4    	mov	x4, x22
10000aeec: aa1403e5    	mov	x5, x20
10000aef0: d63f0100    	blr	x8
10000aef4: 360000c0    	tbz	w0, #0x0, 0x10000af0c <_heap.ArenaAllocator.reset+0x278>
10000aef8: f90002b6    	str	x22, [x21]
10000aefc: 14000018    	b	0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000af00: aa0103f5    	mov	x21, x1
10000af04: 3607fc79    	tbz	w25, #0x0, 0x10000ae90 <_heap.ArenaAllocator.reset+0x1fc>
10000af08: 9407a8e5    	bl	0x1001f529c <_debug.FullPanic((function 'defaultPanic')).integerOverflow>
10000af0c: a9402260    	ldp	x0, x8, [x19]
10000af10: f9400108    	ldr	x8, [x8]
10000af14: aa1603e1    	mov	x1, x22
10000af18: 52800062    	mov	w2, #0x3                ; =3
10000af1c: aa1403e3    	mov	x3, x20
10000af20: d63f0100    	blr	x8
10000af24: b40001c0    	cbz	x0, 0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000af28: aa0003f7    	mov	x23, x0
10000af2c: aa1803e2    	mov	x2, x24
10000af30: a9402260    	ldp	x0, x8, [x19]
10000af34: f9400d08    	ldr	x8, [x8, #0x18]
10000af38: aa1503e1    	mov	x1, x21
10000af3c: 52800063    	mov	w3, #0x3                ; =3
10000af40: aa1403e4    	mov	x4, x20
10000af44: d63f0100    	blr	x8
10000af48: f2400aff    	tst	x23, #0x7
10000af4c: 54000141    	b.ne	0x10000af74 <_heap.ArenaAllocator.reset+0x2e0>
10000af50: a900feff    	stp	xzr, xzr, [x23, #0x8]
10000af54: f90002f6    	str	x22, [x23]
10000af58: f9000e77    	str	x23, [x19, #0x18]
10000af5c: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10000af60: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10000af64: a94257f6    	ldp	x22, x21, [sp, #0x20]
10000af68: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10000af6c: a8c567fa    	ldp	x26, x25, [sp], #0x50
10000af70: d65f03c0    	ret
10000af74: 9407925b    	bl	0x1001ef8e0 <_debug.FullPanic((function 'defaultPanic')).incorrectAlignment>

00000001000b8a40 <_machine.machine.Group.execute>:
1000b8a40: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1000b8a44: a90167fa    	stp	x26, x25, [sp, #0x10]
1000b8a48: a9025ff8    	stp	x24, x23, [sp, #0x20]
1000b8a4c: a90357f6    	stp	x22, x21, [sp, #0x30]
1000b8a50: a9044ff4    	stp	x20, x19, [sp, #0x40]
1000b8a54: a9057bfd    	stp	x29, x30, [sp, #0x50]
1000b8a58: 910143fd    	add	x29, sp, #0x50
1000b8a5c: d13443ff    	sub	sp, sp, #0xd10
1000b8a60: f90017fe    	str	x30, [sp, #0x28]
1000b8a64: b9005fe3    	str	w3, [sp, #0x5c]
1000b8a68: aa0203f6    	mov	x22, x2
1000b8a6c: aa0103f5    	mov	x21, x1
1000b8a70: f9000fe0    	str	x0, [sp, #0x18]
1000b8a74: d0000f88    	adrp	x8, 0x1002aa000 <___anon_158745+0x70>
1000b8a78: f9409508    	ldr	x8, [x8, #0x128]
1000b8a7c: f9400108    	ldr	x8, [x8]
1000b8a80: f81983a8    	stur	x8, [x29, #-0x68]
1000b8a84: d0000ae1    	adrp	x1, 0x100216000 <___anon_77823+0x8>
1000b8a88: 911b0021    	add	x1, x1, #0x6c0
1000b8a8c: 911003e0    	add	x0, sp, #0x400
1000b8a90: 52803402    	mov	w2, #0x1a0              ; =416
1000b8a94: 94051674    	bl	0x1001fe464 <_writev+0x1001fe464>
1000b8a98: 910742a0    	add	x0, x21, #0x1d0
1000b8a9c: 97fd487e    	bl	0x10000ac94 <_heap.ArenaAllocator.reset>
1000b8aa0: a95fa6c8    	ldp	x8, x9, [x22, #0x1f8]
1000b8aa4: ab090108    	adds	x8, x8, x9
1000b8aa8: 54012122    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8aac: 911b83e9    	add	x9, sp, #0x6e0
1000b8ab0: 91008129    	add	x9, x9, #0x20
1000b8ab4: f90023e9    	str	x9, [sp, #0x40]
1000b8ab8: 911d23e9    	add	x9, sp, #0x748
1000b8abc: 91008129    	add	x9, x9, #0x20
1000b8ac0: f9000be9    	str	x9, [sp, #0x10]
1000b8ac4: b9405fe9    	ldr	w9, [sp, #0x5c]
1000b8ac8: 52000129    	eor	w9, w9, #0x1
1000b8acc: b90027e9    	str	w9, [sp, #0x24]
1000b8ad0: 1400000a    	b	0x1000b8af8 <_machine.machine.Group.execute+0xb8>
1000b8ad4: 52800208    	mov	w8, #0x10               ; =16
1000b8ad8: f902c3e8    	str	x8, [sp, #0x580]
1000b8adc: 911003e8    	add	x8, sp, #0x400
1000b8ae0: a918fd1f    	stp	xzr, xzr, [x8, #0x188]
1000b8ae4: 910742a0    	add	x0, x21, #0x1d0
1000b8ae8: 97fd486b    	bl	0x10000ac94 <_heap.ArenaAllocator.reset>
1000b8aec: a95fa6c8    	ldp	x8, x9, [x22, #0x1f8]
1000b8af0: ab090108    	adds	x8, x8, x9
1000b8af4: 54011ec2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8af8: a91ffec8    	stp	x8, xzr, [x22, #0x1f8]
1000b8afc: f9404ec1    	ldr	x1, [x22, #0x98]
1000b8b00: f1000420    	subs	x0, x1, #0x1
1000b8b04: 54011e43    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8b08: eb01001f    	cmp	x0, x1
1000b8b0c: 54011f22    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b8b10: f9404ac8    	ldr	x8, [x22, #0x90]
1000b8b14: 52800909    	mov	w9, #0x48               ; =72
1000b8b18: 9b092014    	madd	x20, x0, x9, x8
1000b8b1c: b9403e9b    	ldr	w27, [x20, #0x3c]
1000b8b20: 3955d2c8    	ldrb	w8, [x22, #0x574]
1000b8b24: 360000c8    	tbz	w8, #0x0, 0x1000b8b3c <_machine.machine.Group.execute+0xfc>
1000b8b28: f100043f    	cmp	x1, #0x1
1000b8b2c: 54000081    	b.ne	0x1000b8b3c <_machine.machine.Group.execute+0xfc>
1000b8b30: b94572c8    	ldr	w8, [x22, #0x570]
1000b8b34: 6b08037f    	cmp	w27, w8
1000b8b38: 540098a0    	b.eq	0x1000b9e4c <_machine.machine.Group.execute+0x140c>
1000b8b3c: f90262bf    	str	xzr, [x21, #0x4c0]
1000b8b40: 395402a8    	ldrb	w8, [x21, #0x500]
1000b8b44: 36000148    	tbz	w8, #0x0, 0x1000b8b6c <_machine.machine.Group.execute+0x12c>
1000b8b48: f940e6a0    	ldr	x0, [x21, #0x1c8]
1000b8b4c: b4000100    	cbz	x0, 0x1000b8b6c <_machine.machine.Group.execute+0x12c>
1000b8b50: f9427aa2    	ldr	x2, [x21, #0x4f0]
1000b8b54: f94276a1    	ldr	x1, [x21, #0x4e8]
1000b8b58: eb01005f    	cmp	x2, x1
1000b8b5c: 54011d88    	b.hi	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000b8b60: f94272a1    	ldr	x1, [x21, #0x4e0]
1000b8b64: 97fd2397    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b8b68: f9027abf    	str	xzr, [x21, #0x4f0]
1000b8b6c: f9428aa9    	ldr	x9, [x21, #0x510]
1000b8b70: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b8b74: b4000189    	cbz	x9, 0x1000b8ba4 <_machine.machine.Group.execute+0x164>
1000b8b78: b5000408    	cbnz	x8, 0x1000b8bf8 <_machine.machine.Group.execute+0x1b8>
1000b8b7c: f94242c8    	ldr	x8, [x22, #0x480]
1000b8b80: b4000148    	cbz	x8, 0x1000b8ba8 <_machine.machine.Group.execute+0x168>
1000b8b84: aa1503e0    	mov	x0, x21
1000b8b88: aa1603e1    	mov	x1, x22
1000b8b8c: 97ffa40f    	bl	0x1000a1bc8 <_machine.machine.Group.land>
1000b8b90: 72003c1f    	tst	w0, #0xffff
1000b8b94: 54010961    	b.ne	0x1000bacc0 <_machine.machine.Group.execute+0x2280>
1000b8b98: 3946a2c8    	ldrb	w8, [x22, #0x1a8]
1000b8b9c: 3700a7a8    	tbnz	w8, #0x0, 0x1000ba090 <_machine.machine.Group.execute+0x1650>
1000b8ba0: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b8ba4: b50002a8    	cbnz	x8, 0x1000b8bf8 <_machine.machine.Group.execute+0x1b8>
1000b8ba8: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b8bac: f9422ec9    	ldr	x9, [x22, #0x458]
1000b8bb0: eb090108    	subs	x8, x8, x9
1000b8bb4: 540118c3    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8bb8: f94146a9    	ldr	x9, [x21, #0x288]
1000b8bbc: b4000109    	cbz	x9, 0x1000b8bdc <_machine.machine.Group.execute+0x19c>
1000b8bc0: f9423ac9    	ldr	x9, [x22, #0x470]
1000b8bc4: f940112a    	ldr	x10, [x9, #0x20]
1000b8bc8: ab08014a    	adds	x10, x10, x8
1000b8bcc: 54011802    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8bd0: f9413d29    	ldr	x9, [x9, #0x278]
1000b8bd4: eb09015f    	cmp	x10, x9
1000b8bd8: 5400a382    	b.hs	0x1000ba048 <_machine.machine.Group.execute+0x1608>
1000b8bdc: f94016a9    	ldr	x9, [x21, #0x28]
1000b8be0: b40000c9    	cbz	x9, 0x1000b8bf8 <_machine.machine.Group.execute+0x1b8>
1000b8be4: f940faaa    	ldr	x10, [x21, #0x1f0]
1000b8be8: ab080148    	adds	x8, x10, x8
1000b8bec: 54011702    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8bf0: eb09011f    	cmp	x8, x9
1000b8bf4: 5400a2e2    	b.hs	0x1000ba050 <_machine.machine.Group.execute+0x1610>
1000b8bf8: f9400288    	ldr	x8, [x20]
1000b8bfc: b40000c8    	cbz	x8, 0x1000b8c14 <_machine.machine.Group.execute+0x1d4>
1000b8c00: 91018109    	add	x9, x8, #0x60
1000b8c04: f9403d21    	ldr	x1, [x9, #0x78]
1000b8c08: eb1b003f    	cmp	x1, x27
1000b8c0c: 540000e8    	b.hi	0x1000b8c28 <_machine.machine.Group.execute+0x1e8>
1000b8c10: 140008b9    	b	0x1000baef4 <_machine.machine.Group.execute+0x24b4>
1000b8c14: f9423ac9    	ldr	x9, [x22, #0x470]
1000b8c18: 9101e129    	add	x9, x9, #0x78
1000b8c1c: f9403d21    	ldr	x1, [x9, #0x78]
1000b8c20: eb1b003f    	cmp	x1, x27
1000b8c24: 54011689    	b.ls	0x1000baef4 <_machine.machine.Group.execute+0x24b4>
1000b8c28: f9403929    	ldr	x9, [x9, #0x70]
1000b8c2c: 5280060a    	mov	w10, #0x30              ; =48
1000b8c30: 9baa2769    	umaddl	x9, w27, w10, x9
1000b8c34: ad408121    	ldp	q1, q0, [x9, #0x10]
1000b8c38: 3d8187e0    	str	q0, [sp, #0x610]
1000b8c3c: 3dc00120    	ldr	q0, [x9]
1000b8c40: 3d817fe0    	str	q0, [sp, #0x5f0]
1000b8c44: 3d8183e1    	str	q1, [sp, #0x600]
1000b8c48: b4000088    	cbz	x8, 0x1000b8c58 <_machine.machine.Group.execute+0x218>
1000b8c4c: 9100c109    	add	x9, x8, #0x30
1000b8c50: 9100e108    	add	x8, x8, #0x38
1000b8c54: 14000004    	b	0x1000b8c64 <_machine.machine.Group.execute+0x224>
1000b8c58: f9423ac8    	ldr	x8, [x22, #0x470]
1000b8c5c: 9106c109    	add	x9, x8, #0x1b0
1000b8c60: 9106e108    	add	x8, x8, #0x1b8
1000b8c64: f940011c    	ldr	x28, [x8]
1000b8c68: f9400129    	ldr	x9, [x9]
1000b8c6c: 3dc17fe0    	ldr	q0, [sp, #0x5f0]
1000b8c70: 3dc183e1    	ldr	q1, [sp, #0x600]
1000b8c74: 3c8d82a0    	stur	q0, [x21, #0xd8]
1000b8c78: b94613e8    	ldr	w8, [sp, #0x610]
1000b8c7c: f9002be8    	str	x8, [sp, #0x50]
1000b8c80: b94617e8    	ldr	w8, [sp, #0x614]
1000b8c84: f90027e8    	str	x8, [sp, #0x48]
1000b8c88: 395863f3    	ldrb	w19, [sp, #0x618]
1000b8c8c: f9001fe9    	str	x9, [sp, #0x38]
1000b8c90: a90cf2a9    	stp	x9, x28, [x21, #0xc8]
1000b8c94: b9010abb    	str	w27, [x21, #0x108]
1000b8c98: 3c8e82a1    	stur	q1, [x21, #0xe8]
1000b8c9c: 3dc187e0    	ldr	q0, [sp, #0x610]
1000b8ca0: 3c8f82a0    	stur	q0, [x21, #0xf8]
1000b8ca4: f9400288    	ldr	x8, [x20]
1000b8ca8: b40000a8    	cbz	x8, 0x1000b8cbc <_machine.machine.Group.execute+0x27c>
1000b8cac: 91018101    	add	x1, x8, #0x60
1000b8cb0: 7101ce7f    	cmp	w19, #0x73
1000b8cb4: 540000c1    	b.ne	0x1000b8ccc <_machine.machine.Group.execute+0x28c>
1000b8cb8: 1400005e    	b	0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8cbc: f9423ac8    	ldr	x8, [x22, #0x470]
1000b8cc0: 9101e101    	add	x1, x8, #0x78
1000b8cc4: 7101ce7f    	cmp	w19, #0x73
1000b8cc8: 54000b40    	b.eq	0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8ccc: f9401288    	ldr	x8, [x20, #0x20]
1000b8cd0: b4000b08    	cbz	x8, 0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8cd4: f9404428    	ldr	x8, [x1, #0x88]
1000b8cd8: b4000ac8    	cbz	x8, 0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8cdc: a944e6b7    	ldp	x23, x25, [x21, #0x48]
1000b8ce0: f9404029    	ldr	x9, [x1, #0x80]
1000b8ce4: 29402d2a    	ldp	w10, w11, [x9]
1000b8ce8: 3940412c    	ldrb	w12, [x9, #0x10]
1000b8cec: 1200058c    	and	w12, w12, #0x3
1000b8cf0: 7100059f    	cmp	w12, #0x1
1000b8cf4: 7a5b0142    	ccmp	w10, w27, #0x2, eq
1000b8cf8: 7a4b9362    	ccmp	w27, w11, #0x2, ls
1000b8cfc: 540000a9    	b.ls	0x1000b8d10 <_machine.machine.Group.execute+0x2d0>
1000b8d00: 91005129    	add	x9, x9, #0x14
1000b8d04: f1000508    	subs	x8, x8, #0x1
1000b8d08: 54fffee1    	b.ne	0x1000b8ce4 <_machine.machine.Group.execute+0x2a4>
1000b8d0c: 14000049    	b	0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8d10: 7102467f    	cmp	w19, #0x91
1000b8d14: 540110e2    	b.hs	0x1000baf30 <_machine.machine.Group.execute+0x24f0>
1000b8d18: 52801508    	mov	w8, #0xa8               ; =168
1000b8d1c: 90000e89    	adrp	x9, 0x100288000 <___anon_76546+0x18>
1000b8d20: 91068129    	add	x9, x9, #0x1a0
1000b8d24: 9ba82668    	umaddl	x8, w19, w8, x9
1000b8d28: 912e83e0    	add	x0, sp, #0xba0
1000b8d2c: 9117c3e2    	add	x2, sp, #0x5f0
1000b8d30: 9100c103    	add	x3, x8, #0x30
1000b8d34: 97ff7c56    	bl	0x100097e8c <_machine.verify.count>
1000b8d38: 396ea3e8    	ldrb	w8, [sp, #0xba8]
1000b8d3c: 360007a8    	tbz	w8, #0x0, 0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8d40: f945d3f8    	ldr	x24, [sp, #0xba0]
1000b8d44: b4000778    	cbz	x24, 0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8d48: f9401281    	ldr	x1, [x20, #0x20]
1000b8d4c: eb01031f    	cmp	x24, x1
1000b8d50: 54000708    	b.hi	0x1000b8e30 <_machine.machine.Group.execute+0x3f0>
1000b8d54: f100231f    	cmp	x24, #0x8
1000b8d58: 54000068    	b.hi	0x1000b8d64 <_machine.machine.Group.execute+0x324>
1000b8d5c: 911003f7    	add	x23, sp, #0x400
1000b8d60: 14000018    	b	0x1000b8dc0 <_machine.machine.Group.execute+0x380>
1000b8d64: 52800608    	mov	w8, #0x30               ; =48
1000b8d68: 9bc87f08    	umulh	x8, x24, x8
1000b8d6c: eb0803ff    	cmp	xzr, x8
1000b8d70: 54009881    	b.ne	0x1000ba080 <_machine.machine.Group.execute+0x1640>
1000b8d74: 8b180708    	add	x8, x24, x24, lsl #1
1000b8d78: d37ced1a    	lsl	x26, x8, #4
1000b8d7c: f94017e3    	ldr	x3, [sp, #0x28]
1000b8d80: dac143e3    	xpaci	x3
1000b8d84: f9400328    	ldr	x8, [x25]
1000b8d88: aa1703e0    	mov	x0, x23
1000b8d8c: aa1a03e1    	mov	x1, x26
1000b8d90: 52800082    	mov	w2, #0x4                ; =4
1000b8d94: d63f0100    	blr	x8
1000b8d98: b4009740    	cbz	x0, 0x1000ba080 <_machine.machine.Group.execute+0x1640>
1000b8d9c: aa0003f7    	mov	x23, x0
1000b8da0: 52801541    	mov	w1, #0xaa               ; =170
1000b8da4: aa1a03e2    	mov	x2, x26
1000b8da8: 940515b5    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b8dac: f2400eff    	tst	x23, #0xf
1000b8db0: 54010ca1    	b.ne	0x1000baf44 <_machine.machine.Group.execute+0x2504>
1000b8db4: f902c3f7    	str	x23, [sp, #0x580]
1000b8db8: f902c7f8    	str	x24, [sp, #0x588]
1000b8dbc: f9401281    	ldr	x1, [x20, #0x20]
1000b8dc0: eb180020    	subs	x0, x1, x24
1000b8dc4: 54010843    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8dc8: eb00003f    	cmp	x1, x0
1000b8dcc: 54010ca3    	b.lo	0x1000baf60 <_machine.machine.Group.execute+0x2520>
1000b8dd0: cb000028    	sub	x8, x1, x0
1000b8dd4: eb08031f    	cmp	x24, x8
1000b8dd8: 54010c21    	b.ne	0x1000baf5c <_machine.machine.Group.execute+0x251c>
1000b8ddc: f9400e88    	ldr	x8, [x20, #0x18]
1000b8de0: 52800609    	mov	w9, #0x30               ; =48
1000b8de4: 9b092019    	madd	x25, x0, x9, x8
1000b8de8: aa1803fa    	mov	x26, x24
1000b8dec: ad400720    	ldp	q0, q1, [x25]
1000b8df0: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
1000b8df4: 3dc00b20    	ldr	q0, [x25, #0x20]
1000b8df8: 3c9603a0    	stur	q0, [x29, #-0xa0]
1000b8dfc: 913003e0    	add	x0, sp, #0xc00
1000b8e00: d10303a1    	sub	x1, x29, #0xc0
1000b8e04: 9401369f    	bl	0x100106880 <_machine.machine.retainSlot>
1000b8e08: 3dc303e0    	ldr	q0, [sp, #0xc00]
1000b8e0c: 3dc307e1    	ldr	q1, [sp, #0xc10]
1000b8e10: ad0006e0    	stp	q0, q1, [x23]
1000b8e14: 3dc30be0    	ldr	q0, [sp, #0xc20]
1000b8e18: 3d800ae0    	str	q0, [x23, #0x20]
1000b8e1c: 9100c339    	add	x25, x25, #0x30
1000b8e20: 9100c2f7    	add	x23, x23, #0x30
1000b8e24: f100075a    	subs	x26, x26, #0x1
1000b8e28: 54fffe21    	b.ne	0x1000b8dec <_machine.machine.Group.execute+0x3ac>
1000b8e2c: f902cbf8    	str	x24, [sp, #0x590]
1000b8e30: b9403e88    	ldr	w8, [x20, #0x3c]
1000b8e34: 31000508    	adds	w8, w8, #0x1
1000b8e38: 540104a2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8e3c: b9003e88    	str	w8, [x20, #0x3c]
1000b8e40: b0000ec8    	adrp	x8, 0x100291000 <___anon_84261+0x9d0>
1000b8e44: 913a4108    	add	x8, x8, #0xe90
1000b8e48: ad420101    	ldp	q1, q0, [x8, #0x40]
1000b8e4c: ad0303e1    	stp	q1, q0, [sp, #0x60]
1000b8e50: 3d819be1    	str	q1, [sp, #0x660]
1000b8e54: 3d819fe0    	str	q0, [sp, #0x670]
1000b8e58: f9403117    	ldr	x23, [x8, #0x60]
1000b8e5c: f90343f7    	str	x23, [sp, #0x680]
1000b8e60: ad400101    	ldp	q1, q0, [x8]
1000b8e64: ad0403e1    	stp	q1, q0, [sp, #0x80]
1000b8e68: 3d818be1    	str	q1, [sp, #0x620]
1000b8e6c: 3d818fe0    	str	q0, [sp, #0x630]
1000b8e70: ad410500    	ldp	q0, q1, [x8, #0x20]
1000b8e74: ad0503e1    	stp	q1, q0, [sp, #0xa0]
1000b8e78: 3d8197e1    	str	q1, [sp, #0x650]
1000b8e7c: 3d8193e0    	str	q0, [sp, #0x640]
1000b8e80: 911a23e0    	add	x0, sp, #0x688
1000b8e84: 9117c3e4    	add	x4, sp, #0x5f0
1000b8e88: 911883e5    	add	x5, sp, #0x620
1000b8e8c: aa1503e1    	mov	x1, x21
1000b8e90: aa1603e2    	mov	x2, x22
1000b8e94: aa1403e3    	mov	x3, x20
1000b8e98: 97ffd67a    	bl	0x1000ae880 <_machine.machine.Group.instruction>
1000b8e9c: 794db3f4    	ldrh	w20, [sp, #0x6d8]
1000b8ea0: f9001bfc    	str	x28, [sp, #0x30]
1000b8ea4: 35000374    	cbnz	w20, 0x1000b8f10 <_machine.machine.Group.execute+0x4d0>
1000b8ea8: 911a23e8    	add	x8, sp, #0x688
1000b8eac: ad418101    	ldp	q1, q0, [x8, #0x30]
1000b8eb0: 3d81cbe0    	str	q0, [sp, #0x720]
1000b8eb4: ad408900    	ldp	q0, q2, [x8, #0x10]
1000b8eb8: 3d81c3e2    	str	q2, [sp, #0x700]
1000b8ebc: 3d81c7e1    	str	q1, [sp, #0x710]
1000b8ec0: 3dc00101    	ldr	q1, [x8]
1000b8ec4: 3d81bfe0    	str	q0, [sp, #0x6f0]
1000b8ec8: 3d81bbe1    	str	q1, [sp, #0x6e0]
1000b8ecc: 395ca3e8    	ldrb	w8, [sp, #0x728]
1000b8ed0: 12000d08    	and	w8, w8, #0xf
1000b8ed4: 7100311f    	cmp	w8, #0xc
1000b8ed8: 540076e0    	b.eq	0x1000b9db4 <_machine.machine.Group.execute+0x1374>
1000b8edc: 911b83fa    	add	x26, sp, #0x6e0
1000b8ee0: f94023fc    	ldr	x28, [sp, #0x40]
1000b8ee4: 395a07e8    	ldrb	w8, [sp, #0x681]
1000b8ee8: b9405fe9    	ldr	w9, [sp, #0x5c]
1000b8eec: 360003e9    	tbz	w9, #0x0, 0x1000b8f68 <_machine.machine.Group.execute+0x528>
1000b8ef0: 360003c8    	tbz	w8, #0x0, 0x1000b8f68 <_machine.machine.Group.execute+0x528>
1000b8ef4: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b8ef8: f940fec9    	ldr	x9, [x22, #0x1f8]
1000b8efc: ab090108    	adds	x8, x8, x9
1000b8f00: 5400fe62    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8f04: f9005ac8    	str	x8, [x22, #0xb0]
1000b8f08: f900fedf    	str	xzr, [x22, #0x1f8]
1000b8f0c: 14000084    	b	0x1000b911c <_machine.machine.Group.execute+0x6dc>
1000b8f10: 71028e9f    	cmp	w20, #0xa3
1000b8f14: 5400e0cc    	b.gt	0x1000bab2c <_machine.machine.Group.execute+0x20ec>
1000b8f18: 7102869f    	cmp	w20, #0xa1
1000b8f1c: 5400e9a0    	b.eq	0x1000bac50 <_machine.machine.Group.execute+0x2210>
1000b8f20: 71028e9f    	cmp	w20, #0xa3
1000b8f24: 5400e441    	b.ne	0x1000babac <_machine.machine.Group.execute+0x216c>
1000b8f28: 911ce3e0    	add	x0, sp, #0x738
1000b8f2c: 9117c3e3    	add	x3, sp, #0x5f0
1000b8f30: aa1503e1    	mov	x1, x21
1000b8f34: aa1603e2    	mov	x2, x22
1000b8f38: 97fff86d    	bl	0x1000b70ec <_machine.machine.Group.completeError>
1000b8f3c: 794e83f4    	ldrh	w20, [sp, #0x740]
1000b8f40: 3500fc94    	cbnz	w20, 0x1000baed0 <_machine.machine.Group.execute+0x2490>
1000b8f44: f9439fe8    	ldr	x8, [sp, #0x738]
1000b8f48: f903a7e8    	str	x8, [sp, #0x748]
1000b8f4c: 52800068    	mov	w8, #0x3                ; =3
1000b8f50: 391e43e8    	strb	w8, [sp, #0x790]
1000b8f54: 911d23fa    	add	x26, sp, #0x748
1000b8f58: f9400bfc    	ldr	x28, [sp, #0x10]
1000b8f5c: 395a07e8    	ldrb	w8, [sp, #0x681]
1000b8f60: b9405fe9    	ldr	w9, [sp, #0x5c]
1000b8f64: 3707fc69    	tbnz	w9, #0x0, 0x1000b8ef0 <_machine.machine.Group.execute+0x4b0>
1000b8f68: b94027e9    	ldr	w9, [sp, #0x24]
1000b8f6c: 2a080128    	orr	w8, w9, w8
1000b8f70: 37000d68    	tbnz	w8, #0x0, 0x1000b911c <_machine.machine.Group.execute+0x6dc>
1000b8f74: 910503e0    	add	x0, sp, #0x140
1000b8f78: 911883e2    	add	x2, sp, #0x620
1000b8f7c: aa1303e1    	mov	x1, x19
1000b8f80: 94012fe9    	bl	0x100104f24 <_machine.costs.chargeInstruction>
1000b8f84: f940a3e8    	ldr	x8, [sp, #0x140]
1000b8f88: f940fed4    	ldr	x20, [x22, #0x1f8]
1000b8f8c: ab140119    	adds	x25, x8, x20
1000b8f90: 5400f9e2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8f94: f940a7f8    	ldr	x24, [sp, #0x148]
1000b8f98: f900fedf    	str	xzr, [x22, #0x1f8]
1000b8f9c: 39412348    	ldrb	w8, [x26, #0x48]
1000b8fa0: 51002909    	sub	w9, w8, #0xa
1000b8fa4: 7100093f    	cmp	w9, #0x2
1000b8fa8: 540000e2    	b.hs	0x1000b8fc4 <_machine.machine.Group.execute+0x584>
1000b8fac: 52800028    	mov	w8, #0x1                ; =1
1000b8fb0: f94272ca    	ldr	x10, [x22, #0x4e0]
1000b8fb4: 90000ba9    	adrp	x9, 0x10022c000 <___anon_29849+0x8>
1000b8fb8: 913dc929    	add	x9, x9, #0xf72
1000b8fbc: b50007aa    	cbnz	x10, 0x1000b90b0 <_machine.machine.Group.execute+0x670>
1000b8fc0: 14000014    	b	0x1000b9010 <_machine.machine.Group.execute+0x5d0>
1000b8fc4: 7100051f    	cmp	w8, #0x1
1000b8fc8: 54000161    	b.ne	0x1000b8ff4 <_machine.machine.Group.execute+0x5b4>
1000b8fcc: f9404ec8    	ldr	x8, [x22, #0x98]
1000b8fd0: f1000508    	subs	x8, x8, #0x1
1000b8fd4: 5400f7c3    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b8fd8: f94272ca    	ldr	x10, [x22, #0x4e0]
1000b8fdc: eb0a011f    	cmp	x8, x10
1000b8fe0: 1a9f17e8    	cset	w8, eq
1000b8fe4: 90000ba9    	adrp	x9, 0x10022c000 <___anon_29849+0x8>
1000b8fe8: 913dc929    	add	x9, x9, #0xf72
1000b8fec: b500062a    	cbnz	x10, 0x1000b90b0 <_machine.machine.Group.execute+0x670>
1000b8ff0: 14000008    	b	0x1000b9010 <_machine.machine.Group.execute+0x5d0>
1000b8ff4: 7100351f    	cmp	w8, #0xd
1000b8ff8: 5400f8e2    	b.hs	0x1000baf14 <_machine.machine.Group.execute+0x24d4>
1000b8ffc: 52800008    	mov	w8, #0x0                ; =0
1000b9000: f94272ca    	ldr	x10, [x22, #0x4e0]
1000b9004: f0000b89    	adrp	x9, 0x10022c000 <___anon_29849+0x8>
1000b9008: 913dc929    	add	x9, x9, #0xf72
1000b900c: b500052a    	cbnz	x10, 0x1000b90b0 <_machine.machine.Group.execute+0x670>
1000b9010: 34000128    	cbz	w8, 0x1000b9034 <_machine.machine.Group.execute+0x5f4>
1000b9014: f9423ac0    	ldr	x0, [x22, #0x470]
1000b9018: 9400261c    	bl	0x1000c2888 <_machine.machine.Group.persistentState>
1000b901c: f9423ac8    	ldr	x8, [x22, #0x470]
1000b9020: f9412108    	ldr	x8, [x8, #0x240]
1000b9024: b0000ae9    	adrp	x9, 0x100216000 <___anon_77823+0x8>
1000b9028: 91254129    	add	x9, x9, #0x950
1000b902c: eb08001f    	cmp	x0, x8
1000b9030: 54000408    	b.hi	0x1000b90b0 <_machine.machine.Group.execute+0x670>
1000b9034: 394c82c9    	ldrb	w9, [x22, #0x320]
1000b9038: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b903c: 36000189    	tbz	w9, #0x0, 0x1000b906c <_machine.machine.Group.execute+0x62c>
1000b9040: f9418ec9    	ldr	x9, [x22, #0x318]
1000b9044: eb090108    	subs	x8, x8, x9
1000b9048: 5400f423    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b904c: f940fac9    	ldr	x9, [x22, #0x1f0]
1000b9050: 9ac86529    	umax	x9, x9, x8
1000b9054: cb080128    	sub	x8, x9, x8
1000b9058: b0000ae9    	adrp	x9, 0x100216000 <___anon_77823+0x8>
1000b905c: 91254929    	add	x9, x9, #0x952
1000b9060: eb08033f    	cmp	x25, x8
1000b9064: 54000129    	b.ls	0x1000b9088 <_machine.machine.Group.execute+0x648>
1000b9068: 14000012    	b	0x1000b90b0 <_machine.machine.Group.execute+0x670>
1000b906c: f940dac9    	ldr	x9, [x22, #0x1b0]
1000b9070: 9ac86529    	umax	x9, x9, x8
1000b9074: cb080128    	sub	x8, x9, x8
1000b9078: b0000ae9    	adrp	x9, 0x100216000 <___anon_77823+0x8>
1000b907c: 91254929    	add	x9, x9, #0x952
1000b9080: eb08033f    	cmp	x25, x8
1000b9084: 54000168    	b.hi	0x1000b90b0 <_machine.machine.Group.execute+0x670>
1000b9088: f9405ec8    	ldr	x8, [x22, #0xb8]
1000b908c: ab180108    	adds	x8, x8, x24
1000b9090: 5400f1e2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9094: f940dec9    	ldr	x9, [x22, #0x1b8]
1000b9098: eb09011f    	cmp	x8, x9
1000b909c: f0000b88    	adrp	x8, 0x10022c000 <___anon_29849+0x8>
1000b90a0: 913dc908    	add	x8, x8, #0xf72
1000b90a4: 90000ba9    	adrp	x9, 0x10022d000 <___anon_149624>
1000b90a8: 9106c129    	add	x9, x9, #0x1b0
1000b90ac: 9a888129    	csel	x9, x9, x8, hi
1000b90b0: 39400528    	ldrb	w8, [x9, #0x1]
1000b90b4: 37007108    	tbnz	w8, #0x0, 0x1000b9ed4 <_machine.machine.Group.execute+0x1494>
1000b90b8: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b90bc: ab190108    	adds	x8, x8, x25
1000b90c0: 5400f062    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b90c4: f9005ac8    	str	x8, [x22, #0xb0]
1000b90c8: f9405ec8    	ldr	x8, [x22, #0xb8]
1000b90cc: ab180108    	adds	x8, x8, x24
1000b90d0: 5400efe2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b90d4: f9005ec8    	str	x8, [x22, #0xb8]
1000b90d8: 39412348    	ldrb	w8, [x26, #0x48]
1000b90dc: 12000d08    	and	w8, w8, #0xf
1000b90e0: 7100251f    	cmp	w8, #0x9
1000b90e4: 540001c1    	b.ne	0x1000b911c <_machine.machine.Group.execute+0x6dc>
1000b90e8: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b90ec: b5000188    	cbnz	x8, 0x1000b911c <_machine.machine.Group.execute+0x6dc>
1000b90f0: f9423ac0    	ldr	x0, [x22, #0x470]
1000b90f4: 940025e5    	bl	0x1000c2888 <_machine.machine.Group.persistentState>
1000b90f8: aa0003f3    	mov	x19, x0
1000b90fc: aa1603e0    	mov	x0, x22
1000b9100: 9400234d    	bl	0x1000c1e34 <_machine.machine.Group.runSize>
1000b9104: ab000268    	adds	x8, x19, x0
1000b9108: 5400ee22    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b910c: f9423ac9    	ldr	x9, [x22, #0x470]
1000b9110: f9412129    	ldr	x9, [x9, #0x240]
1000b9114: eb09011f    	cmp	x8, x9
1000b9118: 5400a228    	b.hi	0x1000ba55c <_machine.machine.Group.execute+0x1b1c>
1000b911c: f94313e0    	ldr	x0, [sp, #0x620]
1000b9120: b4000040    	cbz	x0, 0x1000b9128 <_machine.machine.Group.execute+0x6e8>
1000b9124: 97fea230    	bl	0x1000619e4 <_value.Value.release>
1000b9128: f94317e0    	ldr	x0, [sp, #0x628]
1000b912c: b4000040    	cbz	x0, 0x1000b9134 <_machine.machine.Group.execute+0x6f4>
1000b9130: 97fea22d    	bl	0x1000619e4 <_value.Value.release>
1000b9134: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000b9138: 3d819be1    	str	q1, [sp, #0x660]
1000b913c: 3d819fe0    	str	q0, [sp, #0x670]
1000b9140: f90343f7    	str	x23, [sp, #0x680]
1000b9144: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000b9148: 3d818be1    	str	q1, [sp, #0x620]
1000b914c: 3d818fe0    	str	q0, [sp, #0x630]
1000b9150: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000b9154: 3d8197e1    	str	q1, [sp, #0x650]
1000b9158: 3d8193e0    	str	q0, [sp, #0x640]
1000b915c: 39412348    	ldrb	w8, [x26, #0x48]
1000b9160: 12000d09    	and	w9, w8, #0xf
1000b9164: 7100313f    	cmp	w9, #0xc
1000b9168: 5400ed68    	b.hi	0x1000baf14 <_machine.machine.Group.execute+0x24d4>
1000b916c: d0000a2b    	adrp	x11, 0x1001ff000 <_writev+0x1001ff000>
1000b9170: 913f316b    	add	x11, x11, #0xfcc
1000b9174: 10000089    	adr	x9, 0x1000b9184 <_machine.machine.Group.execute+0x744>
1000b9178: 7868796a    	ldrh	w10, [x11, x8, lsl #1]
1000b917c: 8b0a0929    	add	x9, x9, x10, lsl #2
1000b9180: d61f0120    	br	x9
1000b9184: f9400353    	ldr	x19, [x26]
1000b9188: aa1503e0    	mov	x0, x21
1000b918c: aa1603e1    	mov	x1, x22
1000b9190: 97feef1f    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b9194: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9198: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b919c: eb08003f    	cmp	x1, x8
1000b91a0: 54007c60    	b.eq	0x1000ba12c <_machine.machine.Group.execute+0x16ec>
1000b91a4: f1000420    	subs	x0, x1, #0x1
1000b91a8: 5400e923    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b91ac: eb01001f    	cmp	x0, x1
1000b91b0: 5400ea02    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b91b4: f9404ac8    	ldr	x8, [x22, #0x90]
1000b91b8: 52800909    	mov	w9, #0x48               ; =72
1000b91bc: 9b092014    	madd	x20, x0, x9, x8
1000b91c0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b91c4: 3d8303e0    	str	q0, [sp, #0xc00]
1000b91c8: f9401288    	ldr	x8, [x20, #0x20]
1000b91cc: b1000502    	adds	x2, x8, #0x1
1000b91d0: 5400e7e2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b91d4: 91006280    	add	x0, x20, #0x18
1000b91d8: 913003e1    	add	x1, sp, #0xc00
1000b91dc: 97ff8332    	bl	0x100099ea4 <_array_list.Aligned(machine.machine.Slot,null).ensureTotalCapacity>
1000b91e0: 72003c17    	ands	w23, w0, #0xffff
1000b91e4: 5400dec1    	b.ne	0x1000badbc <_machine.machine.Group.execute+0x237c>
1000b91e8: a9422688    	ldp	x8, x9, [x20, #0x20]
1000b91ec: eb09011f    	cmp	x8, x9
1000b91f0: 5400e862    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b91f4: 91000509    	add	x9, x8, #0x1
1000b91f8: f9001289    	str	x9, [x20, #0x20]
1000b91fc: f9400e89    	ldr	x9, [x20, #0x18]
1000b9200: 5280060a    	mov	w10, #0x30              ; =48
1000b9204: 9b0a2508    	madd	x8, x8, x10, x9
1000b9208: f9000113    	str	x19, [x8]
1000b920c: 3900811f    	strb	wzr, [x8, #0x20]
1000b9210: 140002b6    	b	0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b9214: f9420ec8    	ldr	x8, [x22, #0x418]
1000b9218: b4000208    	cbz	x8, 0x1000b9258 <_machine.machine.Group.execute+0x818>
1000b921c: f9420ac9    	ldr	x9, [x22, #0x410]
1000b9220: 5280160a    	mov	w10, #0xb0              ; =176
1000b9224: 9b0a2508    	madd	x8, x8, x10, x9
1000b9228: 385f8109    	ldurb	w9, [x8, #-0x8]
1000b922c: 36000169    	tbz	w9, #0x0, 0x1000b9258 <_machine.machine.Group.execute+0x818>
1000b9230: 385d0109    	ldurb	w9, [x8, #-0x30]
1000b9234: 12000929    	and	w9, w9, #0x7
1000b9238: 7100053f    	cmp	w9, #0x1
1000b923c: 540000e1    	b.ne	0x1000b9258 <_machine.machine.Group.execute+0x818>
1000b9240: f8550102    	ldur	x2, [x8, #-0xb0]
1000b9244: aa1503e0    	mov	x0, x21
1000b9248: aa1603e1    	mov	x1, x22
1000b924c: aa1b03e3    	mov	x3, x27
1000b9250: a94493e5    	ldp	x5, x4, [sp, #0x48]
1000b9254: 94001b36    	bl	0x1000bff2c <_machine.machine.Group.writeRaise>
1000b9258: 9128a3e0    	add	x0, sp, #0xa28
1000b925c: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9260: 12000103    	and	w3, w8, #0x1
1000b9264: aa1503e1    	mov	x1, x21
1000b9268: aa1603e2    	mov	x2, x22
1000b926c: 94001794    	bl	0x1000bf0bc <_machine.machine.Group.nextCleanup>
1000b9270: 7954f3f3    	ldrh	w19, [sp, #0xa78]
1000b9274: 3500d393    	cbnz	w19, 0x1000bace4 <_machine.machine.Group.execute+0x22a4>
1000b9278: 3969c3e8    	ldrb	w8, [sp, #0xa70]
1000b927c: 36005368    	tbz	w8, #0x0, 0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b9280: 140003b6    	b	0x1000ba158 <_machine.machine.Group.execute+0x1718>
1000b9284: f9420ec1    	ldr	x1, [x22, #0x418]
1000b9288: f1000420    	subs	x0, x1, #0x1
1000b928c: 5400e203    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9290: eb01001f    	cmp	x0, x1
1000b9294: 5400e2e2    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b9298: f9420ac8    	ldr	x8, [x22, #0x410]
1000b929c: 52801609    	mov	w9, #0xb0               ; =176
1000b92a0: 9b092008    	madd	x8, x0, x9, x8
1000b92a4: 3942a109    	ldrb	w9, [x8, #0xa8]
1000b92a8: 3700e3e9    	tbnz	w9, #0x0, 0x1000baf24 <_machine.machine.Group.execute+0x24e4>
1000b92ac: f9400513    	ldr	x19, [x8, #0x8]
1000b92b0: f9404ec1    	ldr	x1, [x22, #0x98]
1000b92b4: eb01027f    	cmp	x19, x1
1000b92b8: 5400e322    	b.hs	0x1000baf1c <_machine.machine.Group.execute+0x24dc>
1000b92bc: f9404ac8    	ldr	x8, [x22, #0x90]
1000b92c0: 52800909    	mov	w9, #0x48               ; =72
1000b92c4: 9b092268    	madd	x8, x19, x9, x8
1000b92c8: b9403d18    	ldr	w24, [x8, #0x3c]
1000b92cc: 3cc18100    	ldur	q0, [x8, #0x18]
1000b92d0: 3cc28101    	ldur	q1, [x8, #0x28]
1000b92d4: ad1b07e0    	stp	q0, q1, [sp, #0x360]
1000b92d8: b0000ae9    	adrp	x9, 0x100216000 <___anon_77823+0x8>
1000b92dc: 9102c129    	add	x9, x9, #0xb0
1000b92e0: ad400520    	ldp	q0, q1, [x9]
1000b92e4: 3c818100    	stur	q0, [x8, #0x18]
1000b92e8: 3c828101    	stur	q1, [x8, #0x28]
1000b92ec: 913003e0    	add	x0, sp, #0xc00
1000b92f0: aa1503e1    	mov	x1, x21
1000b92f4: aa1603e2    	mov	x2, x22
1000b92f8: 940016bb    	bl	0x1000bede4 <_machine.machine.Group.endDispatch>
1000b92fc: f94603f4    	ldr	x20, [sp, #0xc00]
1000b9300: f94607e3    	ldr	x3, [sp, #0xc08]
1000b9304: f94627e8    	ldr	x8, [sp, #0xc48]
1000b9308: b94c8be7    	ldr	w7, [sp, #0xc88]
1000b930c: b0000ae9    	adrp	x9, 0x100216000 <___anon_77823+0x8>
1000b9310: 91042129    	add	x9, x9, #0x108
1000b9314: ad400520    	ldp	q0, q1, [x9]
1000b9318: ad1c07e0    	stp	q0, q1, [sp, #0x380]
1000b931c: f1000504    	subs	x4, x8, #0x1
1000b9320: 5400dd63    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9324: 910e03e2    	add	x2, sp, #0x380
1000b9328: 913003e8    	add	x8, sp, #0xc00
1000b932c: 9101c106    	add	x6, x8, #0x70
1000b9330: aa1503e0    	mov	x0, x21
1000b9334: aa1603e1    	mov	x1, x22
1000b9338: 52800025    	mov	w5, #0x1                ; =1
1000b933c: 97fffc67    	bl	0x1000b84d8 <_machine.machine.Group.collect>
1000b9340: 72003c17    	ands	w23, w0, #0xffff
1000b9344: 5400cea1    	b.ne	0x1000bad18 <_machine.machine.Group.execute+0x22d8>
1000b9348: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
1000b934c: 912e83e8    	add	x8, sp, #0xba0
1000b9350: 3c808100    	stur	q0, [x8, #0x8]
1000b9354: 3c818101    	stur	q1, [x8, #0x18]
1000b9358: f905d3f3    	str	x19, [sp, #0xba0]
1000b935c: b90bcbf8    	str	w24, [sp, #0xbc8]
1000b9360: 392fc3ff    	strb	wzr, [sp, #0xbf0]
1000b9364: 910e03e3    	add	x3, sp, #0x380
1000b9368: 912e83e4    	add	x4, sp, #0xba0
1000b936c: aa1503e0    	mov	x0, x21
1000b9370: aa1603e1    	mov	x1, x22
1000b9374: aa1403e2    	mov	x2, x20
1000b9378: 97fffd49    	bl	0x1000b889c <_machine.machine.Group.startCleanup>
1000b937c: 72003c17    	ands	w23, w0, #0xffff
1000b9380: 5400ce81    	b.ne	0x1000bad50 <_machine.machine.Group.execute+0x2310>
1000b9384: d10303a0    	sub	x0, x29, #0xc0
1000b9388: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b938c: 12000103    	and	w3, w8, #0x1
1000b9390: aa1503e1    	mov	x1, x21
1000b9394: aa1603e2    	mov	x2, x22
1000b9398: 94001749    	bl	0x1000bf0bc <_machine.machine.Group.nextCleanup>
1000b939c: 785903b7    	ldurh	w23, [x29, #-0x70]
1000b93a0: 350070d7    	cbnz	w23, 0x1000ba1b8 <_machine.machine.Group.execute+0x1778>
1000b93a4: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
1000b93a8: 3d82abe0    	str	q0, [sp, #0xaa0]
1000b93ac: 3d82afe1    	str	q1, [sp, #0xab0]
1000b93b0: f85803a8    	ldur	x8, [x29, #-0x80]
1000b93b4: f90563e8    	str	x8, [sp, #0xac0]
1000b93b8: ad7a03a1    	ldp	q1, q0, [x29, #-0xc0]
1000b93bc: 3d82a7e0    	str	q0, [sp, #0xa90]
1000b93c0: 3d82a3e1    	str	q1, [sp, #0xa80]
1000b93c4: 385883a8    	ldurb	w8, [x29, #-0x78]
1000b93c8: 36004908    	tbz	w8, #0x0, 0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b93cc: 140003c3    	b	0x1000ba2d8 <_machine.machine.Group.execute+0x1898>
1000b93d0: f9404ec1    	ldr	x1, [x22, #0x98]
1000b93d4: f1000420    	subs	x0, x1, #0x1
1000b93d8: 1a9f27e8    	cset	w8, lo
1000b93dc: 5400d783    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b93e0: eb01001f    	cmp	x0, x1
1000b93e4: 5400d862    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b93e8: f9404ac9    	ldr	x9, [x22, #0x90]
1000b93ec: 5280090a    	mov	w10, #0x48              ; =72
1000b93f0: 9b0a7c0a    	mul	x10, x0, x10
1000b93f4: f86a6929    	ldr	x9, [x9, x10]
1000b93f8: b40017c9    	cbz	x9, 0x1000b96f0 <_machine.machine.Group.execute+0xcb0>
1000b93fc: 9101812b    	add	x11, x9, #0x60
1000b9400: f9400353    	ldr	x19, [x26]
1000b9404: f940456a    	ldr	x10, [x11, #0x88]
1000b9408: b50017ea    	cbnz	x10, 0x1000b9704 <_machine.machine.Group.execute+0xcc4>
1000b940c: 14000235    	b	0x1000b9ce0 <_machine.machine.Group.execute+0x12a0>
1000b9410: 3dc00340    	ldr	q0, [x26]
1000b9414: 3d80bfe0    	str	q0, [sp, #0x2f0]
1000b9418: a9415353    	ldp	x19, x20, [x26, #0x10]
1000b941c: ad400780    	ldp	q0, q1, [x28]
1000b9420: 3d82cbe0    	str	q0, [sp, #0xb20]
1000b9424: 3d82cfe1    	str	q1, [sp, #0xb30]
1000b9428: f9401388    	ldr	x8, [x28, #0x20]
1000b942c: f905a3e8    	str	x8, [sp, #0xb40]
1000b9430: f9420ec8    	ldr	x8, [x22, #0x418]
1000b9434: 5280160c    	mov	w12, #0xb0              ; =176
1000b9438: b400d5a8    	cbz	x8, 0x1000baeec <_machine.machine.Group.execute+0x24ac>
1000b943c: f9420ac9    	ldr	x9, [x22, #0x410]
1000b9440: 9b0c250a    	madd	x10, x8, x12, x9
1000b9444: 385f814b    	ldurb	w11, [x10, #-0x8]
1000b9448: 360007eb    	tbz	w11, #0x0, 0x1000b9544 <_machine.machine.Group.execute+0xb04>
1000b944c: 9b0c2509    	madd	x9, x8, x12, x9
1000b9450: d102e129    	sub	x9, x9, #0xb8
1000b9454: f1000508    	subs	x8, x8, #0x1
1000b9458: 5400d4a0    	b.eq	0x1000baeec <_machine.machine.Group.execute+0x24ac>
1000b945c: d102c12a    	sub	x10, x9, #0xb0
1000b9460: 3940012b    	ldrb	w11, [x9]
1000b9464: aa0a03e9    	mov	x9, x10
1000b9468: 3707ff6b    	tbnz	w11, #0x0, 0x1000b9454 <_machine.machine.Group.execute+0xa14>
1000b946c: 91002158    	add	x24, x10, #0x8
1000b9470: 14000036    	b	0x1000b9548 <_machine.machine.Group.execute+0xb08>
1000b9474: f9400353    	ldr	x19, [x26]
1000b9478: f942c7e1    	ldr	x1, [sp, #0x588]
1000b947c: b4001101    	cbz	x1, 0x1000b969c <_machine.machine.Group.execute+0xc5c>
1000b9480: f942c3e0    	ldr	x0, [sp, #0x580]
1000b9484: 1400008a    	b	0x1000b96ac <_machine.machine.Group.execute+0xc6c>
1000b9488: f9404ec1    	ldr	x1, [x22, #0x98]
1000b948c: f1000420    	subs	x0, x1, #0x1
1000b9490: 5400d1e3    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9494: eb01001f    	cmp	x0, x1
1000b9498: 5400d2c2    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b949c: f9404ac8    	ldr	x8, [x22, #0x90]
1000b94a0: 52800909    	mov	w9, #0x48               ; =72
1000b94a4: 9b09201c    	madd	x28, x0, x9, x8
1000b94a8: 39410788    	ldrb	w8, [x28, #0x41]
1000b94ac: 36005ba8    	tbz	w8, #0x0, 0x1000ba020 <_machine.machine.Group.execute+0x15e0>
1000b94b0: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b94b4: eb08001f    	cmp	x0, x8
1000b94b8: 54005b49    	b.ls	0x1000ba020 <_machine.machine.Group.execute+0x15e0>
1000b94bc: f940039a    	ldr	x26, [x28]
1000b94c0: b40014da    	cbz	x26, 0x1000b9758 <_machine.machine.Group.execute+0xd18>
1000b94c4: 91018357    	add	x23, x26, #0x60
1000b94c8: b9403b9b    	ldr	w27, [x28, #0x38]
1000b94cc: f94036e1    	ldr	x1, [x23, #0x68]
1000b94d0: eb1b003f    	cmp	x1, x27
1000b94d4: 540014e8    	b.hi	0x1000b9770 <_machine.machine.Group.execute+0xd30>
1000b94d8: 14000687    	b	0x1000baef4 <_machine.machine.Group.execute+0x24b4>
1000b94dc: 913003e0    	add	x0, sp, #0xc00
1000b94e0: aa1503e1    	mov	x1, x21
1000b94e4: aa1603e2    	mov	x2, x22
1000b94e8: 9400163f    	bl	0x1000bede4 <_machine.machine.Group.endDispatch>
1000b94ec: f94603e3    	ldr	x3, [sp, #0xc00]
1000b94f0: d10303a0    	sub	x0, x29, #0xc0
1000b94f4: 913003e8    	add	x8, sp, #0xc00
1000b94f8: 91010104    	add	x4, x8, #0x40
1000b94fc: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9500: 12000105    	and	w5, w8, #0x1
1000b9504: aa1503e1    	mov	x1, x21
1000b9508: aa1603e2    	mov	x2, x22
1000b950c: 94001cc0    	bl	0x1000c080c <_machine.machine.Group.search>
1000b9510: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
1000b9514: 3d82bfe0    	str	q0, [sp, #0xaf0]
1000b9518: 3d82c3e1    	str	q1, [sp, #0xb00]
1000b951c: f85803a8    	ldur	x8, [x29, #-0x80]
1000b9520: f9058be8    	str	x8, [sp, #0xb10]
1000b9524: ad7a03a1    	ldp	q1, q0, [x29, #-0xc0]
1000b9528: 3d82bbe0    	str	q0, [sp, #0xae0]
1000b952c: 3d82b7e1    	str	q1, [sp, #0xad0]
1000b9530: 785903b3    	ldurh	w19, [x29, #-0x70]
1000b9534: 3500be33    	cbnz	w19, 0x1000bacf8 <_machine.machine.Group.execute+0x22b8>
1000b9538: 385883a8    	ldurb	w8, [x29, #-0x78]
1000b953c: 36003d68    	tbz	w8, #0x0, 0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b9540: 1400030e    	b	0x1000ba178 <_machine.machine.Group.execute+0x1738>
1000b9544: d102c158    	sub	x24, x10, #0xb0
1000b9548: b0000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000b954c: 91042108    	add	x8, x8, #0x108
1000b9550: ad400500    	ldp	q0, q1, [x8]
1000b9554: 3d82ebe0    	str	q0, [sp, #0xba0]
1000b9558: 3d82efe1    	str	q1, [sp, #0xbb0]
1000b955c: f9402708    	ldr	x8, [x24, #0x48]
1000b9560: f1000504    	subs	x4, x8, #0x1
1000b9564: 5400cb43    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9568: f9400703    	ldr	x3, [x24, #0x8]
1000b956c: 912e83e2    	add	x2, sp, #0xba0
1000b9570: aa1503e0    	mov	x0, x21
1000b9574: aa1603e1    	mov	x1, x22
1000b9578: 52800025    	mov	w5, #0x1                ; =1
1000b957c: b0000ae6    	adrp	x6, 0x100216000 <___anon_77823+0x8>
1000b9580: 9103c0c6    	add	x6, x6, #0xf0
1000b9584: aa1b03e7    	mov	x7, x27
1000b9588: 97fffbd4    	bl	0x1000b84d8 <_machine.machine.Group.collect>
1000b958c: 72003c19    	ands	w25, w0, #0xffff
1000b9590: 5400bce1    	b.ne	0x1000bad2c <_machine.machine.Group.execute+0x22ec>
1000b9594: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9598: 3d80f3e0    	str	q0, [sp, #0x3c0]
1000b959c: f945d7e8    	ldr	x8, [sp, #0xba8]
1000b95a0: b1000502    	adds	x2, x8, #0x1
1000b95a4: 5400c942    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b95a8: 912e83e0    	add	x0, sp, #0xba0
1000b95ac: 910f03e1    	add	x1, sp, #0x3c0
1000b95b0: 97fdb04a    	bl	0x1000256d8 <_array_list.Aligned(machine.machine.Cleanup,null).ensureTotalCapacity>
1000b95b4: 72003c19    	ands	w25, w0, #0xffff
1000b95b8: 5400bd81    	b.ne	0x1000bad68 <_machine.machine.Group.execute+0x2328>
1000b95bc: f945d7e8    	ldr	x8, [sp, #0xba8]
1000b95c0: f945dbfa    	ldr	x26, [sp, #0xbb0]
1000b95c4: eb1a011f    	cmp	x8, x26
1000b95c8: 5400c9a2    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b95cc: 91000509    	add	x9, x8, #0x1
1000b95d0: f905d7e9    	str	x9, [sp, #0xba8]
1000b95d4: f945d3f7    	ldr	x23, [sp, #0xba0]
1000b95d8: 8b0816e8    	add	x8, x23, x8, lsl #5
1000b95dc: b0000ae9    	adrp	x9, 0x100216000 <___anon_77823+0x8>
1000b95e0: 911a6129    	add	x9, x9, #0x698
1000b95e4: ad400520    	ldp	q0, q1, [x9]
1000b95e8: ad000500    	stp	q0, q1, [x8]
1000b95ec: f9400302    	ldr	x2, [x24]
1000b95f0: f9406048    	ldr	x8, [x2, #0xc0]
1000b95f4: b1000508    	adds	x8, x8, #0x1
1000b95f8: 5400c6a2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b95fc: f9006048    	str	x8, [x2, #0xc0]
1000b9600: 3dc0bfe0    	ldr	q0, [sp, #0x2f0]
1000b9604: 3c9403a0    	stur	q0, [x29, #-0xc0]
1000b9608: a93553b3    	stp	x19, x20, [x29, #-0xb0]
1000b960c: 3dc2cbe0    	ldr	q0, [sp, #0xb20]
1000b9610: 3dc2cfe1    	ldr	q1, [sp, #0xb30]
1000b9614: d10303a9    	sub	x9, x29, #0xc0
1000b9618: ad010520    	stp	q0, q1, [x9, #0x20]
1000b961c: f945a3e8    	ldr	x8, [sp, #0xb40]
1000b9620: f8040128    	stur	x8, [x9, #0x40]
1000b9624: 52800068    	mov	w8, #0x3                ; =3
1000b9628: 381903a8    	sturb	w8, [x29, #-0x70]
1000b962c: 912e83e3    	add	x3, sp, #0xba0
1000b9630: d10303a4    	sub	x4, x29, #0xc0
1000b9634: aa1503e0    	mov	x0, x21
1000b9638: aa1603e1    	mov	x1, x22
1000b963c: 97fffc98    	bl	0x1000b889c <_machine.machine.Group.startCleanup>
1000b9640: 72003c19    	ands	w25, w0, #0xffff
1000b9644: 5400ba41    	b.ne	0x1000bad8c <_machine.machine.Group.execute+0x234c>
1000b9648: 913003e0    	add	x0, sp, #0xc00
1000b964c: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9650: 12000103    	and	w3, w8, #0x1
1000b9654: aa1503e1    	mov	x1, x21
1000b9658: aa1603e2    	mov	x2, x22
1000b965c: 94001698    	bl	0x1000bf0bc <_machine.machine.Group.nextCleanup>
1000b9660: 7958a3f9    	ldrh	w25, [sp, #0xc50]
1000b9664: 35005e19    	cbnz	w25, 0x1000ba224 <_machine.machine.Group.execute+0x17e4>
1000b9668: 3dc30be0    	ldr	q0, [sp, #0xc20]
1000b966c: 3dc30fe1    	ldr	q1, [sp, #0xc30]
1000b9670: 3d82dfe0    	str	q0, [sp, #0xb70]
1000b9674: 3d82e3e1    	str	q1, [sp, #0xb80]
1000b9678: f94623e8    	ldr	x8, [sp, #0xc40]
1000b967c: f905cbe8    	str	x8, [sp, #0xb90]
1000b9680: 3dc307e0    	ldr	q0, [sp, #0xc10]
1000b9684: 3dc303e1    	ldr	q1, [sp, #0xc00]
1000b9688: 3d82dbe0    	str	q0, [sp, #0xb60]
1000b968c: 3d82d7e1    	str	q1, [sp, #0xb50]
1000b9690: 397123e8    	ldrb	w8, [sp, #0xc48]
1000b9694: 360032a8    	tbz	w8, #0x0, 0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b9698: 14000318    	b	0x1000ba2f8 <_machine.machine.Group.execute+0x18b8>
1000b969c: f942cbe1    	ldr	x1, [sp, #0x590]
1000b96a0: f100243f    	cmp	x1, #0x9
1000b96a4: 5400c562    	b.hs	0x1000baf50 <_machine.machine.Group.execute+0x2510>
1000b96a8: 911003e0    	add	x0, sp, #0x400
1000b96ac: 94001b2e    	bl	0x1000c0364 <_machine.machine.stackSize>
1000b96b0: f9013aa0    	str	x0, [x21, #0x270]
1000b96b4: 912743e0    	add	x0, sp, #0x9d0
1000b96b8: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b96bc: 12000107    	and	w7, w8, #0x1
1000b96c0: aa1503e1    	mov	x1, x21
1000b96c4: aa1603e2    	mov	x2, x22
1000b96c8: aa1303e3    	mov	x3, x19
1000b96cc: aa1b03e4    	mov	x4, x27
1000b96d0: a94497e6    	ldp	x6, x5, [sp, #0x48]
1000b96d4: 97fffa3a    	bl	0x1000b7fbc <_machine.machine.Group.unwind>
1000b96d8: 795443f3    	ldrh	w19, [sp, #0xa20]
1000b96dc: 3500af93    	cbnz	w19, 0x1000baccc <_machine.machine.Group.execute+0x228c>
1000b96e0: 396863e8    	ldrb	w8, [sp, #0xa18]
1000b96e4: f9013abf    	str	xzr, [x21, #0x270]
1000b96e8: 36003008    	tbz	w8, #0x0, 0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b96ec: 140002ab    	b	0x1000ba198 <_machine.machine.Group.execute+0x1758>
1000b96f0: f9423aca    	ldr	x10, [x22, #0x470]
1000b96f4: 9101e14b    	add	x11, x10, #0x78
1000b96f8: f9400353    	ldr	x19, [x26]
1000b96fc: f940456a    	ldr	x10, [x11, #0x88]
1000b9700: b4002f0a    	cbz	x10, 0x1000b9ce0 <_machine.machine.Group.execute+0x12a0>
1000b9704: f940416b    	ldr	x11, [x11, #0x80]
1000b9708: 9100216b    	add	x11, x11, #0x8
1000b970c: 14000004    	b	0x1000b971c <_machine.machine.Group.execute+0xcdc>
1000b9710: 9100516b    	add	x11, x11, #0x14
1000b9714: f100054a    	subs	x10, x10, #0x1
1000b9718: 54002e40    	b.eq	0x1000b9ce0 <_machine.machine.Group.execute+0x12a0>
1000b971c: 3940216c    	ldrb	w12, [x11, #0x8]
1000b9720: 1200058c    	and	w12, w12, #0x3
1000b9724: 7100099f    	cmp	w12, #0x2
1000b9728: 54ffff41    	b.ne	0x1000b9710 <_machine.machine.Group.execute+0xcd0>
1000b972c: 297f316d    	ldp	w13, w12, [x11, #-0x8]
1000b9730: 6b1b01bf    	cmp	w13, w27
1000b9734: 7a4c9362    	ccmp	w27, w12, #0x2, ls
1000b9738: 54fffec8    	b.hi	0x1000b9710 <_machine.machine.Group.execute+0xcd0>
1000b973c: f940017c    	ldr	x28, [x11]
1000b9740: f940e6b4    	ldr	x20, [x21, #0x1c8]
1000b9744: b40027d4    	cbz	x20, 0x1000b9c3c <_machine.machine.Group.execute+0x11fc>
1000b9748: b4001b69    	cbz	x9, 0x1000b9ab4 <_machine.machine.Group.execute+0x1074>
1000b974c: 9100c128    	add	x8, x9, #0x30
1000b9750: 9100e129    	add	x9, x9, #0x38
1000b9754: 140000db    	b	0x1000b9ac0 <_machine.machine.Group.execute+0x1080>
1000b9758: f9423ac8    	ldr	x8, [x22, #0x470]
1000b975c: 9101e117    	add	x23, x8, #0x78
1000b9760: b9403b9b    	ldr	w27, [x28, #0x38]
1000b9764: f94036e1    	ldr	x1, [x23, #0x68]
1000b9768: eb1b003f    	cmp	x1, x27
1000b976c: 5400bc49    	b.ls	0x1000baef4 <_machine.machine.Group.execute+0x24b4>
1000b9770: f94032e8    	ldr	x8, [x23, #0x60]
1000b9774: 52800b09    	mov	w9, #0x58               ; =88
1000b9778: 9ba92368    	umaddl	x8, w27, w9, x8
1000b977c: f9400d14    	ldr	x20, [x8, #0x18]
1000b9780: d37dfe88    	lsr	x8, x20, #61
1000b9784: b5004748    	cbnz	x8, 0x1000ba06c <_machine.machine.Group.execute+0x162c>
1000b9788: f94017f3    	ldr	x19, [sp, #0x28]
1000b978c: dac143f3    	xpaci	x19
1000b9790: d37df299    	lsl	x25, x20, #3
1000b9794: b4000494    	cbz	x20, 0x1000b9824 <_machine.machine.Group.execute+0xde4>
1000b9798: a944a2a0    	ldp	x0, x8, [x21, #0x48]
1000b979c: f9400108    	ldr	x8, [x8]
1000b97a0: aa1903e1    	mov	x1, x25
1000b97a4: 52800062    	mov	w2, #0x3                ; =3
1000b97a8: aa1303e3    	mov	x3, x19
1000b97ac: d63f0100    	blr	x8
1000b97b0: b40045e0    	cbz	x0, 0x1000ba06c <_machine.machine.Group.execute+0x162c>
1000b97b4: aa0003f8    	mov	x24, x0
1000b97b8: 52801541    	mov	w1, #0xaa               ; =170
1000b97bc: aa1903e2    	mov	x2, x25
1000b97c0: 9405132f    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b97c4: f2400b1f    	tst	x24, #0x7
1000b97c8: 5400bbe1    	b.ne	0x1000baf44 <_machine.machine.Group.execute+0x2504>
1000b97cc: f9400b81    	ldr	x1, [x28, #0x10]
1000b97d0: eb01029f    	cmp	x20, x1
1000b97d4: 5400bb42    	b.hs	0x1000baf3c <_machine.machine.Group.execute+0x24fc>
1000b97d8: d2800008    	mov	x8, #0x0                ; =0
1000b97dc: f9400789    	ldr	x9, [x28, #0x8]
1000b97e0: 91002129    	add	x9, x9, #0x8
1000b97e4: f868792a    	ldr	x10, [x9, x8, lsl #3]
1000b97e8: f940614b    	ldr	x11, [x10, #0xc0]
1000b97ec: b100056b    	adds	x11, x11, #0x1
1000b97f0: 5400b6e2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b97f4: f900614b    	str	x11, [x10, #0xc0]
1000b97f8: f8287b0a    	str	x10, [x24, x8, lsl #3]
1000b97fc: 91000508    	add	x8, x8, #0x1
1000b9800: eb08029f    	cmp	x20, x8
1000b9804: 54ffff01    	b.ne	0x1000b97e4 <_machine.machine.Group.execute+0xda4>
1000b9808: aa1503e0    	mov	x0, x21
1000b980c: aa1603e1    	mov	x1, x22
1000b9810: 97feed7f    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b9814: f94036e1    	ldr	x1, [x23, #0x68]
1000b9818: eb1b003f    	cmp	x1, x27
1000b981c: 54000188    	b.hi	0x1000b984c <_machine.machine.Group.execute+0xe0c>
1000b9820: 140005b5    	b	0x1000baef4 <_machine.machine.Group.execute+0x24b4>
1000b9824: f9400b81    	ldr	x1, [x28, #0x10]
1000b9828: eb01029f    	cmp	x20, x1
1000b982c: 5400b882    	b.hs	0x1000baf3c <_machine.machine.Group.execute+0x24fc>
1000b9830: 928000f8    	mov	x24, #-0x8              ; =-8
1000b9834: aa1503e0    	mov	x0, x21
1000b9838: aa1603e1    	mov	x1, x22
1000b983c: 97feed74    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b9840: f94036e1    	ldr	x1, [x23, #0x68]
1000b9844: eb1b003f    	cmp	x1, x27
1000b9848: 5400b569    	b.ls	0x1000baef4 <_machine.machine.Group.execute+0x24b4>
1000b984c: 31000766    	adds	w6, w27, #0x1
1000b9850: 5400b3e2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9854: f94032e8    	ldr	x8, [x23, #0x60]
1000b9858: 52800b09    	mov	w9, #0x58               ; =88
1000b985c: 9ba92368    	umaddl	x8, w27, w9, x8
1000b9860: a9401504    	ldp	x4, x5, [x8]
1000b9864: f90003f4    	str	x20, [sp]
1000b9868: 910ff3e0    	add	x0, sp, #0x3fc
1000b986c: aa1503e1    	mov	x1, x21
1000b9870: aa1603e2    	mov	x2, x22
1000b9874: aa1a03e3    	mov	x3, x26
1000b9878: aa1803e7    	mov	x7, x24
1000b987c: 97ffc420    	bl	0x1000aa8fc <_machine.machine.Group.nextClause>
1000b9880: 7947fbf7    	ldrh	w23, [sp, #0x3fc]
1000b9884: 3500aab7    	cbnz	w23, 0x1000badd8 <_machine.machine.Group.execute+0x2398>
1000b9888: 394ffbe8    	ldrb	w8, [sp, #0x3fe]
1000b988c: 36000368    	tbz	w8, #0x0, 0x1000b98f8 <_machine.machine.Group.execute+0xeb8>
1000b9890: b4000274    	cbz	x20, 0x1000b98dc <_machine.machine.Group.execute+0xe9c>
1000b9894: d280001b    	mov	x27, #0x0               ; =0
1000b9898: a944eab7    	ldp	x23, x26, [x21, #0x48]
1000b989c: f87b7b00    	ldr	x0, [x24, x27, lsl #3]
1000b98a0: 97fea051    	bl	0x1000619e4 <_value.Value.release>
1000b98a4: 9100077b    	add	x27, x27, #0x1
1000b98a8: eb1b029f    	cmp	x20, x27
1000b98ac: 54ffff81    	b.ne	0x1000b989c <_machine.machine.Group.execute+0xe5c>
1000b98b0: aa1803e0    	mov	x0, x24
1000b98b4: 52801541    	mov	w1, #0xaa               ; =170
1000b98b8: aa1903e2    	mov	x2, x25
1000b98bc: 940512f0    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b98c0: f9400f48    	ldr	x8, [x26, #0x18]
1000b98c4: aa1703e0    	mov	x0, x23
1000b98c8: aa1803e1    	mov	x1, x24
1000b98cc: aa1903e2    	mov	x2, x25
1000b98d0: 52800063    	mov	w3, #0x3                ; =3
1000b98d4: aa1303e4    	mov	x4, x19
1000b98d8: d63f0100    	blr	x8
1000b98dc: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b98e0: 3d807be0    	str	q0, [sp, #0x1e0]
1000b98e4: a95e67f4    	ldp	x20, x25, [sp, #0x1e0]
1000b98e8: f942c7f7    	ldr	x23, [sp, #0x588]
1000b98ec: b40002b7    	cbz	x23, 0x1000b9940 <_machine.machine.Group.execute+0xf00>
1000b98f0: f942c3e8    	ldr	x8, [sp, #0x580]
1000b98f4: 14000018    	b	0x1000b9954 <_machine.machine.Group.execute+0xf14>
1000b98f8: f9404ec1    	ldr	x1, [x22, #0x98]
1000b98fc: f1000420    	subs	x0, x1, #0x1
1000b9900: 5400ae63    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9904: eb01001f    	cmp	x0, x1
1000b9908: 5400af42    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b990c: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9910: 52800909    	mov	w9, #0x48               ; =72
1000b9914: 9b092008    	madd	x8, x0, x9, x8
1000b9918: b9403d09    	ldr	w9, [x8, #0x3c]
1000b991c: 71000537    	subs	w23, w9, #0x1
1000b9920: 5400ad63    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9924: f9400108    	ldr	x8, [x8]
1000b9928: b4000468    	cbz	x8, 0x1000b99b4 <_machine.machine.Group.execute+0xf74>
1000b992c: 91018108    	add	x8, x8, #0x60
1000b9930: f9403d01    	ldr	x1, [x8, #0x78]
1000b9934: eb17003f    	cmp	x1, x23
1000b9938: 54000488    	b.hi	0x1000b99c8 <_machine.machine.Group.execute+0xf88>
1000b993c: 14000583    	b	0x1000baf48 <_machine.machine.Group.execute+0x2508>
1000b9940: f942cbf7    	ldr	x23, [sp, #0x590]
1000b9944: f10026ff    	cmp	x23, #0x9
1000b9948: 5400b0e2    	b.hs	0x1000baf64 <_machine.machine.Group.execute+0x2524>
1000b994c: b4ff8c57    	cbz	x23, 0x1000b8ad4 <_machine.machine.Group.execute+0x94>
1000b9950: 911003e8    	add	x8, sp, #0x400
1000b9954: 91008118    	add	x24, x8, #0x20
1000b9958: f85e0300    	ldur	x0, [x24, #-0x20]
1000b995c: 38430701    	ldrb	w1, [x24], #0x30
1000b9960: 910783e2    	add	x2, sp, #0x1e0
1000b9964: 97feee0b    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9968: f10006f7    	subs	x23, x23, #0x1
1000b996c: 54ffff61    	b.ne	0x1000b9958 <_machine.machine.Group.execute+0xf18>
1000b9970: f942c7e8    	ldr	x8, [sp, #0x588]
1000b9974: b4ff8b08    	cbz	x8, 0x1000b8ad4 <_machine.machine.Group.execute+0x94>
1000b9978: f942c3f7    	ldr	x23, [sp, #0x580]
1000b997c: 8b080508    	add	x8, x8, x8, lsl #1
1000b9980: d37ced18    	lsl	x24, x8, #4
1000b9984: aa1703e0    	mov	x0, x23
1000b9988: 52801541    	mov	w1, #0xaa               ; =170
1000b998c: aa1803e2    	mov	x2, x24
1000b9990: 940512bb    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b9994: f9400f28    	ldr	x8, [x25, #0x18]
1000b9998: aa1403e0    	mov	x0, x20
1000b999c: aa1703e1    	mov	x1, x23
1000b99a0: aa1803e2    	mov	x2, x24
1000b99a4: 52800083    	mov	w3, #0x4                ; =4
1000b99a8: aa1303e4    	mov	x4, x19
1000b99ac: d63f0100    	blr	x8
1000b99b0: 17fffc49    	b	0x1000b8ad4 <_machine.machine.Group.execute+0x94>
1000b99b4: f9423ac8    	ldr	x8, [x22, #0x470]
1000b99b8: 9101e108    	add	x8, x8, #0x78
1000b99bc: f9403d01    	ldr	x1, [x8, #0x78]
1000b99c0: eb17003f    	cmp	x1, x23
1000b99c4: 5400ac29    	b.ls	0x1000baf48 <_machine.machine.Group.execute+0x2508>
1000b99c8: f9403908    	ldr	x8, [x8, #0x70]
1000b99cc: 52800609    	mov	w9, #0x30               ; =48
1000b99d0: 9ba922e8    	umaddl	x8, w23, w9, x8
1000b99d4: ad400500    	ldp	q0, q1, [x8]
1000b99d8: 3d824fe0    	str	q0, [sp, #0x930]
1000b99dc: 3d8253e1    	str	q1, [sp, #0x940]
1000b99e0: 3dc00900    	ldr	q0, [x8, #0x20]
1000b99e4: 3d8257e0    	str	q0, [sp, #0x950]
1000b99e8: aa1503e0    	mov	x0, x21
1000b99ec: b0000c61    	adrp	x1, 0x100246000 <___anon_79250+0x48>
1000b99f0: 910d5c21    	add	x1, x1, #0x357
1000b99f4: 52800102    	mov	w2, #0x8                ; =8
1000b99f8: 52800103    	mov	w3, #0x8                ; =8
1000b99fc: d2800004    	mov	x4, #0x0                ; =0
1000b9a00: 940132a8    	bl	0x1001064a0 <_machine.machine.Group.raise>
1000b9a04: 12001c08    	and	w8, w0, #0xff
1000b9a08: 71028d1f    	cmp	w8, #0xa3
1000b9a0c: 54005621    	b.ne	0x1000ba4d0 <_machine.machine.Group.execute+0x1a90>
1000b9a10: 9125a3e0    	add	x0, sp, #0x968
1000b9a14: 9124c3e3    	add	x3, sp, #0x930
1000b9a18: aa1503e1    	mov	x1, x21
1000b9a1c: aa1603e2    	mov	x2, x22
1000b9a20: 97fff5b3    	bl	0x1000b70ec <_machine.machine.Group.completeError>
1000b9a24: 7952e3fa    	ldrh	w26, [sp, #0x970]
1000b9a28: 3500a21a    	cbnz	w26, 0x1000bae68 <_machine.machine.Group.execute+0x2428>
1000b9a2c: f944b7e3    	ldr	x3, [sp, #0x968]
1000b9a30: b94953e5    	ldr	w5, [sp, #0x950]
1000b9a34: b94957e6    	ldr	w6, [sp, #0x954]
1000b9a38: 9125e3e0    	add	x0, sp, #0x978
1000b9a3c: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9a40: 12000107    	and	w7, w8, #0x1
1000b9a44: aa1503e1    	mov	x1, x21
1000b9a48: aa1603e2    	mov	x2, x22
1000b9a4c: aa1703e4    	mov	x4, x23
1000b9a50: 97fff95b    	bl	0x1000b7fbc <_machine.machine.Group.unwind>
1000b9a54: 795393f7    	ldrh	w23, [sp, #0x9c8]
1000b9a58: 3500a257    	cbnz	w23, 0x1000baea0 <_machine.machine.Group.execute+0x2460>
1000b9a5c: 396703e8    	ldrb	w8, [sp, #0x9c0]
1000b9a60: 37005588    	tbnz	w8, #0x0, 0x1000ba510 <_machine.machine.Group.execute+0x1ad0>
1000b9a64: b4001434    	cbz	x20, 0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b9a68: d280001b    	mov	x27, #0x0               ; =0
1000b9a6c: a944eab7    	ldp	x23, x26, [x21, #0x48]
1000b9a70: f87b7b00    	ldr	x0, [x24, x27, lsl #3]
1000b9a74: 97fe9fdc    	bl	0x1000619e4 <_value.Value.release>
1000b9a78: 9100077b    	add	x27, x27, #0x1
1000b9a7c: eb1b029f    	cmp	x20, x27
1000b9a80: 54ffff81    	b.ne	0x1000b9a70 <_machine.machine.Group.execute+0x1030>
1000b9a84: aa1803e0    	mov	x0, x24
1000b9a88: 52801541    	mov	w1, #0xaa               ; =170
1000b9a8c: aa1903e2    	mov	x2, x25
1000b9a90: 9405127b    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b9a94: f9400f48    	ldr	x8, [x26, #0x18]
1000b9a98: aa1703e0    	mov	x0, x23
1000b9a9c: aa1803e1    	mov	x1, x24
1000b9aa0: aa1903e2    	mov	x2, x25
1000b9aa4: 52800063    	mov	w3, #0x3                ; =3
1000b9aa8: aa1303e4    	mov	x4, x19
1000b9aac: d63f0100    	blr	x8
1000b9ab0: 1400008e    	b	0x1000b9ce8 <_machine.machine.Group.execute+0x12a8>
1000b9ab4: f9423ac9    	ldr	x9, [x22, #0x470]
1000b9ab8: 9106c128    	add	x8, x9, #0x1b0
1000b9abc: 9106e129    	add	x9, x9, #0x1b8
1000b9ac0: f9423ed9    	ldr	x25, [x22, #0x478]
1000b9ac4: f94242da    	ldr	x26, [x22, #0x480]
1000b9ac8: f9400137    	ldr	x23, [x9]
1000b9acc: f9400118    	ldr	x24, [x8]
1000b9ad0: aa1403e0    	mov	x0, x20
1000b9ad4: b0000ae1    	adrp	x1, 0x100216000 <___anon_77823+0x8>
1000b9ad8: 912c8021    	add	x1, x1, #0xb20
1000b9adc: 52800162    	mov	w2, #0xb                ; =11
1000b9ae0: 97fd1fb8    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9ae4: 72003c1f    	tst	w0, #0xffff
1000b9ae8: 54000921    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9aec: aa1403e0    	mov	x0, x20
1000b9af0: aa1903e1    	mov	x1, x25
1000b9af4: aa1a03e2    	mov	x2, x26
1000b9af8: 97fd1fb2    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9afc: 72003c1f    	tst	w0, #0xffff
1000b9b00: 54000861    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9b04: aa1403e0    	mov	x0, x20
1000b9b08: b0000ae1    	adrp	x1, 0x100216000 <___anon_77823+0x8>
1000b9b0c: 912cac21    	add	x1, x1, #0xb2b
1000b9b10: 52800082    	mov	w2, #0x4                ; =4
1000b9b14: 97fd1fab    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b18: 72003c1f    	tst	w0, #0xffff
1000b9b1c: 54000781    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9b20: aa1403e0    	mov	x0, x20
1000b9b24: aa1803e1    	mov	x1, x24
1000b9b28: aa1703e2    	mov	x2, x23
1000b9b2c: 97fd1fa5    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b30: 72003c1f    	tst	w0, #0xffff
1000b9b34: 540006c1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9b38: aa1403e0    	mov	x0, x20
1000b9b3c: f0000a21    	adrp	x1, 0x100200000 <_writev+0x100200000>
1000b9b40: 91278c21    	add	x1, x1, #0x9e3
1000b9b44: 52800022    	mov	w2, #0x1                ; =1
1000b9b48: 97fd1f9e    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b4c: 72003c1f    	tst	w0, #0xffff
1000b9b50: 540005e1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9b54: aa1403e0    	mov	x0, x20
1000b9b58: aa1b03e1    	mov	x1, x27
1000b9b5c: 52800142    	mov	w2, #0xa                ; =10
1000b9b60: 52800003    	mov	w3, #0x0                ; =0
1000b9b64: f0000a24    	adrp	x4, 0x100200000 <_writev+0x100200000>
1000b9b68: 9125e084    	add	x4, x4, #0x978
1000b9b6c: 97fd43dc    	bl	0x10000aadc <_Io.Writer.printIntAny__func_56>
1000b9b70: 72003c1f    	tst	w0, #0xffff
1000b9b74: 540004c1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9b78: aa1403e0    	mov	x0, x20
1000b9b7c: b0000ae1    	adrp	x1, 0x100216000 <___anon_77823+0x8>
1000b9b80: 912cbc21    	add	x1, x1, #0xb2f
1000b9b84: 528000a2    	mov	w2, #0x5                ; =5
1000b9b88: 97fd1f8e    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b8c: 72003c1f    	tst	w0, #0xffff
1000b9b90: 540003e1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9b94: aa1403e0    	mov	x0, x20
1000b9b98: f9402be1    	ldr	x1, [sp, #0x50]
1000b9b9c: 52800142    	mov	w2, #0xa                ; =10
1000b9ba0: 52800003    	mov	w3, #0x0                ; =0
1000b9ba4: f0000a24    	adrp	x4, 0x100200000 <_writev+0x100200000>
1000b9ba8: 9125e084    	add	x4, x4, #0x978
1000b9bac: 97fd43cc    	bl	0x10000aadc <_Io.Writer.printIntAny__func_56>
1000b9bb0: 72003c1f    	tst	w0, #0xffff
1000b9bb4: 540002c1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9bb8: aa1403e0    	mov	x0, x20
1000b9bbc: f0000a21    	adrp	x1, 0x100200000 <_writev+0x100200000>
1000b9bc0: 91278c21    	add	x1, x1, #0x9e3
1000b9bc4: 52800022    	mov	w2, #0x1                ; =1
1000b9bc8: 97fd1f7e    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9bcc: 72003c1f    	tst	w0, #0xffff
1000b9bd0: 540001e1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9bd4: aa1403e0    	mov	x0, x20
1000b9bd8: f94027e1    	ldr	x1, [sp, #0x48]
1000b9bdc: 52800142    	mov	w2, #0xa                ; =10
1000b9be0: 52800003    	mov	w3, #0x0                ; =0
1000b9be4: f0000a24    	adrp	x4, 0x100200000 <_writev+0x100200000>
1000b9be8: 9125e084    	add	x4, x4, #0x978
1000b9bec: 97fd43bc    	bl	0x10000aadc <_Io.Writer.printIntAny__func_56>
1000b9bf0: 72003c1f    	tst	w0, #0xffff
1000b9bf4: 540000c1    	b.ne	0x1000b9c0c <_machine.machine.Group.execute+0x11cc>
1000b9bf8: aa1403e0    	mov	x0, x20
1000b9bfc: b0000aa1    	adrp	x1, 0x10020e000 <___anon_49097+0xe0>
1000b9c00: 911bdc21    	add	x1, x1, #0x6f7
1000b9c04: 528000e2    	mov	w2, #0x7                ; =7
1000b9c08: 97fd1f6e    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9c0c: aa1403e0    	mov	x0, x20
1000b9c10: aa1303e1    	mov	x1, x19
1000b9c14: 52800022    	mov	w2, #0x1                ; =1
1000b9c18: 97fe7e0f    	bl	0x100059454 <_display.writeWith>
1000b9c1c: aa1403e0    	mov	x0, x20
1000b9c20: 90000c41    	adrp	x1, 0x100241000 <___anon_2200+0x7a>
1000b9c24: 9124fc21    	add	x1, x1, #0x93f
1000b9c28: 52800022    	mov	w2, #0x1                ; =1
1000b9c2c: 97fd1f65    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9c30: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9c34: f1000420    	subs	x0, x1, #0x1
1000b9c38: 1a9f27e8    	cset	w8, lo
1000b9c3c: 37009488    	tbnz	w8, #0x0, 0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9c40: eb01001f    	cmp	x0, x1
1000b9c44: 54009562    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b9c48: d360ff94    	lsr	x20, x28, #32
1000b9c4c: f9404ac9    	ldr	x9, [x22, #0x90]
1000b9c50: 5280090a    	mov	w10, #0x48              ; =72
1000b9c54: 9b0a2417    	madd	x23, x0, x10, x9
1000b9c58: f94012e9    	ldr	x9, [x23, #0x20]
1000b9c5c: eb14013f    	cmp	x9, x20
1000b9c60: 54000329    	b.ls	0x1000b9cc4 <_machine.machine.Group.execute+0x1284>
1000b9c64: f9401ae8    	ldr	x8, [x23, #0x30]
1000b9c68: b50094a8    	cbnz	x8, 0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b9c6c: f9400ee8    	ldr	x8, [x23, #0x18]
1000b9c70: 5280060a    	mov	w10, #0x30              ; =48
1000b9c74: 9b0a2128    	madd	x8, x9, x10, x8
1000b9c78: f85d0100    	ldur	x0, [x8, #-0x30]
1000b9c7c: 385f0101    	ldurb	w1, [x8, #-0x10]
1000b9c80: 4f05e540    	movi.16b	v0, #0xaa
1000b9c84: ad3e8100    	stp	q0, q0, [x8, #-0x30]
1000b9c88: 3c9f0100    	stur	q0, [x8, #-0x10]
1000b9c8c: f94012e8    	ldr	x8, [x23, #0x20]
1000b9c90: f1000508    	subs	x8, x8, #0x1
1000b9c94: 540091c3    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9c98: f90012e8    	str	x8, [x23, #0x20]
1000b9c9c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9ca0: 3d8303e0    	str	q0, [sp, #0xc00]
1000b9ca4: 913003e2    	add	x2, sp, #0xc00
1000b9ca8: 97feed3a    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9cac: f94012e9    	ldr	x9, [x23, #0x20]
1000b9cb0: eb14013f    	cmp	x9, x20
1000b9cb4: 54fffd88    	b.hi	0x1000b9c64 <_machine.machine.Group.execute+0x1224>
1000b9cb8: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9cbc: f1000420    	subs	x0, x1, #0x1
1000b9cc0: 1a9f27e8    	cset	w8, lo
1000b9cc4: 37009048    	tbnz	w8, #0x0, 0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9cc8: eb01001f    	cmp	x0, x1
1000b9ccc: 54009122    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b9cd0: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9cd4: 52800909    	mov	w9, #0x48               ; =72
1000b9cd8: 9b092008    	madd	x8, x0, x9, x8
1000b9cdc: b9003d1c    	str	w28, [x8, #0x3c]
1000b9ce0: aa1303e0    	mov	x0, x19
1000b9ce4: 97fe9f40    	bl	0x1000619e4 <_value.Value.release>
1000b9ce8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9cec: 3d80d7e0    	str	q0, [sp, #0x350]
1000b9cf0: f941abf3    	ldr	x19, [sp, #0x350]
1000b9cf4: f941aff8    	ldr	x24, [sp, #0x358]
1000b9cf8: f942c7f4    	ldr	x20, [sp, #0x588]
1000b9cfc: b4000074    	cbz	x20, 0x1000b9d08 <_machine.machine.Group.execute+0x12c8>
1000b9d00: f942c3e8    	ldr	x8, [sp, #0x580]
1000b9d04: 14000006    	b	0x1000b9d1c <_machine.machine.Group.execute+0x12dc>
1000b9d08: f942cbf4    	ldr	x20, [sp, #0x590]
1000b9d0c: f100269f    	cmp	x20, #0x9
1000b9d10: 54008f82    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b9d14: b4ff6e14    	cbz	x20, 0x1000b8ad4 <_machine.machine.Group.execute+0x94>
1000b9d18: 911003e8    	add	x8, sp, #0x400
1000b9d1c: 91008117    	add	x23, x8, #0x20
1000b9d20: f85e02e0    	ldur	x0, [x23, #-0x20]
1000b9d24: 384306e1    	ldrb	w1, [x23], #0x30
1000b9d28: 910d43e2    	add	x2, sp, #0x350
1000b9d2c: 97feed19    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9d30: f1000694    	subs	x20, x20, #0x1
1000b9d34: 54ffff61    	b.ne	0x1000b9d20 <_machine.machine.Group.execute+0x12e0>
1000b9d38: f942c7e8    	ldr	x8, [sp, #0x588]
1000b9d3c: b4ff6cc8    	cbz	x8, 0x1000b8ad4 <_machine.machine.Group.execute+0x94>
1000b9d40: f942c3f4    	ldr	x20, [sp, #0x580]
1000b9d44: 8b080508    	add	x8, x8, x8, lsl #1
1000b9d48: d37ced17    	lsl	x23, x8, #4
1000b9d4c: aa1403e0    	mov	x0, x20
1000b9d50: 52801541    	mov	w1, #0xaa               ; =170
1000b9d54: aa1703e2    	mov	x2, x23
1000b9d58: 940511c9    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b9d5c: f94017e4    	ldr	x4, [sp, #0x28]
1000b9d60: dac143e4    	xpaci	x4
1000b9d64: f9400f08    	ldr	x8, [x24, #0x18]
1000b9d68: aa1303e0    	mov	x0, x19
1000b9d6c: aa1403e1    	mov	x1, x20
1000b9d70: aa1703e2    	mov	x2, x23
1000b9d74: 52800083    	mov	w3, #0x4                ; =4
1000b9d78: d63f0100    	blr	x8
1000b9d7c: 17fffb56    	b	0x1000b8ad4 <_machine.machine.Group.execute+0x94>
1000b9d80: aa1503e0    	mov	x0, x21
1000b9d84: aa1603e1    	mov	x1, x22
1000b9d88: 97feec21    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b9d8c: f9404ec8    	ldr	x8, [x22, #0x98]
1000b9d90: b5ffff88    	cbnz	x8, 0x1000b9d80 <_machine.machine.Group.execute+0x1340>
1000b9d94: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9d98: 3d80cfe0    	str	q0, [sp, #0x330]
1000b9d9c: f9419bf3    	ldr	x19, [sp, #0x330]
1000b9da0: f9419ff6    	ldr	x22, [sp, #0x338]
1000b9da4: f942c7f4    	ldr	x20, [sp, #0x588]
1000b9da8: b4004794    	cbz	x20, 0x1000ba698 <_machine.machine.Group.execute+0x1c58>
1000b9dac: f942c3e8    	ldr	x8, [sp, #0x580]
1000b9db0: 1400023f    	b	0x1000ba6ac <_machine.machine.Group.execute+0x1c6c>
1000b9db4: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9db8: f1000420    	subs	x0, x1, #0x1
1000b9dbc: 54008883    	b.lo	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9dc0: eb01001f    	cmp	x0, x1
1000b9dc4: 54008962    	b.hs	0x1000baef0 <_machine.machine.Group.execute+0x24b0>
1000b9dc8: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9dcc: 52800909    	mov	w9, #0x48               ; =72
1000b9dd0: 9b092008    	madd	x8, x0, x9, x8
1000b9dd4: b9003d1b    	str	w27, [x8, #0x3c]
1000b9dd8: f94313e0    	ldr	x0, [sp, #0x620]
1000b9ddc: b4000040    	cbz	x0, 0x1000b9de4 <_machine.machine.Group.execute+0x13a4>
1000b9de0: 97fe9f01    	bl	0x1000619e4 <_value.Value.release>
1000b9de4: f94317e0    	ldr	x0, [sp, #0x628]
1000b9de8: f9400ff3    	ldr	x19, [sp, #0x18]
1000b9dec: b4000040    	cbz	x0, 0x1000b9df4 <_machine.machine.Group.execute+0x13b4>
1000b9df0: 97fe9efd    	bl	0x1000619e4 <_value.Value.release>
1000b9df4: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000b9df8: 3d819be1    	str	q1, [sp, #0x660]
1000b9dfc: 3d819fe0    	str	q0, [sp, #0x670]
1000b9e00: f90343f7    	str	x23, [sp, #0x680]
1000b9e04: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000b9e08: 3d818be1    	str	q1, [sp, #0x620]
1000b9e0c: 3d818fe0    	str	q0, [sp, #0x630]
1000b9e10: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000b9e14: 3d8197e1    	str	q1, [sp, #0x650]
1000b9e18: 3d8193e0    	str	q0, [sp, #0x640]
1000b9e1c: 7900927f    	strh	wzr, [x19, #0x48]
1000b9e20: 52800188    	mov	w8, #0xc                ; =12
1000b9e24: 39010268    	strb	w8, [x19, #0x40]
1000b9e28: 52800048    	mov	w8, #0x2                ; =2
1000b9e2c: 39000268    	strb	w8, [x19]
1000b9e30: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9e34: 3d804fe0    	str	q0, [sp, #0x130]
1000b9e38: a9535bf3    	ldp	x19, x22, [sp, #0x130]
1000b9e3c: f942c7f4    	ldr	x20, [sp, #0x588]
1000b9e40: b40000f4    	cbz	x20, 0x1000b9e5c <_machine.machine.Group.execute+0x141c>
1000b9e44: f942c3e8    	ldr	x8, [sp, #0x580]
1000b9e48: 1400000a    	b	0x1000b9e70 <_machine.machine.Group.execute+0x1430>
1000b9e4c: f902badf    	str	xzr, [x22, #0x570]
1000b9e50: b0000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000b9e54: 91218108    	add	x8, x8, #0x860
1000b9e58: 1400022f    	b	0x1000ba714 <_machine.machine.Group.execute+0x1cd4>
1000b9e5c: f942cbf4    	ldr	x20, [sp, #0x590]
1000b9e60: f100269f    	cmp	x20, #0x9
1000b9e64: 540084e2    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b9e68: b4006474    	cbz	x20, 0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000b9e6c: 911003e8    	add	x8, sp, #0x400
1000b9e70: 91008115    	add	x21, x8, #0x20
1000b9e74: f85e02a0    	ldur	x0, [x21, #-0x20]
1000b9e78: 384306a1    	ldrb	w1, [x21], #0x30
1000b9e7c: 9104c3e2    	add	x2, sp, #0x130
1000b9e80: 97feecc4    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9e84: f1000694    	subs	x20, x20, #0x1
1000b9e88: 54ffff61    	b.ne	0x1000b9e74 <_machine.machine.Group.execute+0x1434>
1000b9e8c: f942c7e8    	ldr	x8, [sp, #0x588]
1000b9e90: b4006328    	cbz	x8, 0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000b9e94: f942c3f4    	ldr	x20, [sp, #0x580]
1000b9e98: 8b080508    	add	x8, x8, x8, lsl #1
1000b9e9c: d37ced15    	lsl	x21, x8, #4
1000b9ea0: aa1403e0    	mov	x0, x20
1000b9ea4: 52801541    	mov	w1, #0xaa               ; =170
1000b9ea8: aa1503e2    	mov	x2, x21
1000b9eac: 94051174    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b9eb0: f94017e4    	ldr	x4, [sp, #0x28]
1000b9eb4: dac143e4    	xpaci	x4
1000b9eb8: f9400ec8    	ldr	x8, [x22, #0x18]
1000b9ebc: aa1303e0    	mov	x0, x19
1000b9ec0: aa1403e1    	mov	x1, x20
1000b9ec4: aa1503e2    	mov	x2, x21
1000b9ec8: 52800083    	mov	w3, #0x4                ; =4
1000b9ecc: d63f0100    	blr	x8
1000b9ed0: 14000309    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000b9ed4: 3940013c    	ldrb	w28, [x9]
1000b9ed8: 12000b88    	and	w8, w28, #0x7
1000b9edc: 7100051f    	cmp	w8, #0x1
1000b9ee0: 540003a8    	b.hi	0x1000b9f54 <_machine.machine.Group.execute+0x1514>
1000b9ee4: 395a0be8    	ldrb	w8, [sp, #0x682]
1000b9ee8: 36000368    	tbz	w8, #0x0, 0x1000b9f54 <_machine.machine.Group.execute+0x1514>
1000b9eec: 3dc19be0    	ldr	q0, [sp, #0x660]
1000b9ef0: 3dc19fe1    	ldr	q1, [sp, #0x670]
1000b9ef4: 3d821fe0    	str	q0, [sp, #0x870]
1000b9ef8: 3d8223e1    	str	q1, [sp, #0x880]
1000b9efc: f94343e8    	ldr	x8, [sp, #0x680]
1000b9f00: f9044be8    	str	x8, [sp, #0x890]
1000b9f04: 3dc18be0    	ldr	q0, [sp, #0x620]
1000b9f08: 3dc18fe1    	ldr	q1, [sp, #0x630]
1000b9f0c: 3d820fe0    	str	q0, [sp, #0x830]
1000b9f10: 3d8213e1    	str	q1, [sp, #0x840]
1000b9f14: 3dc197e0    	ldr	q0, [sp, #0x650]
1000b9f18: 3dc193e1    	ldr	q1, [sp, #0x640]
1000b9f1c: 3d821be0    	str	q0, [sp, #0x860]
1000b9f20: 3d8217e1    	str	q1, [sp, #0x850]
1000b9f24: f9041fff    	str	xzr, [sp, #0x838]
1000b9f28: f9405ad8    	ldr	x24, [x22, #0xb0]
1000b9f2c: 910543e0    	add	x0, sp, #0x150
1000b9f30: 9120c3e2    	add	x2, sp, #0x830
1000b9f34: aa1303e1    	mov	x1, x19
1000b9f38: 94012bfb    	bl	0x100104f24 <_machine.costs.chargeInstruction>
1000b9f3c: f940abe8    	ldr	x8, [sp, #0x150]
1000b9f40: ab140108    	adds	x8, x8, x20
1000b9f44: 54007c42    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9f48: ab080308    	adds	x8, x24, x8
1000b9f4c: 54007c02    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000b9f50: f9005ac8    	str	x8, [x22, #0xb0]
1000b9f54: f94313e0    	ldr	x0, [sp, #0x620]
1000b9f58: b4000040    	cbz	x0, 0x1000b9f60 <_machine.machine.Group.execute+0x1520>
1000b9f5c: 97fe9ea2    	bl	0x1000619e4 <_value.Value.release>
1000b9f60: f94317e0    	ldr	x0, [sp, #0x628]
1000b9f64: b4000040    	cbz	x0, 0x1000b9f6c <_machine.machine.Group.execute+0x152c>
1000b9f68: 97fe9e9f    	bl	0x1000619e4 <_value.Value.release>
1000b9f6c: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000b9f70: 3d819be1    	str	q1, [sp, #0x660]
1000b9f74: 3d819fe0    	str	q0, [sp, #0x670]
1000b9f78: f90343f7    	str	x23, [sp, #0x680]
1000b9f7c: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000b9f80: 3d818be1    	str	q1, [sp, #0x620]
1000b9f84: 3d818fe0    	str	q0, [sp, #0x630]
1000b9f88: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000b9f8c: 3d8197e1    	str	q1, [sp, #0x650]
1000b9f90: 3d8193e0    	str	q0, [sp, #0x640]
1000b9f94: 39412348    	ldrb	w8, [x26, #0x48]
1000b9f98: 11001509    	add	w9, w8, #0x5
1000b9f9c: 53010d2a    	ubfx	w10, w9, #1, #3
1000b9fa0: 2a090d49    	orr	w9, w10, w9, lsl #3
1000b9fa4: 12000d29    	and	w9, w9, #0xf
1000b9fa8: 51000d2a    	sub	w10, w9, #0x3
1000b9fac: 7100095f    	cmp	w10, #0x2
1000b9fb0: 540007e3    	b.lo	0x1000ba0ac <_machine.machine.Group.execute+0x166c>
1000b9fb4: 340007c9    	cbz	w9, 0x1000ba0ac <_machine.machine.Group.execute+0x166c>
1000b9fb8: 7100193f    	cmp	w9, #0x6
1000b9fbc: 54002181    	b.ne	0x1000ba3ec <_machine.machine.Group.execute+0x19ac>
1000b9fc0: f9400f58    	ldr	x24, [x26, #0x18]
1000b9fc4: b40021b8    	cbz	x24, 0x1000ba3f8 <_machine.machine.Group.execute+0x19b8>
1000b9fc8: d2800019    	mov	x25, #0x0               ; =0
1000b9fcc: f9400b53    	ldr	x19, [x26, #0x10]
1000b9fd0: a944d2b7    	ldp	x23, x20, [x21, #0x48]
1000b9fd4: f8797a60    	ldr	x0, [x19, x25, lsl #3]
1000b9fd8: 97fe9e83    	bl	0x1000619e4 <_value.Value.release>
1000b9fdc: 91000739    	add	x25, x25, #0x1
1000b9fe0: eb19031f    	cmp	x24, x25
1000b9fe4: 54ffff81    	b.ne	0x1000b9fd4 <_machine.machine.Group.execute+0x1594>
1000b9fe8: d37df31a    	lsl	x26, x24, #3
1000b9fec: aa1303e0    	mov	x0, x19
1000b9ff0: 52801541    	mov	w1, #0xaa               ; =170
1000b9ff4: aa1a03e2    	mov	x2, x26
1000b9ff8: 94051121    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000b9ffc: f94017e4    	ldr	x4, [sp, #0x28]
1000ba000: dac143e4    	xpaci	x4
1000ba004: f9400e88    	ldr	x8, [x20, #0x18]
1000ba008: aa1703e0    	mov	x0, x23
1000ba00c: aa1303e1    	mov	x1, x19
1000ba010: aa1a03e2    	mov	x2, x26
1000ba014: 52800063    	mov	w3, #0x3                ; =3
1000ba018: d63f0100    	blr	x8
1000ba01c: 140000f7    	b	0x1000ba3f8 <_machine.machine.Group.execute+0x19b8>
1000ba020: aa1503e0    	mov	x0, x21
1000ba024: aa1603e1    	mov	x1, x22
1000ba028: 97feeb79    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000ba02c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba030: 3d806be0    	str	q0, [sp, #0x1a0]
1000ba034: a95a5bf3    	ldp	x19, x22, [sp, #0x1a0]
1000ba038: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba03c: b40016f4    	cbz	x20, 0x1000ba318 <_machine.machine.Group.execute+0x18d8>
1000ba040: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba044: 140000ba    	b	0x1000ba32c <_machine.machine.Group.execute+0x18ec>
1000ba048: 52800008    	mov	w8, #0x0                ; =0
1000ba04c: 14000002    	b	0x1000ba054 <_machine.machine.Group.execute+0x1614>
1000ba050: 52800028    	mov	w8, #0x1                ; =1
1000ba054: f9400fea    	ldr	x10, [sp, #0x18]
1000ba058: 7900915f    	strh	wzr, [x10, #0x48]
1000ba05c: 52800189    	mov	w9, #0xc                ; =12
1000ba060: 39010149    	strb	w9, [x10, #0x40]
1000ba064: 39000148    	strb	w8, [x10]
1000ba068: 140002a3    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba06c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba070: 3d806fe0    	str	q0, [sp, #0x1b0]
1000ba074: 911003e0    	add	x0, sp, #0x400
1000ba078: 9106c3e1    	add	x1, sp, #0x1b0
1000ba07c: 9400284e    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000ba080: 528000a8    	mov	w8, #0x5                ; =5
1000ba084: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba088: 79009128    	strh	w8, [x9, #0x48]
1000ba08c: 1400029a    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba090: 394682c8    	ldrb	w8, [x22, #0x1a0]
1000ba094: 7100051f    	cmp	w8, #0x1
1000ba098: 5400180c    	b.gt	0x1000ba398 <_machine.machine.Group.execute+0x1958>
1000ba09c: 35001888    	cbnz	w8, 0x1000ba3ac <_machine.machine.Group.execute+0x196c>
1000ba0a0: 90000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000ba0a4: 9122c108    	add	x8, x8, #0x8b0
1000ba0a8: 1400019b    	b	0x1000ba714 <_machine.machine.Group.execute+0x1cd4>
1000ba0ac: f9400340    	ldr	x0, [x26]
1000ba0b0: 97fe9e4d    	bl	0x1000619e4 <_value.Value.release>
1000ba0b4: 140000d1    	b	0x1000ba3f8 <_machine.machine.Group.execute+0x19b8>
1000ba0b8: f9400353    	ldr	x19, [x26]
1000ba0bc: f9404ec8    	ldr	x8, [x22, #0x98]
1000ba0c0: b40000c8    	cbz	x8, 0x1000ba0d8 <_machine.machine.Group.execute+0x1698>
1000ba0c4: aa1503e0    	mov	x0, x21
1000ba0c8: aa1603e1    	mov	x1, x22
1000ba0cc: 97feeb50    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000ba0d0: f9404ec8    	ldr	x8, [x22, #0x98]
1000ba0d4: b5ffff88    	cbnz	x8, 0x1000ba0c4 <_machine.machine.Group.execute+0x1684>
1000ba0d8: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba0dc: 7900913f    	strh	wzr, [x9, #0x48]
1000ba0e0: 52800168    	mov	w8, #0xb                ; =11
1000ba0e4: 39010128    	strb	w8, [x9, #0x40]
1000ba0e8: f9000133    	str	x19, [x9]
1000ba0ec: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba0f0: 3d80d3e0    	str	q0, [sp, #0x340]
1000ba0f4: f941a3f3    	ldr	x19, [sp, #0x340]
1000ba0f8: f941a7f6    	ldr	x22, [sp, #0x348]
1000ba0fc: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba100: b4002734    	cbz	x20, 0x1000ba5e4 <_machine.machine.Group.execute+0x1ba4>
1000ba104: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba108: 1400013c    	b	0x1000ba5f8 <_machine.machine.Group.execute+0x1bb8>
1000ba10c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba110: 3d80cbe0    	str	q0, [sp, #0x320]
1000ba114: f94193f3    	ldr	x19, [sp, #0x320]
1000ba118: f94197f6    	ldr	x22, [sp, #0x328]
1000ba11c: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba120: b40027d4    	cbz	x20, 0x1000ba618 <_machine.machine.Group.execute+0x1bd8>
1000ba124: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba128: 14000141    	b	0x1000ba62c <_machine.machine.Group.execute+0x1bec>
1000ba12c: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba130: 7900911f    	strh	wzr, [x8, #0x48]
1000ba134: 3901011f    	strb	wzr, [x8, #0x40]
1000ba138: f9000113    	str	x19, [x8]
1000ba13c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba140: 3d8063e0    	str	q0, [sp, #0x180]
1000ba144: a9585bf3    	ldp	x19, x22, [sp, #0x180]
1000ba148: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba14c: b4002f54    	cbz	x20, 0x1000ba734 <_machine.machine.Group.execute+0x1cf4>
1000ba150: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba154: 1400017d    	b	0x1000ba748 <_machine.machine.Group.execute+0x1d08>
1000ba158: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba15c: 3d80abe0    	str	q0, [sp, #0x2a0]
1000ba160: f94153f3    	ldr	x19, [sp, #0x2a0]
1000ba164: f94157f6    	ldr	x22, [sp, #0x2a8]
1000ba168: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba16c: b4002ff4    	cbz	x20, 0x1000ba768 <_machine.machine.Group.execute+0x1d28>
1000ba170: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba174: 14000182    	b	0x1000ba77c <_machine.machine.Group.execute+0x1d3c>
1000ba178: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba17c: 3d80bbe0    	str	q0, [sp, #0x2e0]
1000ba180: f94173f3    	ldr	x19, [sp, #0x2e0]
1000ba184: f94177f6    	ldr	x22, [sp, #0x2e8]
1000ba188: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba18c: b4003394    	cbz	x20, 0x1000ba7fc <_machine.machine.Group.execute+0x1dbc>
1000ba190: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba194: 1400019f    	b	0x1000ba810 <_machine.machine.Group.execute+0x1dd0>
1000ba198: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba19c: 3d80a3e0    	str	q0, [sp, #0x280]
1000ba1a0: f94143f3    	ldr	x19, [sp, #0x280]
1000ba1a4: f94147f6    	ldr	x22, [sp, #0x288]
1000ba1a8: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba1ac: b4003754    	cbz	x20, 0x1000ba894 <_machine.machine.Group.execute+0x1e54>
1000ba1b0: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba1b4: 140001bd    	b	0x1000ba8a8 <_machine.machine.Group.execute+0x1e68>
1000ba1b8: f941cfe8    	ldr	x8, [sp, #0x398]
1000ba1bc: b5006a08    	cbnz	x8, 0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000ba1c0: f941cbe8    	ldr	x8, [sp, #0x390]
1000ba1c4: b4000208    	cbz	x8, 0x1000ba204 <_machine.machine.Group.execute+0x17c4>
1000ba1c8: a944e2b3    	ldp	x19, x24, [x21, #0x48]
1000ba1cc: d37be914    	lsl	x20, x8, #5
1000ba1d0: f941c3f6    	ldr	x22, [sp, #0x380]
1000ba1d4: aa1603e0    	mov	x0, x22
1000ba1d8: 52801541    	mov	w1, #0xaa               ; =170
1000ba1dc: aa1403e2    	mov	x2, x20
1000ba1e0: 940510a7    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba1e4: f94017e4    	ldr	x4, [sp, #0x28]
1000ba1e8: dac143e4    	xpaci	x4
1000ba1ec: f9400f08    	ldr	x8, [x24, #0x18]
1000ba1f0: aa1303e0    	mov	x0, x19
1000ba1f4: aa1603e1    	mov	x1, x22
1000ba1f8: aa1403e2    	mov	x2, x20
1000ba1fc: 52800063    	mov	w3, #0x3                ; =3
1000ba200: d63f0100    	blr	x8
1000ba204: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba208: 3d80afe0    	str	q0, [sp, #0x2b0]
1000ba20c: 911003e0    	add	x0, sp, #0x400
1000ba210: 910ac3e1    	add	x1, sp, #0x2b0
1000ba214: 940027e8    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000ba218: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba21c: 79009117    	strh	w23, [x8, #0x48]
1000ba220: 14000235    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba224: f945dfe8    	ldr	x8, [sp, #0xbb8]
1000ba228: b50066a8    	cbnz	x8, 0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000ba22c: a944eeb6    	ldp	x22, x27, [x21, #0x48]
1000ba230: d37beb58    	lsl	x24, x26, #5
1000ba234: aa1703e0    	mov	x0, x23
1000ba238: 52801541    	mov	w1, #0xaa               ; =170
1000ba23c: aa1803e2    	mov	x2, x24
1000ba240: 9405108f    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba244: f94017e4    	ldr	x4, [sp, #0x28]
1000ba248: dac143e4    	xpaci	x4
1000ba24c: f9400f68    	ldr	x8, [x27, #0x18]
1000ba250: aa1603e0    	mov	x0, x22
1000ba254: aa1703e1    	mov	x1, x23
1000ba258: aa1803e2    	mov	x2, x24
1000ba25c: 52800063    	mov	w3, #0x3                ; =3
1000ba260: aa0403fa    	mov	x26, x4
1000ba264: d63f0100    	blr	x8
1000ba268: b4000294    	cbz	x20, 0x1000ba2b8 <_machine.machine.Group.execute+0x1878>
1000ba26c: d2800018    	mov	x24, #0x0               ; =0
1000ba270: a944deb6    	ldp	x22, x23, [x21, #0x48]
1000ba274: f8787a60    	ldr	x0, [x19, x24, lsl #3]
1000ba278: 97fe9ddb    	bl	0x1000619e4 <_value.Value.release>
1000ba27c: 91000718    	add	x24, x24, #0x1
1000ba280: eb18029f    	cmp	x20, x24
1000ba284: 54ffff81    	b.ne	0x1000ba274 <_machine.machine.Group.execute+0x1834>
1000ba288: d37df294    	lsl	x20, x20, #3
1000ba28c: aa1303e0    	mov	x0, x19
1000ba290: 52801541    	mov	w1, #0xaa               ; =170
1000ba294: aa1403e2    	mov	x2, x20
1000ba298: 94051079    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba29c: f9400ee8    	ldr	x8, [x23, #0x18]
1000ba2a0: aa1603e0    	mov	x0, x22
1000ba2a4: aa1303e1    	mov	x1, x19
1000ba2a8: aa1403e2    	mov	x2, x20
1000ba2ac: 52800063    	mov	w3, #0x3                ; =3
1000ba2b0: aa1a03e4    	mov	x4, x26
1000ba2b4: d63f0100    	blr	x8
1000ba2b8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba2bc: 3d80c3e0    	str	q0, [sp, #0x300]
1000ba2c0: 911003e0    	add	x0, sp, #0x400
1000ba2c4: 910c03e1    	add	x1, sp, #0x300
1000ba2c8: 940027bb    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000ba2cc: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba2d0: 79009119    	strh	w25, [x8, #0x48]
1000ba2d4: 14000208    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba2d8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba2dc: 3d80b3e0    	str	q0, [sp, #0x2c0]
1000ba2e0: f94163f3    	ldr	x19, [sp, #0x2c0]
1000ba2e4: f94167f6    	ldr	x22, [sp, #0x2c8]
1000ba2e8: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba2ec: b4003214    	cbz	x20, 0x1000ba92c <_machine.machine.Group.execute+0x1eec>
1000ba2f0: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba2f4: 14000193    	b	0x1000ba940 <_machine.machine.Group.execute+0x1f00>
1000ba2f8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba2fc: 3d80c7e0    	str	q0, [sp, #0x310]
1000ba300: f9418bf3    	ldr	x19, [sp, #0x310]
1000ba304: f9418ff6    	ldr	x22, [sp, #0x318]
1000ba308: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba30c: b40035d4    	cbz	x20, 0x1000ba9c4 <_machine.machine.Group.execute+0x1f84>
1000ba310: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba314: 140001b1    	b	0x1000ba9d8 <_machine.machine.Group.execute+0x1f98>
1000ba318: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba31c: f100269f    	cmp	x20, #0x9
1000ba320: 54005f02    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba324: b4000354    	cbz	x20, 0x1000ba38c <_machine.machine.Group.execute+0x194c>
1000ba328: 911003e8    	add	x8, sp, #0x400
1000ba32c: 91008115    	add	x21, x8, #0x20
1000ba330: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba334: 384306a1    	ldrb	w1, [x21], #0x30
1000ba338: 910683e2    	add	x2, sp, #0x1a0
1000ba33c: 97feeb95    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba340: f1000694    	subs	x20, x20, #0x1
1000ba344: 54ffff61    	b.ne	0x1000ba330 <_machine.machine.Group.execute+0x18f0>
1000ba348: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba34c: b4000208    	cbz	x8, 0x1000ba38c <_machine.machine.Group.execute+0x194c>
1000ba350: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba354: 8b080508    	add	x8, x8, x8, lsl #1
1000ba358: d37ced15    	lsl	x21, x8, #4
1000ba35c: aa1403e0    	mov	x0, x20
1000ba360: 52801541    	mov	w1, #0xaa               ; =170
1000ba364: aa1503e2    	mov	x2, x21
1000ba368: 94051045    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba36c: f94017e4    	ldr	x4, [sp, #0x28]
1000ba370: dac143e4    	xpaci	x4
1000ba374: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba378: aa1303e0    	mov	x0, x19
1000ba37c: aa1403e1    	mov	x1, x20
1000ba380: aa1503e2    	mov	x2, x21
1000ba384: 52800083    	mov	w3, #0x4                ; =4
1000ba388: d63f0100    	blr	x8
1000ba38c: 90000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000ba390: 91256108    	add	x8, x8, #0x958
1000ba394: 140000e0    	b	0x1000ba714 <_machine.machine.Group.execute+0x1cd4>
1000ba398: 7100091f    	cmp	w8, #0x2
1000ba39c: 54005bc1    	b.ne	0x1000baf14 <_machine.machine.Group.execute+0x24d4>
1000ba3a0: 90000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000ba3a4: 91240108    	add	x8, x8, #0x900
1000ba3a8: 140000db    	b	0x1000ba714 <_machine.machine.Group.execute+0x1cd4>
1000ba3ac: 6f00e400    	movi.2d	v0, #0000000000000000
1000ba3b0: ad0c82c0    	stp	q0, q0, [x22, #0x190]
1000ba3b4: 911683e0    	add	x0, sp, #0x5a0
1000ba3b8: aa1503e1    	mov	x1, x21
1000ba3bc: aa1603e2    	mov	x2, x22
1000ba3c0: 94013273    	bl	0x100106d8c <_machine.machine.Group.landedCancel>
1000ba3c4: 3dc173e0    	ldr	q0, [sp, #0x5c0]
1000ba3c8: 3dc177e1    	ldr	q1, [sp, #0x5d0]
1000ba3cc: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba3d0: ad010500    	stp	q0, q1, [x8, #0x20]
1000ba3d4: 3dc17be0    	ldr	q0, [sp, #0x5e0]
1000ba3d8: 3d801100    	str	q0, [x8, #0x40]
1000ba3dc: 3dc16fe0    	ldr	q0, [sp, #0x5b0]
1000ba3e0: 3dc16be1    	ldr	q1, [sp, #0x5a0]
1000ba3e4: ad000101    	stp	q1, q0, [x8]
1000ba3e8: 140001c3    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba3ec: 12000d08    	and	w8, w8, #0xf
1000ba3f0: 7100351f    	cmp	w8, #0xd
1000ba3f4: 54005902    	b.hs	0x1000baf14 <_machine.machine.Group.execute+0x24d4>
1000ba3f8: a9449fe8    	ldp	x8, x7, [sp, #0x48]
1000ba3fc: b90003e8    	str	w8, [sp]
1000ba400: 912283e0    	add	x0, sp, #0x8a0
1000ba404: aa1503e1    	mov	x1, x21
1000ba408: aa1603e2    	mov	x2, x22
1000ba40c: aa1c03e3    	mov	x3, x28
1000ba410: a94313e5    	ldp	x5, x4, [sp, #0x30]
1000ba414: aa1b03e6    	mov	x6, x27
1000ba418: 940024f1    	bl	0x1000c37dc <_machine.machine.Group.limitFault>
1000ba41c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba420: 3d805be0    	str	q0, [sp, #0x160]
1000ba424: a9565bf3    	ldp	x19, x22, [sp, #0x160]
1000ba428: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba42c: b4000074    	cbz	x20, 0x1000ba438 <_machine.machine.Group.execute+0x19f8>
1000ba430: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba434: 14000006    	b	0x1000ba44c <_machine.machine.Group.execute+0x1a0c>
1000ba438: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba43c: f100269f    	cmp	x20, #0x9
1000ba440: 54005602    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba444: b4000354    	cbz	x20, 0x1000ba4ac <_machine.machine.Group.execute+0x1a6c>
1000ba448: 911003e8    	add	x8, sp, #0x400
1000ba44c: 91008115    	add	x21, x8, #0x20
1000ba450: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba454: 384306a1    	ldrb	w1, [x21], #0x30
1000ba458: 910583e2    	add	x2, sp, #0x160
1000ba45c: 97feeb4d    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba460: f1000694    	subs	x20, x20, #0x1
1000ba464: 54ffff61    	b.ne	0x1000ba450 <_machine.machine.Group.execute+0x1a10>
1000ba468: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba46c: b4000208    	cbz	x8, 0x1000ba4ac <_machine.machine.Group.execute+0x1a6c>
1000ba470: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba474: 8b080508    	add	x8, x8, x8, lsl #1
1000ba478: d37ced15    	lsl	x21, x8, #4
1000ba47c: aa1403e0    	mov	x0, x20
1000ba480: 52801541    	mov	w1, #0xaa               ; =170
1000ba484: aa1503e2    	mov	x2, x21
1000ba488: 94050ffd    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba48c: f94017e4    	ldr	x4, [sp, #0x28]
1000ba490: dac143e4    	xpaci	x4
1000ba494: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba498: aa1303e0    	mov	x0, x19
1000ba49c: aa1403e1    	mov	x1, x20
1000ba4a0: aa1503e2    	mov	x2, x21
1000ba4a4: 52800083    	mov	w3, #0x4                ; =4
1000ba4a8: d63f0100    	blr	x8
1000ba4ac: 3dc233e0    	ldr	q0, [sp, #0x8c0]
1000ba4b0: 3dc237e1    	ldr	q1, [sp, #0x8d0]
1000ba4b4: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba4b8: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba4bc: f94473e8    	ldr	x8, [sp, #0x8e0]
1000ba4c0: f9002128    	str	x8, [x9, #0x40]
1000ba4c4: 3dc22fe0    	ldr	q0, [sp, #0x8b0]
1000ba4c8: 3dc22be1    	ldr	q1, [sp, #0x8a0]
1000ba4cc: 14000188    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000ba4d0: 7100151f    	cmp	w8, #0x5
1000ba4d4: 54005201    	b.ne	0x1000baf14 <_machine.machine.Group.execute+0x24d4>
1000ba4d8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba4dc: 3d807fe0    	str	q0, [sp, #0x1f0]
1000ba4e0: 9107c3e2    	add	x2, sp, #0x1f0
1000ba4e4: aa1803e0    	mov	x0, x24
1000ba4e8: aa1403e1    	mov	x1, x20
1000ba4ec: 97fee709    	bl	0x100074110 <_machine.machine.releaseAll>
1000ba4f0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba4f4: 3d8083e0    	str	q0, [sp, #0x200]
1000ba4f8: 911003e0    	add	x0, sp, #0x400
1000ba4fc: 910803e1    	add	x1, sp, #0x200
1000ba500: 9400272d    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000ba504: 90000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000ba508: 9126a108    	add	x8, x8, #0x9a8
1000ba50c: 14000082    	b	0x1000ba714 <_machine.machine.Group.execute+0x1cd4>
1000ba510: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba514: 3d8097e0    	str	q0, [sp, #0x250]
1000ba518: 910943e2    	add	x2, sp, #0x250
1000ba51c: aa1803e0    	mov	x0, x24
1000ba520: aa1403e1    	mov	x1, x20
1000ba524: 97fee6fb    	bl	0x100074110 <_machine.machine.releaseAll>
1000ba528: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba52c: 3d809be0    	str	q0, [sp, #0x260]
1000ba530: 911003e0    	add	x0, sp, #0x400
1000ba534: 910983e1    	add	x1, sp, #0x260
1000ba538: 9400271f    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000ba53c: 911a23ea    	add	x10, sp, #0x688
1000ba540: ad588540    	ldp	q0, q1, [x10, #0x310]
1000ba544: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba548: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba54c: f944dfe8    	ldr	x8, [sp, #0x9b8]
1000ba550: f9002128    	str	x8, [x9, #0x40]
1000ba554: ad578141    	ldp	q1, q0, [x10, #0x2f0]
1000ba558: 14000165    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000ba55c: f94313e0    	ldr	x0, [sp, #0x620]
1000ba560: b4000040    	cbz	x0, 0x1000ba568 <_machine.machine.Group.execute+0x1b28>
1000ba564: 97fe9d20    	bl	0x1000619e4 <_value.Value.release>
1000ba568: f94317e0    	ldr	x0, [sp, #0x628]
1000ba56c: f9401bf3    	ldr	x19, [sp, #0x30]
1000ba570: b4000040    	cbz	x0, 0x1000ba578 <_machine.machine.Group.execute+0x1b38>
1000ba574: 97fe9d1c    	bl	0x1000619e4 <_value.Value.release>
1000ba578: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000ba57c: 3d819be1    	str	q1, [sp, #0x660]
1000ba580: 3d819fe0    	str	q0, [sp, #0x670]
1000ba584: f90343f7    	str	x23, [sp, #0x680]
1000ba588: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000ba58c: 3d818be1    	str	q1, [sp, #0x620]
1000ba590: 3d818fe0    	str	q0, [sp, #0x630]
1000ba594: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000ba598: 3d8197e1    	str	q1, [sp, #0x650]
1000ba59c: 3d8193e0    	str	q0, [sp, #0x640]
1000ba5a0: a9449fe8    	ldp	x8, x7, [sp, #0x48]
1000ba5a4: b90003e8    	str	w8, [sp]
1000ba5a8: 9123a3e0    	add	x0, sp, #0x8e8
1000ba5ac: aa1503e1    	mov	x1, x21
1000ba5b0: aa1603e2    	mov	x2, x22
1000ba5b4: 52800043    	mov	w3, #0x2                ; =2
1000ba5b8: f9401fe4    	ldr	x4, [sp, #0x38]
1000ba5bc: aa1303e5    	mov	x5, x19
1000ba5c0: aa1b03e6    	mov	x6, x27
1000ba5c4: 94002486    	bl	0x1000c37dc <_machine.machine.Group.limitFault>
1000ba5c8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba5cc: 3d805fe0    	str	q0, [sp, #0x170]
1000ba5d0: a9575bf3    	ldp	x19, x22, [sp, #0x170]
1000ba5d4: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba5d8: b4002434    	cbz	x20, 0x1000baa5c <_machine.machine.Group.execute+0x201c>
1000ba5dc: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba5e0: 14000124    	b	0x1000baa70 <_machine.machine.Group.execute+0x2030>
1000ba5e4: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba5e8: f100269f    	cmp	x20, #0x9
1000ba5ec: 540048a2    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba5f0: b4002834    	cbz	x20, 0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba5f4: 911003e8    	add	x8, sp, #0x400
1000ba5f8: 91008115    	add	x21, x8, #0x20
1000ba5fc: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba600: 384306a1    	ldrb	w1, [x21], #0x30
1000ba604: 910d03e2    	add	x2, sp, #0x340
1000ba608: 97feeae2    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba60c: f1000694    	subs	x20, x20, #0x1
1000ba610: 54ffff61    	b.ne	0x1000ba5fc <_machine.machine.Group.execute+0x1bbc>
1000ba614: 17fffe1e    	b	0x1000b9e8c <_machine.machine.Group.execute+0x144c>
1000ba618: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba61c: f100269f    	cmp	x20, #0x9
1000ba620: 54004702    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba624: b4000354    	cbz	x20, 0x1000ba68c <_machine.machine.Group.execute+0x1c4c>
1000ba628: 911003e8    	add	x8, sp, #0x400
1000ba62c: 91008115    	add	x21, x8, #0x20
1000ba630: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba634: 384306a1    	ldrb	w1, [x21], #0x30
1000ba638: 910c83e2    	add	x2, sp, #0x320
1000ba63c: 97feead5    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba640: f1000694    	subs	x20, x20, #0x1
1000ba644: 54ffff61    	b.ne	0x1000ba630 <_machine.machine.Group.execute+0x1bf0>
1000ba648: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba64c: b4000208    	cbz	x8, 0x1000ba68c <_machine.machine.Group.execute+0x1c4c>
1000ba650: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba654: 8b080508    	add	x8, x8, x8, lsl #1
1000ba658: d37ced15    	lsl	x21, x8, #4
1000ba65c: aa1403e0    	mov	x0, x20
1000ba660: 52801541    	mov	w1, #0xaa               ; =170
1000ba664: aa1503e2    	mov	x2, x21
1000ba668: 94050f85    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba66c: f94017e4    	ldr	x4, [sp, #0x28]
1000ba670: dac143e4    	xpaci	x4
1000ba674: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba678: aa1303e0    	mov	x0, x19
1000ba67c: aa1403e1    	mov	x1, x20
1000ba680: aa1503e2    	mov	x2, x21
1000ba684: 52800083    	mov	w3, #0x4                ; =4
1000ba688: d63f0100    	blr	x8
1000ba68c: 90000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000ba690: 9127e108    	add	x8, x8, #0x9f8
1000ba694: 14000020    	b	0x1000ba714 <_machine.machine.Group.execute+0x1cd4>
1000ba698: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba69c: f100269f    	cmp	x20, #0x9
1000ba6a0: 54004302    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba6a4: b4000354    	cbz	x20, 0x1000ba70c <_machine.machine.Group.execute+0x1ccc>
1000ba6a8: 911003e8    	add	x8, sp, #0x400
1000ba6ac: 91008115    	add	x21, x8, #0x20
1000ba6b0: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba6b4: 384306a1    	ldrb	w1, [x21], #0x30
1000ba6b8: 910cc3e2    	add	x2, sp, #0x330
1000ba6bc: 97feeab5    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba6c0: f1000694    	subs	x20, x20, #0x1
1000ba6c4: 54ffff61    	b.ne	0x1000ba6b0 <_machine.machine.Group.execute+0x1c70>
1000ba6c8: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba6cc: b4000208    	cbz	x8, 0x1000ba70c <_machine.machine.Group.execute+0x1ccc>
1000ba6d0: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba6d4: 8b080508    	add	x8, x8, x8, lsl #1
1000ba6d8: d37ced15    	lsl	x21, x8, #4
1000ba6dc: aa1403e0    	mov	x0, x20
1000ba6e0: 52801541    	mov	w1, #0xaa               ; =170
1000ba6e4: aa1503e2    	mov	x2, x21
1000ba6e8: 94050f65    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba6ec: f94017e4    	ldr	x4, [sp, #0x28]
1000ba6f0: dac143e4    	xpaci	x4
1000ba6f4: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba6f8: aa1303e0    	mov	x0, x19
1000ba6fc: aa1403e1    	mov	x1, x20
1000ba700: aa1503e2    	mov	x2, x21
1000ba704: 52800083    	mov	w3, #0x4                ; =4
1000ba708: d63f0100    	blr	x8
1000ba70c: 90000ae8    	adrp	x8, 0x100216000 <___anon_77823+0x8>
1000ba710: 91292108    	add	x8, x8, #0xa48
1000ba714: ad410500    	ldp	q0, q1, [x8, #0x20]
1000ba718: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba71c: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba720: 3dc01100    	ldr	q0, [x8, #0x40]
1000ba724: 3d801120    	str	q0, [x9, #0x40]
1000ba728: ad400101    	ldp	q1, q0, [x8]
1000ba72c: ad000121    	stp	q1, q0, [x9]
1000ba730: 140000f1    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba734: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba738: f100269f    	cmp	x20, #0x9
1000ba73c: 54003e22    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba740: b4001db4    	cbz	x20, 0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000ba744: 911003e8    	add	x8, sp, #0x400
1000ba748: 91008115    	add	x21, x8, #0x20
1000ba74c: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba750: 384306a1    	ldrb	w1, [x21], #0x30
1000ba754: 910603e2    	add	x2, sp, #0x180
1000ba758: 97feea8e    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba75c: f1000694    	subs	x20, x20, #0x1
1000ba760: 54ffff61    	b.ne	0x1000ba74c <_machine.machine.Group.execute+0x1d0c>
1000ba764: 17fffdca    	b	0x1000b9e8c <_machine.machine.Group.execute+0x144c>
1000ba768: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba76c: f100269f    	cmp	x20, #0x9
1000ba770: 54003c82    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba774: b4000354    	cbz	x20, 0x1000ba7dc <_machine.machine.Group.execute+0x1d9c>
1000ba778: 911003e8    	add	x8, sp, #0x400
1000ba77c: 91008115    	add	x21, x8, #0x20
1000ba780: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba784: 384306a1    	ldrb	w1, [x21], #0x30
1000ba788: 910a83e2    	add	x2, sp, #0x2a0
1000ba78c: 97feea81    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba790: f1000694    	subs	x20, x20, #0x1
1000ba794: 54ffff61    	b.ne	0x1000ba780 <_machine.machine.Group.execute+0x1d40>
1000ba798: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba79c: b4000208    	cbz	x8, 0x1000ba7dc <_machine.machine.Group.execute+0x1d9c>
1000ba7a0: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba7a4: 8b080508    	add	x8, x8, x8, lsl #1
1000ba7a8: d37ced15    	lsl	x21, x8, #4
1000ba7ac: aa1403e0    	mov	x0, x20
1000ba7b0: 52801541    	mov	w1, #0xaa               ; =170
1000ba7b4: aa1503e2    	mov	x2, x21
1000ba7b8: 94050f31    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba7bc: f94017e4    	ldr	x4, [sp, #0x28]
1000ba7c0: dac143e4    	xpaci	x4
1000ba7c4: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba7c8: aa1303e0    	mov	x0, x19
1000ba7cc: aa1403e1    	mov	x1, x20
1000ba7d0: aa1503e2    	mov	x2, x21
1000ba7d4: 52800083    	mov	w3, #0x4                ; =4
1000ba7d8: d63f0100    	blr	x8
1000ba7dc: 911a23ea    	add	x10, sp, #0x688
1000ba7e0: ad5e0540    	ldp	q0, q1, [x10, #0x3c0]
1000ba7e4: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba7e8: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba7ec: f94537e8    	ldr	x8, [sp, #0xa68]
1000ba7f0: f9002128    	str	x8, [x9, #0x40]
1000ba7f4: ad5d0141    	ldp	q1, q0, [x10, #0x3a0]
1000ba7f8: 140000bd    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000ba7fc: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba800: f100269f    	cmp	x20, #0x9
1000ba804: 540037e2    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba808: b4000354    	cbz	x20, 0x1000ba870 <_machine.machine.Group.execute+0x1e30>
1000ba80c: 911003e8    	add	x8, sp, #0x400
1000ba810: 91008115    	add	x21, x8, #0x20
1000ba814: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba818: 384306a1    	ldrb	w1, [x21], #0x30
1000ba81c: 910b83e2    	add	x2, sp, #0x2e0
1000ba820: 97feea5c    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba824: f1000694    	subs	x20, x20, #0x1
1000ba828: 54ffff61    	b.ne	0x1000ba814 <_machine.machine.Group.execute+0x1dd4>
1000ba82c: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba830: b4000208    	cbz	x8, 0x1000ba870 <_machine.machine.Group.execute+0x1e30>
1000ba834: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba838: 8b080508    	add	x8, x8, x8, lsl #1
1000ba83c: d37ced15    	lsl	x21, x8, #4
1000ba840: aa1403e0    	mov	x0, x20
1000ba844: 52801541    	mov	w1, #0xaa               ; =170
1000ba848: aa1503e2    	mov	x2, x21
1000ba84c: 94050f0c    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba850: f94017e4    	ldr	x4, [sp, #0x28]
1000ba854: dac143e4    	xpaci	x4
1000ba858: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba85c: aa1303e0    	mov	x0, x19
1000ba860: aa1403e1    	mov	x1, x20
1000ba864: aa1503e2    	mov	x2, x21
1000ba868: 52800083    	mov	w3, #0x4                ; =4
1000ba86c: d63f0100    	blr	x8
1000ba870: 3dc2bfe0    	ldr	q0, [sp, #0xaf0]
1000ba874: 3dc2c3e1    	ldr	q1, [sp, #0xb00]
1000ba878: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba87c: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba880: f9458be8    	ldr	x8, [sp, #0xb10]
1000ba884: f9002128    	str	x8, [x9, #0x40]
1000ba888: 3dc2bbe0    	ldr	q0, [sp, #0xae0]
1000ba88c: 3dc2b7e1    	ldr	q1, [sp, #0xad0]
1000ba890: 14000097    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000ba894: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba898: f100269f    	cmp	x20, #0x9
1000ba89c: 54003322    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba8a0: b4000354    	cbz	x20, 0x1000ba908 <_machine.machine.Group.execute+0x1ec8>
1000ba8a4: 911003e8    	add	x8, sp, #0x400
1000ba8a8: 91008115    	add	x21, x8, #0x20
1000ba8ac: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba8b0: 384306a1    	ldrb	w1, [x21], #0x30
1000ba8b4: 910a03e2    	add	x2, sp, #0x280
1000ba8b8: 97feea36    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba8bc: f1000694    	subs	x20, x20, #0x1
1000ba8c0: 54ffff61    	b.ne	0x1000ba8ac <_machine.machine.Group.execute+0x1e6c>
1000ba8c4: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba8c8: b4000208    	cbz	x8, 0x1000ba908 <_machine.machine.Group.execute+0x1ec8>
1000ba8cc: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba8d0: 8b080508    	add	x8, x8, x8, lsl #1
1000ba8d4: d37ced15    	lsl	x21, x8, #4
1000ba8d8: aa1403e0    	mov	x0, x20
1000ba8dc: 52801541    	mov	w1, #0xaa               ; =170
1000ba8e0: aa1503e2    	mov	x2, x21
1000ba8e4: 94050ee6    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba8e8: f94017e4    	ldr	x4, [sp, #0x28]
1000ba8ec: dac143e4    	xpaci	x4
1000ba8f0: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba8f4: aa1303e0    	mov	x0, x19
1000ba8f8: aa1403e1    	mov	x1, x20
1000ba8fc: aa1503e2    	mov	x2, x21
1000ba900: 52800083    	mov	w3, #0x4                ; =4
1000ba904: d63f0100    	blr	x8
1000ba908: 3dc27fe0    	ldr	q0, [sp, #0x9f0]
1000ba90c: 3dc283e1    	ldr	q1, [sp, #0xa00]
1000ba910: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba914: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba918: f9450be8    	ldr	x8, [sp, #0xa10]
1000ba91c: f9002128    	str	x8, [x9, #0x40]
1000ba920: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1000ba924: 3dc277e1    	ldr	q1, [sp, #0x9d0]
1000ba928: 14000071    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000ba92c: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba930: f100269f    	cmp	x20, #0x9
1000ba934: 54002e62    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba938: b4000354    	cbz	x20, 0x1000ba9a0 <_machine.machine.Group.execute+0x1f60>
1000ba93c: 911003e8    	add	x8, sp, #0x400
1000ba940: 91008115    	add	x21, x8, #0x20
1000ba944: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba948: 384306a1    	ldrb	w1, [x21], #0x30
1000ba94c: 910b03e2    	add	x2, sp, #0x2c0
1000ba950: 97feea10    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba954: f1000694    	subs	x20, x20, #0x1
1000ba958: 54ffff61    	b.ne	0x1000ba944 <_machine.machine.Group.execute+0x1f04>
1000ba95c: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba960: b4000208    	cbz	x8, 0x1000ba9a0 <_machine.machine.Group.execute+0x1f60>
1000ba964: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba968: 8b080508    	add	x8, x8, x8, lsl #1
1000ba96c: d37ced15    	lsl	x21, x8, #4
1000ba970: aa1403e0    	mov	x0, x20
1000ba974: 52801541    	mov	w1, #0xaa               ; =170
1000ba978: aa1503e2    	mov	x2, x21
1000ba97c: 94050ec0    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000ba980: f94017e4    	ldr	x4, [sp, #0x28]
1000ba984: dac143e4    	xpaci	x4
1000ba988: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba98c: aa1303e0    	mov	x0, x19
1000ba990: aa1403e1    	mov	x1, x20
1000ba994: aa1503e2    	mov	x2, x21
1000ba998: 52800083    	mov	w3, #0x4                ; =4
1000ba99c: d63f0100    	blr	x8
1000ba9a0: 3dc2abe0    	ldr	q0, [sp, #0xaa0]
1000ba9a4: 3dc2afe1    	ldr	q1, [sp, #0xab0]
1000ba9a8: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba9ac: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba9b0: f94563e8    	ldr	x8, [sp, #0xac0]
1000ba9b4: f9002128    	str	x8, [x9, #0x40]
1000ba9b8: 3dc2a7e0    	ldr	q0, [sp, #0xa90]
1000ba9bc: 3dc2a3e1    	ldr	q1, [sp, #0xa80]
1000ba9c0: 1400004b    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000ba9c4: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba9c8: f100269f    	cmp	x20, #0x9
1000ba9cc: 540029a2    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000ba9d0: b4000354    	cbz	x20, 0x1000baa38 <_machine.machine.Group.execute+0x1ff8>
1000ba9d4: 911003e8    	add	x8, sp, #0x400
1000ba9d8: 91008115    	add	x21, x8, #0x20
1000ba9dc: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba9e0: 384306a1    	ldrb	w1, [x21], #0x30
1000ba9e4: 910c43e2    	add	x2, sp, #0x310
1000ba9e8: 97fee9ea    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba9ec: f1000694    	subs	x20, x20, #0x1
1000ba9f0: 54ffff61    	b.ne	0x1000ba9dc <_machine.machine.Group.execute+0x1f9c>
1000ba9f4: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba9f8: b4000208    	cbz	x8, 0x1000baa38 <_machine.machine.Group.execute+0x1ff8>
1000ba9fc: f942c3f4    	ldr	x20, [sp, #0x580]
1000baa00: 8b080508    	add	x8, x8, x8, lsl #1
1000baa04: d37ced15    	lsl	x21, x8, #4
1000baa08: aa1403e0    	mov	x0, x20
1000baa0c: 52801541    	mov	w1, #0xaa               ; =170
1000baa10: aa1503e2    	mov	x2, x21
1000baa14: 94050e9a    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000baa18: f94017e4    	ldr	x4, [sp, #0x28]
1000baa1c: dac143e4    	xpaci	x4
1000baa20: f9400ec8    	ldr	x8, [x22, #0x18]
1000baa24: aa1303e0    	mov	x0, x19
1000baa28: aa1403e1    	mov	x1, x20
1000baa2c: aa1503e2    	mov	x2, x21
1000baa30: 52800083    	mov	w3, #0x4                ; =4
1000baa34: d63f0100    	blr	x8
1000baa38: 3dc2dfe0    	ldr	q0, [sp, #0xb70]
1000baa3c: 3dc2e3e1    	ldr	q1, [sp, #0xb80]
1000baa40: f9400fe9    	ldr	x9, [sp, #0x18]
1000baa44: ad010520    	stp	q0, q1, [x9, #0x20]
1000baa48: f945cbe8    	ldr	x8, [sp, #0xb90]
1000baa4c: f9002128    	str	x8, [x9, #0x40]
1000baa50: 3dc2dbe0    	ldr	q0, [sp, #0xb60]
1000baa54: 3dc2d7e1    	ldr	q1, [sp, #0xb50]
1000baa58: 14000025    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000baa5c: f942cbf4    	ldr	x20, [sp, #0x590]
1000baa60: f100269f    	cmp	x20, #0x9
1000baa64: 540024e2    	b.hs	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000baa68: b4000354    	cbz	x20, 0x1000baad0 <_machine.machine.Group.execute+0x2090>
1000baa6c: 911003e8    	add	x8, sp, #0x400
1000baa70: 91008115    	add	x21, x8, #0x20
1000baa74: f85e02a0    	ldur	x0, [x21, #-0x20]
1000baa78: 384306a1    	ldrb	w1, [x21], #0x30
1000baa7c: 9105c3e2    	add	x2, sp, #0x170
1000baa80: 97fee9c4    	bl	0x100075190 <_machine.machine.Slot.release>
1000baa84: f1000694    	subs	x20, x20, #0x1
1000baa88: 54ffff61    	b.ne	0x1000baa74 <_machine.machine.Group.execute+0x2034>
1000baa8c: f942c7e8    	ldr	x8, [sp, #0x588]
1000baa90: b4000208    	cbz	x8, 0x1000baad0 <_machine.machine.Group.execute+0x2090>
1000baa94: f942c3f4    	ldr	x20, [sp, #0x580]
1000baa98: 8b080508    	add	x8, x8, x8, lsl #1
1000baa9c: d37ced15    	lsl	x21, x8, #4
1000baaa0: aa1403e0    	mov	x0, x20
1000baaa4: 52801541    	mov	w1, #0xaa               ; =170
1000baaa8: aa1503e2    	mov	x2, x21
1000baaac: 94050e74    	bl	0x1001fe47c <_writev+0x1001fe47c>
1000baab0: f94017e4    	ldr	x4, [sp, #0x28]
1000baab4: dac143e4    	xpaci	x4
1000baab8: f9400ec8    	ldr	x8, [x22, #0x18]
1000baabc: aa1303e0    	mov	x0, x19
1000baac0: aa1403e1    	mov	x1, x20
1000baac4: aa1503e2    	mov	x2, x21
1000baac8: 52800083    	mov	w3, #0x4                ; =4
1000baacc: d63f0100    	blr	x8
1000baad0: 911a23ea    	add	x10, sp, #0x688
1000baad4: ad540540    	ldp	q0, q1, [x10, #0x280]
1000baad8: f9400fe9    	ldr	x9, [sp, #0x18]
1000baadc: ad010520    	stp	q0, q1, [x9, #0x20]
1000baae0: f94497e8    	ldr	x8, [sp, #0x928]
1000baae4: f9002128    	str	x8, [x9, #0x40]
1000baae8: ad530141    	ldp	q1, q0, [x10, #0x260]
1000baaec: ad000121    	stp	q1, q0, [x9]
1000baaf0: 7900913f    	strh	wzr, [x9, #0x48]
1000baaf4: f85983a8    	ldur	x8, [x29, #-0x68]
1000baaf8: 90000f89    	adrp	x9, 0x1002aa000 <___anon_158745+0x70>
1000baafc: f9409529    	ldr	x9, [x9, #0x128]
1000bab00: f9400129    	ldr	x9, [x9]
1000bab04: eb08013f    	cmp	x9, x8
1000bab08: 54002081    	b.ne	0x1000baf18 <_machine.machine.Group.execute+0x24d8>
1000bab0c: 913443ff    	add	sp, sp, #0xd10
1000bab10: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1000bab14: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1000bab18: a94357f6    	ldp	x22, x21, [sp, #0x30]
1000bab1c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1000bab20: a94167fa    	ldp	x26, x25, [sp, #0x10]
1000bab24: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1000bab28: d65f03c0    	ret
1000bab2c: 7102929f    	cmp	w20, #0xa4
1000bab30: 54000520    	b.eq	0x1000babd4 <_machine.machine.Group.execute+0x2194>
1000bab34: 7102969f    	cmp	w20, #0xa5
1000bab38: 540003a1    	b.ne	0x1000babac <_machine.machine.Group.execute+0x216c>
1000bab3c: b9405fe8    	ldr	w8, [sp, #0x5c]
1000bab40: 36000268    	tbz	w8, #0x0, 0x1000bab8c <_machine.machine.Group.execute+0x214c>
1000bab44: 9103c3e0    	add	x0, sp, #0xf0
1000bab48: 911883e2    	add	x2, sp, #0x620
1000bab4c: aa1303e1    	mov	x1, x19
1000bab50: 940128f5    	bl	0x100104f24 <_machine.costs.chargeInstruction>
1000bab54: f9407be8    	ldr	x8, [sp, #0xf0]
1000bab58: f940fec9    	ldr	x9, [x22, #0x1f8]
1000bab5c: ab090108    	adds	x8, x8, x9
1000bab60: 54001b62    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000bab64: f9405ac9    	ldr	x9, [x22, #0xb0]
1000bab68: ab080128    	adds	x8, x9, x8
1000bab6c: 54001b02    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000bab70: f9407fe9    	ldr	x9, [sp, #0xf8]
1000bab74: f9005ac8    	str	x8, [x22, #0xb0]
1000bab78: f9405ec8    	ldr	x8, [x22, #0xb8]
1000bab7c: ab090108    	adds	x8, x8, x9
1000bab80: 54001a62    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000bab84: f9005ec8    	str	x8, [x22, #0xb8]
1000bab88: f900fedf    	str	xzr, [x22, #0x1f8]
1000bab8c: 911883e0    	add	x0, sp, #0x620
1000bab90: 940025e3    	bl	0x1000c431c <_machine.costs.Measures.release>
1000bab94: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bab98: 3d8043e0    	str	q0, [sp, #0x100]
1000bab9c: 911003e0    	add	x0, sp, #0x400
1000baba0: 910403e1    	add	x1, sp, #0x100
1000baba4: 94002584    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000baba8: 17fffd3e    	b	0x1000ba0a0 <_machine.machine.Group.execute+0x1660>
1000babac: 911883e0    	add	x0, sp, #0x620
1000babb0: 940025db    	bl	0x1000c431c <_machine.costs.Measures.release>
1000babb4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000babb8: 3d804be0    	str	q0, [sp, #0x120]
1000babbc: 911003e0    	add	x0, sp, #0x400
1000babc0: 910483e1    	add	x1, sp, #0x120
1000babc4: 9400257c    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000babc8: f9400fe8    	ldr	x8, [sp, #0x18]
1000babcc: 79009114    	strh	w20, [x8, #0x48]
1000babd0: 17ffffc9    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000babd4: b9405fe8    	ldr	w8, [sp, #0x5c]
1000babd8: 36000268    	tbz	w8, #0x0, 0x1000bac24 <_machine.machine.Group.execute+0x21e4>
1000babdc: 910343e0    	add	x0, sp, #0xd0
1000babe0: 911883e2    	add	x2, sp, #0x620
1000babe4: aa1303e1    	mov	x1, x19
1000babe8: 940128cf    	bl	0x100104f24 <_machine.costs.chargeInstruction>
1000babec: f9406be8    	ldr	x8, [sp, #0xd0]
1000babf0: f940fec9    	ldr	x9, [x22, #0x1f8]
1000babf4: ab090108    	adds	x8, x8, x9
1000babf8: 540016a2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000babfc: f9405ac9    	ldr	x9, [x22, #0xb0]
1000bac00: ab080128    	adds	x8, x9, x8
1000bac04: 54001642    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000bac08: f9406fe9    	ldr	x9, [sp, #0xd8]
1000bac0c: f9005ac8    	str	x8, [x22, #0xb0]
1000bac10: f9405ec8    	ldr	x8, [x22, #0xb8]
1000bac14: ab090108    	adds	x8, x8, x9
1000bac18: 540015a2    	b.hs	0x1000baecc <_machine.machine.Group.execute+0x248c>
1000bac1c: f9005ec8    	str	x8, [x22, #0xb8]
1000bac20: f900fedf    	str	xzr, [x22, #0x1f8]
1000bac24: 911883e0    	add	x0, sp, #0x620
1000bac28: 940025bd    	bl	0x1000c431c <_machine.costs.Measures.release>
1000bac2c: 3946a2c8    	ldrb	w8, [x22, #0x1a8]
1000bac30: 360015e8    	tbz	w8, #0x0, 0x1000baeec <_machine.machine.Group.execute+0x24ac>
1000bac34: 394682c8    	ldrb	w8, [x22, #0x1a0]
1000bac38: 7100051f    	cmp	w8, #0x1
1000bac3c: 54000e4c    	b.gt	0x1000bae04 <_machine.machine.Group.execute+0x23c4>
1000bac40: 35000ec8    	cbnz	w8, 0x1000bae18 <_machine.machine.Group.execute+0x23d8>
1000bac44: 90000af3    	adrp	x19, 0x100216000 <___anon_77823+0x8>
1000bac48: 9122c273    	add	x19, x19, #0x8b0
1000bac4c: 1400007a    	b	0x1000bae34 <_machine.machine.Group.execute+0x23f4>
1000bac50: 911883e0    	add	x0, sp, #0x620
1000bac54: 940025b2    	bl	0x1000c431c <_machine.costs.Measures.release>
1000bac58: 3954eea8    	ldrb	w8, [x21, #0x53b]
1000bac5c: 36001488    	tbz	w8, #0x0, 0x1000baeec <_machine.machine.Group.execute+0x24ac>
1000bac60: 3954eaa3    	ldrb	w3, [x21, #0x53a]
1000bac64: 790a76bf    	strh	wzr, [x21, #0x53a]
1000bac68: a9449fe8    	ldp	x8, x7, [sp, #0x48]
1000bac6c: b90003e8    	str	w8, [sp]
1000bac70: 911fa3e0    	add	x0, sp, #0x7e8
1000bac74: aa1503e1    	mov	x1, x21
1000bac78: aa1603e2    	mov	x2, x22
1000bac7c: f9401fe4    	ldr	x4, [sp, #0x38]
1000bac80: aa1c03e5    	mov	x5, x28
1000bac84: aa1b03e6    	mov	x6, x27
1000bac88: 940022d5    	bl	0x1000c37dc <_machine.machine.Group.limitFault>
1000bac8c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bac90: 3d8047e0    	str	q0, [sp, #0x110]
1000bac94: 911003e0    	add	x0, sp, #0x400
1000bac98: 910443e1    	add	x1, sp, #0x110
1000bac9c: 94002546    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000baca0: 911a23ea    	add	x10, sp, #0x688
1000baca4: ad4c0540    	ldp	q0, q1, [x10, #0x180]
1000baca8: f9400fe9    	ldr	x9, [sp, #0x18]
1000bacac: ad010520    	stp	q0, q1, [x9, #0x20]
1000bacb0: f94417e8    	ldr	x8, [sp, #0x828]
1000bacb4: f9002128    	str	x8, [x9, #0x40]
1000bacb8: ad4b0141    	ldp	q1, q0, [x10, #0x160]
1000bacbc: 17ffff8c    	b	0x1000baaec <_machine.machine.Group.execute+0x20ac>
1000bacc0: f9400fe8    	ldr	x8, [sp, #0x18]
1000bacc4: 79009100    	strh	w0, [x8, #0x48]
1000bacc8: 17ffff8b    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000baccc: f9013abf    	str	xzr, [x21, #0x270]
1000bacd0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bacd4: 3d809fe0    	str	q0, [sp, #0x270]
1000bacd8: 911003e0    	add	x0, sp, #0x400
1000bacdc: 9109c3e1    	add	x1, sp, #0x270
1000bace0: 1400000a    	b	0x1000bad08 <_machine.machine.Group.execute+0x22c8>
1000bace4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bace8: 3d80a7e0    	str	q0, [sp, #0x290]
1000bacec: 911003e0    	add	x0, sp, #0x400
1000bacf0: 910a43e1    	add	x1, sp, #0x290
1000bacf4: 14000005    	b	0x1000bad08 <_machine.machine.Group.execute+0x22c8>
1000bacf8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bacfc: 3d80b7e0    	str	q0, [sp, #0x2d0]
1000bad00: 911003e0    	add	x0, sp, #0x400
1000bad04: 910b43e1    	add	x1, sp, #0x2d0
1000bad08: 9400252b    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000bad0c: f9400fe8    	ldr	x8, [sp, #0x18]
1000bad10: 79009113    	strh	w19, [x8, #0x48]
1000bad14: 17ffff78    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000bad18: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad1c: 3d80f7e0    	str	q0, [sp, #0x3d0]
1000bad20: 910e03e0    	add	x0, sp, #0x380
1000bad24: 910f43e1    	add	x1, sp, #0x3d0
1000bad28: 1400000e    	b	0x1000bad60 <_machine.machine.Group.execute+0x2320>
1000bad2c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad30: 3d80ebe0    	str	q0, [sp, #0x3a0]
1000bad34: 912e83e0    	add	x0, sp, #0xba0
1000bad38: 910e83e1    	add	x1, sp, #0x3a0
1000bad3c: 97feebae    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bad40: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad44: 3d80efe0    	str	q0, [sp, #0x3b0]
1000bad48: 910ec3e2    	add	x2, sp, #0x3b0
1000bad4c: 14000018    	b	0x1000badac <_machine.machine.Group.execute+0x236c>
1000bad50: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad54: 3d80fbe0    	str	q0, [sp, #0x3e0]
1000bad58: 910e03e0    	add	x0, sp, #0x380
1000bad5c: 910f83e1    	add	x1, sp, #0x3e0
1000bad60: 97feeba5    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bad64: 17fffd28    	b	0x1000ba204 <_machine.machine.Group.execute+0x17c4>
1000bad68: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad6c: 3d80f7e0    	str	q0, [sp, #0x3d0]
1000bad70: 912e83e0    	add	x0, sp, #0xba0
1000bad74: 910f43e1    	add	x1, sp, #0x3d0
1000bad78: 97feeb9f    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bad7c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad80: 3d80fbe0    	str	q0, [sp, #0x3e0]
1000bad84: 910f83e2    	add	x2, sp, #0x3e0
1000bad88: 14000009    	b	0x1000badac <_machine.machine.Group.execute+0x236c>
1000bad8c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad90: 3d80dbe0    	str	q0, [sp, #0x360]
1000bad94: 912e83e0    	add	x0, sp, #0xba0
1000bad98: 910d83e1    	add	x1, sp, #0x360
1000bad9c: 97feeb96    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bada0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bada4: 3d80e3e0    	str	q0, [sp, #0x380]
1000bada8: 910e03e2    	add	x2, sp, #0x380
1000badac: aa1303e0    	mov	x0, x19
1000badb0: aa1403e1    	mov	x1, x20
1000badb4: 97fee4d7    	bl	0x100074110 <_machine.machine.releaseAll>
1000badb8: 17fffd40    	b	0x1000ba2b8 <_machine.machine.Group.execute+0x1878>
1000badbc: aa1303e0    	mov	x0, x19
1000badc0: 97fe9b09    	bl	0x1000619e4 <_value.Value.release>
1000badc4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000badc8: 3d8067e0    	str	q0, [sp, #0x190]
1000badcc: 911003e0    	add	x0, sp, #0x400
1000badd0: 910643e1    	add	x1, sp, #0x190
1000badd4: 17fffd10    	b	0x1000ba214 <_machine.machine.Group.execute+0x17d4>
1000badd8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baddc: 3d8073e0    	str	q0, [sp, #0x1c0]
1000bade0: 910703e2    	add	x2, sp, #0x1c0
1000bade4: aa1803e0    	mov	x0, x24
1000bade8: aa1403e1    	mov	x1, x20
1000badec: 97fee4c9    	bl	0x100074110 <_machine.machine.releaseAll>
1000badf0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000badf4: 3d8077e0    	str	q0, [sp, #0x1d0]
1000badf8: 911003e0    	add	x0, sp, #0x400
1000badfc: 910743e1    	add	x1, sp, #0x1d0
1000bae00: 17fffd05    	b	0x1000ba214 <_machine.machine.Group.execute+0x17d4>
1000bae04: 7100091f    	cmp	w8, #0x2
1000bae08: 54000861    	b.ne	0x1000baf14 <_machine.machine.Group.execute+0x24d4>
1000bae0c: 90000af3    	adrp	x19, 0x100216000 <___anon_77823+0x8>
1000bae10: 91240273    	add	x19, x19, #0x900
1000bae14: 14000008    	b	0x1000bae34 <_machine.machine.Group.execute+0x23f4>
1000bae18: 6f00e400    	movi.2d	v0, #0000000000000000
1000bae1c: ad0c82c0    	stp	q0, q0, [x22, #0x190]
1000bae20: 911e63f3    	add	x19, sp, #0x798
1000bae24: 911e63e0    	add	x0, sp, #0x798
1000bae28: aa1503e1    	mov	x1, x21
1000bae2c: aa1603e2    	mov	x2, x22
1000bae30: 94012fd7    	bl	0x100106d8c <_machine.machine.Group.landedCancel>
1000bae34: f9400ff4    	ldr	x20, [sp, #0x18]
1000bae38: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae3c: 3d803be0    	str	q0, [sp, #0xe0]
1000bae40: 911003e0    	add	x0, sp, #0x400
1000bae44: 910383e1    	add	x1, sp, #0xe0
1000bae48: 940024db    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000bae4c: ad410660    	ldp	q0, q1, [x19, #0x20]
1000bae50: ad010680    	stp	q0, q1, [x20, #0x20]
1000bae54: 3dc01260    	ldr	q0, [x19, #0x40]
1000bae58: 3d801280    	str	q0, [x20, #0x40]
1000bae5c: ad400261    	ldp	q1, q0, [x19]
1000bae60: ad000281    	stp	q1, q0, [x20]
1000bae64: 17ffff24    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000bae68: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae6c: 3d8087e0    	str	q0, [sp, #0x210]
1000bae70: 910843e2    	add	x2, sp, #0x210
1000bae74: aa1803e0    	mov	x0, x24
1000bae78: aa1403e1    	mov	x1, x20
1000bae7c: 97fee4a5    	bl	0x100074110 <_machine.machine.releaseAll>
1000bae80: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae84: 3d808be0    	str	q0, [sp, #0x220]
1000bae88: 911003e0    	add	x0, sp, #0x400
1000bae8c: 910883e1    	add	x1, sp, #0x220
1000bae90: 940024c9    	bl	0x1000c41b4 <_machine.machine.Operands.release>
1000bae94: f9400fe8    	ldr	x8, [sp, #0x18]
1000bae98: 7900911a    	strh	w26, [x8, #0x48]
1000bae9c: 17ffff16    	b	0x1000baaf4 <_machine.machine.Group.execute+0x20b4>
1000baea0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baea4: 3d808fe0    	str	q0, [sp, #0x230]
1000baea8: 9108c3e2    	add	x2, sp, #0x230
1000baeac: aa1803e0    	mov	x0, x24
1000baeb0: aa1403e1    	mov	x1, x20
1000baeb4: 97fee497    	bl	0x100074110 <_machine.machine.releaseAll>
1000baeb8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baebc: 3d8093e0    	str	q0, [sp, #0x240]
1000baec0: 911003e0    	add	x0, sp, #0x400
1000baec4: 910903e1    	add	x1, sp, #0x240
1000baec8: 17fffcd3    	b	0x1000ba214 <_machine.machine.Group.execute+0x17d4>
1000baecc: 9404e8f4    	bl	0x1001f529c <_debug.FullPanic((function 'defaultPanic')).integerOverflow>
1000baed0: 911883e0    	add	x0, sp, #0x620
1000baed4: 94002512    	bl	0x1000c431c <_machine.costs.Measures.release>
1000baed8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baedc: 3d8033e0    	str	q0, [sp, #0xc0]
1000baee0: 911003e0    	add	x0, sp, #0x400
1000baee4: 910303e1    	add	x1, sp, #0xc0
1000baee8: 17ffff37    	b	0x1000babc4 <_machine.machine.Group.execute+0x2184>
1000baeec: 9404d18a    	bl	0x1001ef514 <_debug.FullPanic((function 'defaultPanic')).unwrapNull>
1000baef0: 9404e8f7    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baef4: aa1b03e0    	mov	x0, x27
1000baef8: 9404e8f5    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baefc: 9404d13e    	bl	0x1001ef3f4 <_debug.FullPanic((function 'defaultPanic')).reachedUnreachable>
1000baf00: aa1403e0    	mov	x0, x20
1000baf04: 52800101    	mov	w1, #0x8                ; =8
1000baf08: 9404e8f1    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf0c: aa0203e0    	mov	x0, x2
1000baf10: 9404e8ef    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf14: 9404d168    	bl	0x1001ef4b4 <_debug.FullPanic((function 'defaultPanic')).corruptSwitch>
1000baf18: 94050cae    	bl	0x1001fe1d0 <_writev+0x1001fe1d0>
1000baf1c: aa1303e0    	mov	x0, x19
1000baf20: 9404e8eb    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf24: 52800020    	mov	w0, #0x1                ; =1
1000baf28: 52800001    	mov	w1, #0x0                ; =0
1000baf2c: 9404f070    	bl	0x1001f70ec <_debug.FullPanic((function 'defaultPanic')).inactiveUnionField__func_1432>
1000baf30: aa1303e0    	mov	x0, x19
1000baf34: 52801221    	mov	w1, #0x91               ; =145
1000baf38: 9404e8e5    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf3c: 91000680    	add	x0, x20, #0x1
1000baf40: 9404e8e3    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf44: 9404d267    	bl	0x1001ef8e0 <_debug.FullPanic((function 'defaultPanic')).incorrectAlignment>
1000baf48: aa1703e0    	mov	x0, x23
1000baf4c: 9404e8e0    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf50: aa0103e0    	mov	x0, x1
1000baf54: 52800101    	mov	w1, #0x8                ; =8
1000baf58: 9404e8dd    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf5c: 9404d013    	bl	0x1001eefa8 <_debug.FullPanic((function 'defaultPanic')).forLenMismatch>
1000baf60: 9404e8e6    	bl	0x1001f52f8 <_debug.FullPanic((function 'defaultPanic')).startGreaterThanEnd>
1000baf64: aa1703e0    	mov	x0, x23
1000baf68: 52800101    	mov	w1, #0x8                ; =8
1000baf6c: 9404e8d8    	bl	0x1001f52cc <_debug.FullPanic((function 'defaultPanic')).outOfBounds>

