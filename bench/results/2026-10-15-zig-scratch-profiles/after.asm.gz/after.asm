000000010000ac94 <_heap.ArenaAllocator.reset>:
10000ac94: a9bb67fa    	stp	x26, x25, [sp, #-0x50]!
10000ac98: a9015ff8    	stp	x24, x23, [sp, #0x10]
10000ac9c: a90257f6    	stp	x22, x21, [sp, #0x20]
10000aca0: a9034ff4    	stp	x20, x19, [sp, #0x30]
10000aca4: a9047bfd    	stp	x29, x30, [sp, #0x40]
10000aca8: 910103fd    	add	x29, sp, #0x40
10000acac: aa1e03f4    	mov	x20, x30
10000acb0: aa0003f3    	mov	x19, x0
10000acb4: f9400801    	ldr	x1, [x0, #0x10]
10000acb8: b40003a1    	cbz	x1, 0x10000ad2c <_heap.ArenaAllocator.reset+0x98>
10000acbc: d2800008    	mov	x8, #0x0                ; =0
10000acc0: aa0103e9    	mov	x9, x1
10000acc4: f940012a    	ldr	x10, [x9]
10000acc8: 927ff94a    	and	x10, x10, #0xfffffffffffffffe
10000accc: f100614a    	subs	x10, x10, #0x18
10000acd0: 540011c3    	b.lo	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000acd4: ab0a0108    	adds	x8, x8, x10
10000acd8: 54001182    	b.hs	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000acdc: f9400929    	ldr	x9, [x9, #0x10]
10000ace0: b5ffff29    	cbnz	x9, 0x10000acc4 <_heap.ArenaAllocator.reset+0x30>
10000ace4: b1006116    	adds	x22, x8, #0x18
10000ace8: 1a9f37f7    	cset	w23, hs
10000acec: f9400e68    	ldr	x8, [x19, #0x18]
10000acf0: b4000268    	cbz	x8, 0x10000ad3c <_heap.ArenaAllocator.reset+0xa8>
10000acf4: d2800009    	mov	x9, #0x0                ; =0
10000acf8: f940010a    	ldr	x10, [x8]
10000acfc: 927ff94a    	and	x10, x10, #0xfffffffffffffffe
10000ad00: f100614a    	subs	x10, x10, #0x18
10000ad04: 54001023    	b.lo	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad08: ab0a0129    	adds	x9, x9, x10
10000ad0c: 54000fe2    	b.hs	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad10: f9400908    	ldr	x8, [x8, #0x10]
10000ad14: b5ffff28    	cbnz	x8, 0x10000acf8 <_heap.ArenaAllocator.reset+0x64>
10000ad18: b1006138    	adds	x24, x9, #0x18
10000ad1c: 1a9f37f9    	cset	w25, hs
10000ad20: dac143f4    	xpaci	x20
10000ad24: b5000141    	cbnz	x1, 0x10000ad4c <_heap.ArenaAllocator.reset+0xb8>
10000ad28: 1400004a    	b	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ad2c: 52800017    	mov	w23, #0x0               ; =0
10000ad30: 52800316    	mov	w22, #0x18              ; =24
10000ad34: f9400e68    	ldr	x8, [x19, #0x18]
10000ad38: b5fffde8    	cbnz	x8, 0x10000acf4 <_heap.ArenaAllocator.reset+0x60>
10000ad3c: 52800019    	mov	w25, #0x0               ; =0
10000ad40: 52800318    	mov	w24, #0x18              ; =24
10000ad44: dac143f4    	xpaci	x20
10000ad48: b4000841    	cbz	x1, 0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ad4c: f9400828    	ldr	x8, [x1, #0x10]
10000ad50: b40001c8    	cbz	x8, 0x10000ad88 <_heap.ArenaAllocator.reset+0xf4>
10000ad54: aa0803f5    	mov	x21, x8
10000ad58: a9402260    	ldp	x0, x8, [x19]
10000ad5c: f9400029    	ldr	x9, [x1]
10000ad60: f9400d08    	ldr	x8, [x8, #0x18]
10000ad64: 927ff922    	and	x2, x9, #0xfffffffffffffffe
10000ad68: 52800063    	mov	w3, #0x3                ; =3
10000ad6c: aa1403e4    	mov	x4, x20
10000ad70: d63f0100    	blr	x8
10000ad74: f9400aa8    	ldr	x8, [x21, #0x10]
10000ad78: aa1503e1    	mov	x1, x21
10000ad7c: b5fffec8    	cbnz	x8, 0x10000ad54 <_heap.ArenaAllocator.reset+0xc0>
10000ad80: 36000097    	tbz	w23, #0x0, 0x10000ad90 <_heap.ArenaAllocator.reset+0xfc>
10000ad84: 14000061    	b	0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad88: aa0103f5    	mov	x21, x1
10000ad8c: 37000bf7    	tbnz	w23, #0x0, 0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ad90: f94002a8    	ldr	x8, [x21]
10000ad94: 927ff902    	and	x2, x8, #0xfffffffffffffffe
10000ad98: 927ffad6    	and	x22, x22, #0xfffffffffffffffe
10000ad9c: f10062df    	cmp	x22, #0x18
10000ada0: 54000121    	b.ne	0x10000adc4 <_heap.ArenaAllocator.reset+0x130>
10000ada4: a9402260    	ldp	x0, x8, [x19]
10000ada8: f9400d08    	ldr	x8, [x8, #0x18]
10000adac: aa1503e1    	mov	x1, x21
10000adb0: 52800063    	mov	w3, #0x3                ; =3
10000adb4: aa1403e4    	mov	x4, x20
10000adb8: d63f0100    	blr	x8
10000adbc: f9000a7f    	str	xzr, [x19, #0x10]
10000adc0: 14000024    	b	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000adc4: f90006bf    	str	xzr, [x21, #0x8]
10000adc8: f9000a75    	str	x21, [x19, #0x10]
10000adcc: eb16005f    	cmp	x2, x22
10000add0: 54000400    	b.eq	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000add4: a9402260    	ldp	x0, x8, [x19]
10000add8: f9400508    	ldr	x8, [x8, #0x8]
10000addc: aa1503e1    	mov	x1, x21
10000ade0: aa0203fa    	mov	x26, x2
10000ade4: 52800063    	mov	w3, #0x3                ; =3
10000ade8: aa1603e4    	mov	x4, x22
10000adec: aa1403e5    	mov	x5, x20
10000adf0: d63f0100    	blr	x8
10000adf4: 36000060    	tbz	w0, #0x0, 0x10000ae00 <_heap.ArenaAllocator.reset+0x16c>
10000adf8: f90002b6    	str	x22, [x21]
10000adfc: 14000015    	b	0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ae00: a9402260    	ldp	x0, x8, [x19]
10000ae04: f9400108    	ldr	x8, [x8]
10000ae08: aa1603e1    	mov	x1, x22
10000ae0c: 52800062    	mov	w2, #0x3                ; =3
10000ae10: aa1403e3    	mov	x3, x20
10000ae14: d63f0100    	blr	x8
10000ae18: b40001c0    	cbz	x0, 0x10000ae50 <_heap.ArenaAllocator.reset+0x1bc>
10000ae1c: aa0003f7    	mov	x23, x0
10000ae20: aa1a03e2    	mov	x2, x26
10000ae24: a9402260    	ldp	x0, x8, [x19]
10000ae28: f9400d08    	ldr	x8, [x8, #0x18]
10000ae2c: aa1503e1    	mov	x1, x21
10000ae30: 52800063    	mov	w3, #0x3                ; =3
10000ae34: aa1403e4    	mov	x4, x20
10000ae38: d63f0100    	blr	x8
10000ae3c: f2400aff    	tst	x23, #0x7
10000ae40: 540009a1    	b.ne	0x10000af74 <_heap.ArenaAllocator.reset+0x2e0>
10000ae44: a900feff    	stp	xzr, xzr, [x23, #0x8]
10000ae48: f90002f6    	str	x22, [x23]
10000ae4c: f9000a77    	str	x23, [x19, #0x10]
10000ae50: f9400e61    	ldr	x1, [x19, #0x18]
10000ae54: b4000841    	cbz	x1, 0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000ae58: f9400828    	ldr	x8, [x1, #0x10]
10000ae5c: b4000528    	cbz	x8, 0x10000af00 <_heap.ArenaAllocator.reset+0x26c>
10000ae60: aa0803f5    	mov	x21, x8
10000ae64: a9402260    	ldp	x0, x8, [x19]
10000ae68: f9400029    	ldr	x9, [x1]
10000ae6c: f9400d08    	ldr	x8, [x8, #0x18]
10000ae70: 927ff922    	and	x2, x9, #0xfffffffffffffffe
10000ae74: 52800063    	mov	w3, #0x3                ; =3
10000ae78: aa1403e4    	mov	x4, x20
10000ae7c: d63f0100    	blr	x8
10000ae80: f9400aa8    	ldr	x8, [x21, #0x10]
10000ae84: aa1503e1    	mov	x1, x21
10000ae88: b5fffec8    	cbnz	x8, 0x10000ae60 <_heap.ArenaAllocator.reset+0x1cc>
10000ae8c: 370003f9    	tbnz	w25, #0x0, 0x10000af08 <_heap.ArenaAllocator.reset+0x274>
10000ae90: f94002a8    	ldr	x8, [x21]
10000ae94: 927ff902    	and	x2, x8, #0xfffffffffffffffe
10000ae98: 927ffb16    	and	x22, x24, #0xfffffffffffffffe
10000ae9c: f10062df    	cmp	x22, #0x18
10000aea0: 54000121    	b.ne	0x10000aec4 <_heap.ArenaAllocator.reset+0x230>
10000aea4: a9402260    	ldp	x0, x8, [x19]
10000aea8: f9400d08    	ldr	x8, [x8, #0x18]
10000aeac: aa1503e1    	mov	x1, x21
10000aeb0: 52800063    	mov	w3, #0x3                ; =3
10000aeb4: aa1403e4    	mov	x4, x20
10000aeb8: d63f0100    	blr	x8
10000aebc: f9000e7f    	str	xzr, [x19, #0x18]
10000aec0: 14000027    	b	0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000aec4: f90006bf    	str	xzr, [x21, #0x8]
10000aec8: f9000e75    	str	x21, [x19, #0x18]
10000aecc: eb16005f    	cmp	x2, x22
10000aed0: 54000460    	b.eq	0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000aed4: a9402260    	ldp	x0, x8, [x19]
10000aed8: f9400508    	ldr	x8, [x8, #0x8]
10000aedc: aa1503e1    	mov	x1, x21
10000aee0: aa0203f8    	mov	x24, x2
10000aee4: 52800063    	mov	w3, #0x3                ; =3
10000aee8: aa1603e4    	mov	x4, x22
10000aeec: aa1403e5    	mov	x5, x20
10000aef0: d63f0100    	blr	x8
10000aef4: 360000c0    	tbz	w0, #0x0, 0x10000af0c <_heap.ArenaAllocator.reset+0x278>
10000aef8: f90002b6    	str	x22, [x21]
10000aefc: 14000018    	b	0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000af00: aa0103f5    	mov	x21, x1
10000af04: 3607fc79    	tbz	w25, #0x0, 0x10000ae90 <_heap.ArenaAllocator.reset+0x1fc>
10000af08: 9407a8e8    	bl	0x1001f52a8 <_debug.FullPanic((function 'defaultPanic')).integerOverflow>
10000af0c: a9402260    	ldp	x0, x8, [x19]
10000af10: f9400108    	ldr	x8, [x8]
10000af14: aa1603e1    	mov	x1, x22
10000af18: 52800062    	mov	w2, #0x3                ; =3
10000af1c: aa1403e3    	mov	x3, x20
10000af20: d63f0100    	blr	x8
10000af24: b40001c0    	cbz	x0, 0x10000af5c <_heap.ArenaAllocator.reset+0x2c8>
10000af28: aa0003f7    	mov	x23, x0
10000af2c: aa1803e2    	mov	x2, x24
10000af30: a9402260    	ldp	x0, x8, [x19]
10000af34: f9400d08    	ldr	x8, [x8, #0x18]
10000af38: aa1503e1    	mov	x1, x21
10000af3c: 52800063    	mov	w3, #0x3                ; =3
10000af40: aa1403e4    	mov	x4, x20
10000af44: d63f0100    	blr	x8
10000af48: f2400aff    	tst	x23, #0x7
10000af4c: 54000141    	b.ne	0x10000af74 <_heap.ArenaAllocator.reset+0x2e0>
10000af50: a900feff    	stp	xzr, xzr, [x23, #0x8]
10000af54: f90002f6    	str	x22, [x23]
10000af58: f9000e77    	str	x23, [x19, #0x18]
10000af5c: a9447bfd    	ldp	x29, x30, [sp, #0x40]
10000af60: a9434ff4    	ldp	x20, x19, [sp, #0x30]
10000af64: a94257f6    	ldp	x22, x21, [sp, #0x20]
10000af68: a9415ff8    	ldp	x24, x23, [sp, #0x10]
10000af6c: a8c567fa    	ldp	x26, x25, [sp], #0x50
10000af70: d65f03c0    	ret
10000af74: 9407925e    	bl	0x1001ef8ec <_debug.FullPanic((function 'defaultPanic')).incorrectAlignment>

00000001000b8a40 <_machine.machine.Group.execute>:
1000b8a40: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
1000b8a44: a90167fa    	stp	x26, x25, [sp, #0x10]
1000b8a48: a9025ff8    	stp	x24, x23, [sp, #0x20]
1000b8a4c: a90357f6    	stp	x22, x21, [sp, #0x30]
1000b8a50: a9044ff4    	stp	x20, x19, [sp, #0x40]
1000b8a54: a9057bfd    	stp	x29, x30, [sp, #0x50]
1000b8a58: 910143fd    	add	x29, sp, #0x50
1000b8a5c: d13443ff    	sub	sp, sp, #0xd10
1000b8a60: f90017fe    	str	x30, [sp, #0x28]
1000b8a64: aa0303f3    	mov	x19, x3
1000b8a68: aa0203f6    	mov	x22, x2
1000b8a6c: aa0103f5    	mov	x21, x1
1000b8a70: f9000fe0    	str	x0, [sp, #0x18]
1000b8a74: d0000f88    	adrp	x8, 0x1002aa000 <___anon_158753+0x70>
1000b8a78: f9409508    	ldr	x8, [x8, #0x128]
1000b8a7c: f9400108    	ldr	x8, [x8]
1000b8a80: f81983a8    	stur	x8, [x29, #-0x68]
1000b8a84: d0000ae1    	adrp	x1, 0x100216000 <___anon_78196+0x40>
1000b8a88: 911b4021    	add	x1, x1, #0x6d0
1000b8a8c: 911003e0    	add	x0, sp, #0x400
1000b8a90: 52803402    	mov	w2, #0x1a0              ; =416
1000b8a94: 94051677    	bl	0x1001fe470 <_writev+0x1001fe470>
1000b8a98: b9005ff3    	str	w19, [sp, #0x5c]
1000b8a9c: 52000268    	eor	w8, w19, #0x1
1000b8aa0: b90027e8    	str	w8, [sp, #0x24]
1000b8aa4: 911b83e8    	add	x8, sp, #0x6e0
1000b8aa8: 91008108    	add	x8, x8, #0x20
1000b8aac: f90023e8    	str	x8, [sp, #0x40]
1000b8ab0: 911d23e8    	add	x8, sp, #0x748
1000b8ab4: 91008108    	add	x8, x8, #0x20
1000b8ab8: f9000be8    	str	x8, [sp, #0x10]
1000b8abc: 14000013    	b	0x1000b8b08 <_machine.machine.Group.execute+0xc8>
1000b8ac0: f942c3f7    	ldr	x23, [sp, #0x580]
1000b8ac4: 8b080508    	add	x8, x8, x8, lsl #1
1000b8ac8: d37ced18    	lsl	x24, x8, #4
1000b8acc: aa1703e0    	mov	x0, x23
1000b8ad0: 52801541    	mov	w1, #0xaa               ; =170
1000b8ad4: aa1803e2    	mov	x2, x24
1000b8ad8: 9405166c    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b8adc: f9400f28    	ldr	x8, [x25, #0x18]
1000b8ae0: aa1403e0    	mov	x0, x20
1000b8ae4: aa1703e1    	mov	x1, x23
1000b8ae8: aa1803e2    	mov	x2, x24
1000b8aec: 52800083    	mov	w3, #0x4                ; =4
1000b8af0: aa1303e4    	mov	x4, x19
1000b8af4: d63f0100    	blr	x8
1000b8af8: 52800208    	mov	w8, #0x10               ; =16
1000b8afc: f902c3e8    	str	x8, [sp, #0x580]
1000b8b00: 911003e8    	add	x8, sp, #0x400
1000b8b04: a918fd1f    	stp	xzr, xzr, [x8, #0x188]
1000b8b08: f940f6a8    	ldr	x8, [x21, #0x1e8]
1000b8b0c: b40009a8    	cbz	x8, 0x1000b8c40 <_machine.machine.Group.execute+0x200>
1000b8b10: 910742a0    	add	x0, x21, #0x1d0
1000b8b14: 97fd4860    	bl	0x10000ac94 <_heap.ArenaAllocator.reset>
1000b8b18: a95fa6c8    	ldp	x8, x9, [x22, #0x1f8]
1000b8b1c: ab090108    	adds	x8, x8, x9
1000b8b20: 54011dc2    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8b24: a91ffec8    	stp	x8, xzr, [x22, #0x1f8]
1000b8b28: f9404ec1    	ldr	x1, [x22, #0x98]
1000b8b2c: f1000420    	subs	x0, x1, #0x1
1000b8b30: 54011d43    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8b34: eb01001f    	cmp	x0, x1
1000b8b38: 54011e22    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b8b3c: f9404ac8    	ldr	x8, [x22, #0x90]
1000b8b40: 52800909    	mov	w9, #0x48               ; =72
1000b8b44: 9b092014    	madd	x20, x0, x9, x8
1000b8b48: b9403e9b    	ldr	w27, [x20, #0x3c]
1000b8b4c: 3955d2c8    	ldrb	w8, [x22, #0x574]
1000b8b50: 360000c8    	tbz	w8, #0x0, 0x1000b8b68 <_machine.machine.Group.execute+0x128>
1000b8b54: f100043f    	cmp	x1, #0x1
1000b8b58: 54000081    	b.ne	0x1000b8b68 <_machine.machine.Group.execute+0x128>
1000b8b5c: b94572c8    	ldr	w8, [x22, #0x570]
1000b8b60: 6b08037f    	cmp	w27, w8
1000b8b64: 540097a0    	b.eq	0x1000b9e58 <_machine.machine.Group.execute+0x1418>
1000b8b68: f90262bf    	str	xzr, [x21, #0x4c0]
1000b8b6c: 395402a8    	ldrb	w8, [x21, #0x500]
1000b8b70: 36000148    	tbz	w8, #0x0, 0x1000b8b98 <_machine.machine.Group.execute+0x158>
1000b8b74: f940e6a0    	ldr	x0, [x21, #0x1c8]
1000b8b78: b4000100    	cbz	x0, 0x1000b8b98 <_machine.machine.Group.execute+0x158>
1000b8b7c: f9427aa2    	ldr	x2, [x21, #0x4f0]
1000b8b80: f94276a1    	ldr	x1, [x21, #0x4e8]
1000b8b84: eb01005f    	cmp	x2, x1
1000b8b88: 54011c88    	b.hi	0x1000baf18 <_machine.machine.Group.execute+0x24d8>
1000b8b8c: f94272a1    	ldr	x1, [x21, #0x4e0]
1000b8b90: 97fd238c    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b8b94: f9027abf    	str	xzr, [x21, #0x4f0]
1000b8b98: f9428aa9    	ldr	x9, [x21, #0x510]
1000b8b9c: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b8ba0: b4000189    	cbz	x9, 0x1000b8bd0 <_machine.machine.Group.execute+0x190>
1000b8ba4: b5000408    	cbnz	x8, 0x1000b8c24 <_machine.machine.Group.execute+0x1e4>
1000b8ba8: f94242c8    	ldr	x8, [x22, #0x480]
1000b8bac: b4000148    	cbz	x8, 0x1000b8bd4 <_machine.machine.Group.execute+0x194>
1000b8bb0: aa1503e0    	mov	x0, x21
1000b8bb4: aa1603e1    	mov	x1, x22
1000b8bb8: 97ffa404    	bl	0x1000a1bc8 <_machine.machine.Group.land>
1000b8bbc: 72003c1f    	tst	w0, #0xffff
1000b8bc0: 54010861    	b.ne	0x1000baccc <_machine.machine.Group.execute+0x228c>
1000b8bc4: 3946a2c8    	ldrb	w8, [x22, #0x1a8]
1000b8bc8: 3700a6a8    	tbnz	w8, #0x0, 0x1000ba09c <_machine.machine.Group.execute+0x165c>
1000b8bcc: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b8bd0: b50002a8    	cbnz	x8, 0x1000b8c24 <_machine.machine.Group.execute+0x1e4>
1000b8bd4: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b8bd8: f9422ec9    	ldr	x9, [x22, #0x458]
1000b8bdc: eb090108    	subs	x8, x8, x9
1000b8be0: 540117c3    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8be4: f94146a9    	ldr	x9, [x21, #0x288]
1000b8be8: b4000109    	cbz	x9, 0x1000b8c08 <_machine.machine.Group.execute+0x1c8>
1000b8bec: f9423ac9    	ldr	x9, [x22, #0x470]
1000b8bf0: f940112a    	ldr	x10, [x9, #0x20]
1000b8bf4: ab08014a    	adds	x10, x10, x8
1000b8bf8: 54011702    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8bfc: f9413d29    	ldr	x9, [x9, #0x278]
1000b8c00: eb09015f    	cmp	x10, x9
1000b8c04: 5400a282    	b.hs	0x1000ba054 <_machine.machine.Group.execute+0x1614>
1000b8c08: f94016a9    	ldr	x9, [x21, #0x28]
1000b8c0c: b40000c9    	cbz	x9, 0x1000b8c24 <_machine.machine.Group.execute+0x1e4>
1000b8c10: f940faaa    	ldr	x10, [x21, #0x1f0]
1000b8c14: ab080148    	adds	x8, x10, x8
1000b8c18: 54011602    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8c1c: eb09011f    	cmp	x8, x9
1000b8c20: 5400a1e2    	b.hs	0x1000ba05c <_machine.machine.Group.execute+0x161c>
1000b8c24: f9400288    	ldr	x8, [x20]
1000b8c28: b40001a8    	cbz	x8, 0x1000b8c5c <_machine.machine.Group.execute+0x21c>
1000b8c2c: 91018109    	add	x9, x8, #0x60
1000b8c30: f9403d21    	ldr	x1, [x9, #0x78]
1000b8c34: eb1b003f    	cmp	x1, x27
1000b8c38: 540001c8    	b.hi	0x1000b8c70 <_machine.machine.Group.execute+0x230>
1000b8c3c: 140008b1    	b	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b8c40: f940f2a8    	ldr	x8, [x21, #0x1e0]
1000b8c44: b4fff6a8    	cbz	x8, 0x1000b8b18 <_machine.machine.Group.execute+0xd8>
1000b8c48: f9400509    	ldr	x9, [x8, #0x8]
1000b8c4c: b5fff629    	cbnz	x9, 0x1000b8b10 <_machine.machine.Group.execute+0xd0>
1000b8c50: f9400908    	ldr	x8, [x8, #0x10]
1000b8c54: b5fff5e8    	cbnz	x8, 0x1000b8b10 <_machine.machine.Group.execute+0xd0>
1000b8c58: 17ffffb0    	b	0x1000b8b18 <_machine.machine.Group.execute+0xd8>
1000b8c5c: f9423ac9    	ldr	x9, [x22, #0x470]
1000b8c60: 9101e129    	add	x9, x9, #0x78
1000b8c64: f9403d21    	ldr	x1, [x9, #0x78]
1000b8c68: eb1b003f    	cmp	x1, x27
1000b8c6c: 540114a9    	b.ls	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b8c70: f9403929    	ldr	x9, [x9, #0x70]
1000b8c74: 5280060a    	mov	w10, #0x30              ; =48
1000b8c78: 9baa2769    	umaddl	x9, w27, w10, x9
1000b8c7c: ad408121    	ldp	q1, q0, [x9, #0x10]
1000b8c80: 3d8187e0    	str	q0, [sp, #0x610]
1000b8c84: 3dc00120    	ldr	q0, [x9]
1000b8c88: 3d817fe0    	str	q0, [sp, #0x5f0]
1000b8c8c: 3d8183e1    	str	q1, [sp, #0x600]
1000b8c90: b4000088    	cbz	x8, 0x1000b8ca0 <_machine.machine.Group.execute+0x260>
1000b8c94: 9100c109    	add	x9, x8, #0x30
1000b8c98: 9100e108    	add	x8, x8, #0x38
1000b8c9c: 14000004    	b	0x1000b8cac <_machine.machine.Group.execute+0x26c>
1000b8ca0: f9423ac8    	ldr	x8, [x22, #0x470]
1000b8ca4: 9106c109    	add	x9, x8, #0x1b0
1000b8ca8: 9106e108    	add	x8, x8, #0x1b8
1000b8cac: f940011c    	ldr	x28, [x8]
1000b8cb0: f9400129    	ldr	x9, [x9]
1000b8cb4: 3dc17fe0    	ldr	q0, [sp, #0x5f0]
1000b8cb8: 3dc183e1    	ldr	q1, [sp, #0x600]
1000b8cbc: 3c8d82a0    	stur	q0, [x21, #0xd8]
1000b8cc0: b94613e8    	ldr	w8, [sp, #0x610]
1000b8cc4: f9002be8    	str	x8, [sp, #0x50]
1000b8cc8: b94617e8    	ldr	w8, [sp, #0x614]
1000b8ccc: f90027e8    	str	x8, [sp, #0x48]
1000b8cd0: 395863f3    	ldrb	w19, [sp, #0x618]
1000b8cd4: f9001fe9    	str	x9, [sp, #0x38]
1000b8cd8: a90cf2a9    	stp	x9, x28, [x21, #0xc8]
1000b8cdc: b9010abb    	str	w27, [x21, #0x108]
1000b8ce0: 3c8e82a1    	stur	q1, [x21, #0xe8]
1000b8ce4: 3dc187e0    	ldr	q0, [sp, #0x610]
1000b8ce8: 3c8f82a0    	stur	q0, [x21, #0xf8]
1000b8cec: f9400288    	ldr	x8, [x20]
1000b8cf0: b40000a8    	cbz	x8, 0x1000b8d04 <_machine.machine.Group.execute+0x2c4>
1000b8cf4: 91018101    	add	x1, x8, #0x60
1000b8cf8: 7101ce7f    	cmp	w19, #0x73
1000b8cfc: 540000c1    	b.ne	0x1000b8d14 <_machine.machine.Group.execute+0x2d4>
1000b8d00: 1400005e    	b	0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d04: f9423ac8    	ldr	x8, [x22, #0x470]
1000b8d08: 9101e101    	add	x1, x8, #0x78
1000b8d0c: 7101ce7f    	cmp	w19, #0x73
1000b8d10: 54000b40    	b.eq	0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d14: f9401288    	ldr	x8, [x20, #0x20]
1000b8d18: b4000b08    	cbz	x8, 0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d1c: f9404428    	ldr	x8, [x1, #0x88]
1000b8d20: b4000ac8    	cbz	x8, 0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d24: a944e6b7    	ldp	x23, x25, [x21, #0x48]
1000b8d28: f9404029    	ldr	x9, [x1, #0x80]
1000b8d2c: 29402d2a    	ldp	w10, w11, [x9]
1000b8d30: 3940412c    	ldrb	w12, [x9, #0x10]
1000b8d34: 1200058c    	and	w12, w12, #0x3
1000b8d38: 7100059f    	cmp	w12, #0x1
1000b8d3c: 7a5b0142    	ccmp	w10, w27, #0x2, eq
1000b8d40: 7a4b9362    	ccmp	w27, w11, #0x2, ls
1000b8d44: 540000a9    	b.ls	0x1000b8d58 <_machine.machine.Group.execute+0x318>
1000b8d48: 91005129    	add	x9, x9, #0x14
1000b8d4c: f1000508    	subs	x8, x8, #0x1
1000b8d50: 54fffee1    	b.ne	0x1000b8d2c <_machine.machine.Group.execute+0x2ec>
1000b8d54: 14000049    	b	0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d58: 7102467f    	cmp	w19, #0x91
1000b8d5c: 54010f02    	b.hs	0x1000baf3c <_machine.machine.Group.execute+0x24fc>
1000b8d60: 52801508    	mov	w8, #0xa8               ; =168
1000b8d64: 90000e89    	adrp	x9, 0x100288000 <___anon_76546+0x18>
1000b8d68: 91068129    	add	x9, x9, #0x1a0
1000b8d6c: 9ba82668    	umaddl	x8, w19, w8, x9
1000b8d70: 912e83e0    	add	x0, sp, #0xba0
1000b8d74: 9117c3e2    	add	x2, sp, #0x5f0
1000b8d78: 9100c103    	add	x3, x8, #0x30
1000b8d7c: 97ff7c44    	bl	0x100097e8c <_machine.verify.count>
1000b8d80: 396ea3e8    	ldrb	w8, [sp, #0xba8]
1000b8d84: 360007a8    	tbz	w8, #0x0, 0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d88: f945d3f8    	ldr	x24, [sp, #0xba0]
1000b8d8c: b4000778    	cbz	x24, 0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d90: f9401281    	ldr	x1, [x20, #0x20]
1000b8d94: eb01031f    	cmp	x24, x1
1000b8d98: 54000708    	b.hi	0x1000b8e78 <_machine.machine.Group.execute+0x438>
1000b8d9c: f100231f    	cmp	x24, #0x8
1000b8da0: 54000068    	b.hi	0x1000b8dac <_machine.machine.Group.execute+0x36c>
1000b8da4: 911003f7    	add	x23, sp, #0x400
1000b8da8: 14000018    	b	0x1000b8e08 <_machine.machine.Group.execute+0x3c8>
1000b8dac: 52800608    	mov	w8, #0x30               ; =48
1000b8db0: 9bc87f08    	umulh	x8, x24, x8
1000b8db4: eb0803ff    	cmp	xzr, x8
1000b8db8: 540096a1    	b.ne	0x1000ba08c <_machine.machine.Group.execute+0x164c>
1000b8dbc: 8b180708    	add	x8, x24, x24, lsl #1
1000b8dc0: d37ced1a    	lsl	x26, x8, #4
1000b8dc4: f94017e3    	ldr	x3, [sp, #0x28]
1000b8dc8: dac143e3    	xpaci	x3
1000b8dcc: f9400328    	ldr	x8, [x25]
1000b8dd0: aa1703e0    	mov	x0, x23
1000b8dd4: aa1a03e1    	mov	x1, x26
1000b8dd8: 52800082    	mov	w2, #0x4                ; =4
1000b8ddc: d63f0100    	blr	x8
1000b8de0: b4009560    	cbz	x0, 0x1000ba08c <_machine.machine.Group.execute+0x164c>
1000b8de4: aa0003f7    	mov	x23, x0
1000b8de8: 52801541    	mov	w1, #0xaa               ; =170
1000b8dec: aa1a03e2    	mov	x2, x26
1000b8df0: 940515a6    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b8df4: f2400eff    	tst	x23, #0xf
1000b8df8: 54010ac1    	b.ne	0x1000baf50 <_machine.machine.Group.execute+0x2510>
1000b8dfc: f902c3f7    	str	x23, [sp, #0x580]
1000b8e00: f902c7f8    	str	x24, [sp, #0x588]
1000b8e04: f9401281    	ldr	x1, [x20, #0x20]
1000b8e08: eb180020    	subs	x0, x1, x24
1000b8e0c: 54010663    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8e10: eb00003f    	cmp	x1, x0
1000b8e14: 54010ac3    	b.lo	0x1000baf6c <_machine.machine.Group.execute+0x252c>
1000b8e18: cb000028    	sub	x8, x1, x0
1000b8e1c: eb08031f    	cmp	x24, x8
1000b8e20: 54010a41    	b.ne	0x1000baf68 <_machine.machine.Group.execute+0x2528>
1000b8e24: f9400e88    	ldr	x8, [x20, #0x18]
1000b8e28: 52800609    	mov	w9, #0x30               ; =48
1000b8e2c: 9b092019    	madd	x25, x0, x9, x8
1000b8e30: aa1803fa    	mov	x26, x24
1000b8e34: ad400720    	ldp	q0, q1, [x25]
1000b8e38: ad3a07a0    	stp	q0, q1, [x29, #-0xc0]
1000b8e3c: 3dc00b20    	ldr	q0, [x25, #0x20]
1000b8e40: 3c9603a0    	stur	q0, [x29, #-0xa0]
1000b8e44: 913003e0    	add	x0, sp, #0xc00
1000b8e48: d10303a1    	sub	x1, x29, #0xc0
1000b8e4c: 94013690    	bl	0x10010688c <_machine.machine.retainSlot>
1000b8e50: 3dc303e0    	ldr	q0, [sp, #0xc00]
1000b8e54: 3dc307e1    	ldr	q1, [sp, #0xc10]
1000b8e58: ad0006e0    	stp	q0, q1, [x23]
1000b8e5c: 3dc30be0    	ldr	q0, [sp, #0xc20]
1000b8e60: 3d800ae0    	str	q0, [x23, #0x20]
1000b8e64: 9100c339    	add	x25, x25, #0x30
1000b8e68: 9100c2f7    	add	x23, x23, #0x30
1000b8e6c: f100075a    	subs	x26, x26, #0x1
1000b8e70: 54fffe21    	b.ne	0x1000b8e34 <_machine.machine.Group.execute+0x3f4>
1000b8e74: f902cbf8    	str	x24, [sp, #0x590]
1000b8e78: b9403e88    	ldr	w8, [x20, #0x3c]
1000b8e7c: 31000508    	adds	w8, w8, #0x1
1000b8e80: 540102c2    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8e84: b9003e88    	str	w8, [x20, #0x3c]
1000b8e88: b0000ec8    	adrp	x8, 0x100291000 <___anon_84269+0x9d0>
1000b8e8c: 913a4108    	add	x8, x8, #0xe90
1000b8e90: ad420101    	ldp	q1, q0, [x8, #0x40]
1000b8e94: ad0303e1    	stp	q1, q0, [sp, #0x60]
1000b8e98: 3d819be1    	str	q1, [sp, #0x660]
1000b8e9c: 3d819fe0    	str	q0, [sp, #0x670]
1000b8ea0: f9403117    	ldr	x23, [x8, #0x60]
1000b8ea4: f90343f7    	str	x23, [sp, #0x680]
1000b8ea8: ad400101    	ldp	q1, q0, [x8]
1000b8eac: ad0403e1    	stp	q1, q0, [sp, #0x80]
1000b8eb0: 3d818be1    	str	q1, [sp, #0x620]
1000b8eb4: 3d818fe0    	str	q0, [sp, #0x630]
1000b8eb8: ad410500    	ldp	q0, q1, [x8, #0x20]
1000b8ebc: ad0503e1    	stp	q1, q0, [sp, #0xa0]
1000b8ec0: 3d8197e1    	str	q1, [sp, #0x650]
1000b8ec4: 3d8193e0    	str	q0, [sp, #0x640]
1000b8ec8: 911a23e0    	add	x0, sp, #0x688
1000b8ecc: 9117c3e4    	add	x4, sp, #0x5f0
1000b8ed0: 911883e5    	add	x5, sp, #0x620
1000b8ed4: aa1503e1    	mov	x1, x21
1000b8ed8: aa1603e2    	mov	x2, x22
1000b8edc: aa1403e3    	mov	x3, x20
1000b8ee0: 97ffd668    	bl	0x1000ae880 <_machine.machine.Group.instruction>
1000b8ee4: 794db3f4    	ldrh	w20, [sp, #0x6d8]
1000b8ee8: f9001bfc    	str	x28, [sp, #0x30]
1000b8eec: 35000374    	cbnz	w20, 0x1000b8f58 <_machine.machine.Group.execute+0x518>
1000b8ef0: 911a23e8    	add	x8, sp, #0x688
1000b8ef4: ad418101    	ldp	q1, q0, [x8, #0x30]
1000b8ef8: 3d81cbe0    	str	q0, [sp, #0x720]
1000b8efc: ad408900    	ldp	q0, q2, [x8, #0x10]
1000b8f00: 3d81c3e2    	str	q2, [sp, #0x700]
1000b8f04: 3d81c7e1    	str	q1, [sp, #0x710]
1000b8f08: 3dc00101    	ldr	q1, [x8]
1000b8f0c: 3d81bfe0    	str	q0, [sp, #0x6f0]
1000b8f10: 3d81bbe1    	str	q1, [sp, #0x6e0]
1000b8f14: 395ca3e8    	ldrb	w8, [sp, #0x728]
1000b8f18: 12000d08    	and	w8, w8, #0xf
1000b8f1c: 7100311f    	cmp	w8, #0xc
1000b8f20: 54007500    	b.eq	0x1000b9dc0 <_machine.machine.Group.execute+0x1380>
1000b8f24: 911b83fa    	add	x26, sp, #0x6e0
1000b8f28: f94023fc    	ldr	x28, [sp, #0x40]
1000b8f2c: 395a07e8    	ldrb	w8, [sp, #0x681]
1000b8f30: b9405fe9    	ldr	w9, [sp, #0x5c]
1000b8f34: 360003e9    	tbz	w9, #0x0, 0x1000b8fb0 <_machine.machine.Group.execute+0x570>
1000b8f38: 360003c8    	tbz	w8, #0x0, 0x1000b8fb0 <_machine.machine.Group.execute+0x570>
1000b8f3c: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b8f40: f940fec9    	ldr	x9, [x22, #0x1f8]
1000b8f44: ab090108    	adds	x8, x8, x9
1000b8f48: 5400fc82    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8f4c: f9005ac8    	str	x8, [x22, #0xb0]
1000b8f50: f900fedf    	str	xzr, [x22, #0x1f8]
1000b8f54: 14000084    	b	0x1000b9164 <_machine.machine.Group.execute+0x724>
1000b8f58: 71028e9f    	cmp	w20, #0xa3
1000b8f5c: 5400deec    	b.gt	0x1000bab38 <_machine.machine.Group.execute+0x20f8>
1000b8f60: 7102869f    	cmp	w20, #0xa1
1000b8f64: 5400e680    	b.eq	0x1000bac34 <_machine.machine.Group.execute+0x21f4>
1000b8f68: 71028e9f    	cmp	w20, #0xa3
1000b8f6c: 5400e9c1    	b.ne	0x1000baca4 <_machine.machine.Group.execute+0x2264>
1000b8f70: 911ce3e0    	add	x0, sp, #0x738
1000b8f74: 9117c3e3    	add	x3, sp, #0x5f0
1000b8f78: aa1503e1    	mov	x1, x21
1000b8f7c: aa1603e2    	mov	x2, x22
1000b8f80: 97fff85b    	bl	0x1000b70ec <_machine.machine.Group.completeError>
1000b8f84: 794e83f4    	ldrh	w20, [sp, #0x740]
1000b8f88: 3500fab4    	cbnz	w20, 0x1000baedc <_machine.machine.Group.execute+0x249c>
1000b8f8c: f9439fe8    	ldr	x8, [sp, #0x738]
1000b8f90: f903a7e8    	str	x8, [sp, #0x748]
1000b8f94: 52800068    	mov	w8, #0x3                ; =3
1000b8f98: 391e43e8    	strb	w8, [sp, #0x790]
1000b8f9c: 911d23fa    	add	x26, sp, #0x748
1000b8fa0: f9400bfc    	ldr	x28, [sp, #0x10]
1000b8fa4: 395a07e8    	ldrb	w8, [sp, #0x681]
1000b8fa8: b9405fe9    	ldr	w9, [sp, #0x5c]
1000b8fac: 3707fc69    	tbnz	w9, #0x0, 0x1000b8f38 <_machine.machine.Group.execute+0x4f8>
1000b8fb0: b94027e9    	ldr	w9, [sp, #0x24]
1000b8fb4: 2a080128    	orr	w8, w9, w8
1000b8fb8: 37000d68    	tbnz	w8, #0x0, 0x1000b9164 <_machine.machine.Group.execute+0x724>
1000b8fbc: 910503e0    	add	x0, sp, #0x140
1000b8fc0: 911883e2    	add	x2, sp, #0x620
1000b8fc4: aa1303e1    	mov	x1, x19
1000b8fc8: 94012fda    	bl	0x100104f30 <_machine.costs.chargeInstruction>
1000b8fcc: f940a3e8    	ldr	x8, [sp, #0x140]
1000b8fd0: f940fed4    	ldr	x20, [x22, #0x1f8]
1000b8fd4: ab140119    	adds	x25, x8, x20
1000b8fd8: 5400f802    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b8fdc: f940a7f8    	ldr	x24, [sp, #0x148]
1000b8fe0: f900fedf    	str	xzr, [x22, #0x1f8]
1000b8fe4: 39412348    	ldrb	w8, [x26, #0x48]
1000b8fe8: 51002909    	sub	w9, w8, #0xa
1000b8fec: 7100093f    	cmp	w9, #0x2
1000b8ff0: 540000e2    	b.hs	0x1000b900c <_machine.machine.Group.execute+0x5cc>
1000b8ff4: 52800028    	mov	w8, #0x1                ; =1
1000b8ff8: f94272ca    	ldr	x10, [x22, #0x4e0]
1000b8ffc: 90000ba9    	adrp	x9, 0x10022c000 <___anon_29839+0x18>
1000b9000: 913e0929    	add	x9, x9, #0xf82
1000b9004: b50007aa    	cbnz	x10, 0x1000b90f8 <_machine.machine.Group.execute+0x6b8>
1000b9008: 14000014    	b	0x1000b9058 <_machine.machine.Group.execute+0x618>
1000b900c: 7100051f    	cmp	w8, #0x1
1000b9010: 54000161    	b.ne	0x1000b903c <_machine.machine.Group.execute+0x5fc>
1000b9014: f9404ec8    	ldr	x8, [x22, #0x98]
1000b9018: f1000508    	subs	x8, x8, #0x1
1000b901c: 5400f5e3    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9020: f94272ca    	ldr	x10, [x22, #0x4e0]
1000b9024: eb0a011f    	cmp	x8, x10
1000b9028: 1a9f17e8    	cset	w8, eq
1000b902c: f0000b89    	adrp	x9, 0x10022c000 <___anon_29839+0x18>
1000b9030: 913e0929    	add	x9, x9, #0xf82
1000b9034: b500062a    	cbnz	x10, 0x1000b90f8 <_machine.machine.Group.execute+0x6b8>
1000b9038: 14000008    	b	0x1000b9058 <_machine.machine.Group.execute+0x618>
1000b903c: 7100351f    	cmp	w8, #0xd
1000b9040: 5400f702    	b.hs	0x1000baf20 <_machine.machine.Group.execute+0x24e0>
1000b9044: 52800008    	mov	w8, #0x0                ; =0
1000b9048: f94272ca    	ldr	x10, [x22, #0x4e0]
1000b904c: f0000b89    	adrp	x9, 0x10022c000 <___anon_29839+0x18>
1000b9050: 913e0929    	add	x9, x9, #0xf82
1000b9054: b500052a    	cbnz	x10, 0x1000b90f8 <_machine.machine.Group.execute+0x6b8>
1000b9058: 34000128    	cbz	w8, 0x1000b907c <_machine.machine.Group.execute+0x63c>
1000b905c: f9423ac0    	ldr	x0, [x22, #0x470]
1000b9060: 9400260d    	bl	0x1000c2894 <_machine.machine.Group.persistentState>
1000b9064: f9423ac8    	ldr	x8, [x22, #0x470]
1000b9068: f9412108    	ldr	x8, [x8, #0x240]
1000b906c: b0000ae9    	adrp	x9, 0x100216000 <___anon_78196+0x40>
1000b9070: 91258129    	add	x9, x9, #0x960
1000b9074: eb08001f    	cmp	x0, x8
1000b9078: 54000408    	b.hi	0x1000b90f8 <_machine.machine.Group.execute+0x6b8>
1000b907c: 394c82c9    	ldrb	w9, [x22, #0x320]
1000b9080: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b9084: 36000189    	tbz	w9, #0x0, 0x1000b90b4 <_machine.machine.Group.execute+0x674>
1000b9088: f9418ec9    	ldr	x9, [x22, #0x318]
1000b908c: eb090108    	subs	x8, x8, x9
1000b9090: 5400f243    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9094: f940fac9    	ldr	x9, [x22, #0x1f0]
1000b9098: 9ac86529    	umax	x9, x9, x8
1000b909c: cb080128    	sub	x8, x9, x8
1000b90a0: b0000ae9    	adrp	x9, 0x100216000 <___anon_78196+0x40>
1000b90a4: 91258929    	add	x9, x9, #0x962
1000b90a8: eb08033f    	cmp	x25, x8
1000b90ac: 54000129    	b.ls	0x1000b90d0 <_machine.machine.Group.execute+0x690>
1000b90b0: 14000012    	b	0x1000b90f8 <_machine.machine.Group.execute+0x6b8>
1000b90b4: f940dac9    	ldr	x9, [x22, #0x1b0]
1000b90b8: 9ac86529    	umax	x9, x9, x8
1000b90bc: cb080128    	sub	x8, x9, x8
1000b90c0: b0000ae9    	adrp	x9, 0x100216000 <___anon_78196+0x40>
1000b90c4: 91258929    	add	x9, x9, #0x962
1000b90c8: eb08033f    	cmp	x25, x8
1000b90cc: 54000168    	b.hi	0x1000b90f8 <_machine.machine.Group.execute+0x6b8>
1000b90d0: f9405ec8    	ldr	x8, [x22, #0xb8]
1000b90d4: ab180108    	adds	x8, x8, x24
1000b90d8: 5400f002    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b90dc: f940dec9    	ldr	x9, [x22, #0x1b8]
1000b90e0: eb09011f    	cmp	x8, x9
1000b90e4: f0000b88    	adrp	x8, 0x10022c000 <___anon_29839+0x18>
1000b90e8: 913e0908    	add	x8, x8, #0xf82
1000b90ec: 90000ba9    	adrp	x9, 0x10022d000 <___anon_149584+0x8>
1000b90f0: 91070129    	add	x9, x9, #0x1c0
1000b90f4: 9a888129    	csel	x9, x9, x8, hi
1000b90f8: 39400528    	ldrb	w8, [x9, #0x1]
1000b90fc: 37006f28    	tbnz	w8, #0x0, 0x1000b9ee0 <_machine.machine.Group.execute+0x14a0>
1000b9100: f9405ac8    	ldr	x8, [x22, #0xb0]
1000b9104: ab190108    	adds	x8, x8, x25
1000b9108: 5400ee82    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b910c: f9005ac8    	str	x8, [x22, #0xb0]
1000b9110: f9405ec8    	ldr	x8, [x22, #0xb8]
1000b9114: ab180108    	adds	x8, x8, x24
1000b9118: 5400ee02    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b911c: f9005ec8    	str	x8, [x22, #0xb8]
1000b9120: 39412348    	ldrb	w8, [x26, #0x48]
1000b9124: 12000d08    	and	w8, w8, #0xf
1000b9128: 7100251f    	cmp	w8, #0x9
1000b912c: 540001c1    	b.ne	0x1000b9164 <_machine.machine.Group.execute+0x724>
1000b9130: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b9134: b5000188    	cbnz	x8, 0x1000b9164 <_machine.machine.Group.execute+0x724>
1000b9138: f9423ac0    	ldr	x0, [x22, #0x470]
1000b913c: 940025d6    	bl	0x1000c2894 <_machine.machine.Group.persistentState>
1000b9140: aa0003f3    	mov	x19, x0
1000b9144: aa1603e0    	mov	x0, x22
1000b9148: 9400233e    	bl	0x1000c1e40 <_machine.machine.Group.runSize>
1000b914c: ab000268    	adds	x8, x19, x0
1000b9150: 5400ec42    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9154: f9423ac9    	ldr	x9, [x22, #0x470]
1000b9158: f9412129    	ldr	x9, [x9, #0x240]
1000b915c: eb09011f    	cmp	x8, x9
1000b9160: 5400a048    	b.hi	0x1000ba568 <_machine.machine.Group.execute+0x1b28>
1000b9164: f94313e0    	ldr	x0, [sp, #0x620]
1000b9168: b4000040    	cbz	x0, 0x1000b9170 <_machine.machine.Group.execute+0x730>
1000b916c: 97fea21e    	bl	0x1000619e4 <_value.Value.release>
1000b9170: f94317e0    	ldr	x0, [sp, #0x628]
1000b9174: b4000040    	cbz	x0, 0x1000b917c <_machine.machine.Group.execute+0x73c>
1000b9178: 97fea21b    	bl	0x1000619e4 <_value.Value.release>
1000b917c: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000b9180: 3d819be1    	str	q1, [sp, #0x660]
1000b9184: 3d819fe0    	str	q0, [sp, #0x670]
1000b9188: f90343f7    	str	x23, [sp, #0x680]
1000b918c: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000b9190: 3d818be1    	str	q1, [sp, #0x620]
1000b9194: 3d818fe0    	str	q0, [sp, #0x630]
1000b9198: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000b919c: 3d8197e1    	str	q1, [sp, #0x650]
1000b91a0: 3d8193e0    	str	q0, [sp, #0x640]
1000b91a4: 39412348    	ldrb	w8, [x26, #0x48]
1000b91a8: 12000d09    	and	w9, w8, #0xf
1000b91ac: 7100313f    	cmp	w9, #0xc
1000b91b0: 5400eb88    	b.hi	0x1000baf20 <_machine.machine.Group.execute+0x24e0>
1000b91b4: d0000a2b    	adrp	x11, 0x1001ff000 <_writev+0x1001ff000>
1000b91b8: 913f716b    	add	x11, x11, #0xfdc
1000b91bc: 10000089    	adr	x9, 0x1000b91cc <_machine.machine.Group.execute+0x78c>
1000b91c0: 7868796a    	ldrh	w10, [x11, x8, lsl #1]
1000b91c4: 8b0a0929    	add	x9, x9, x10, lsl #2
1000b91c8: d61f0120    	br	x9
1000b91cc: f9400353    	ldr	x19, [x26]
1000b91d0: aa1503e0    	mov	x0, x21
1000b91d4: aa1603e1    	mov	x1, x22
1000b91d8: 97feef0d    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b91dc: f9404ec1    	ldr	x1, [x22, #0x98]
1000b91e0: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b91e4: eb08003f    	cmp	x1, x8
1000b91e8: 54007a80    	b.eq	0x1000ba138 <_machine.machine.Group.execute+0x16f8>
1000b91ec: f1000420    	subs	x0, x1, #0x1
1000b91f0: 5400e743    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b91f4: eb01001f    	cmp	x0, x1
1000b91f8: 5400e822    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b91fc: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9200: 52800909    	mov	w9, #0x48               ; =72
1000b9204: 9b092014    	madd	x20, x0, x9, x8
1000b9208: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b920c: 3d8303e0    	str	q0, [sp, #0xc00]
1000b9210: f9401288    	ldr	x8, [x20, #0x20]
1000b9214: b1000502    	adds	x2, x8, #0x1
1000b9218: 5400e602    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b921c: 91006280    	add	x0, x20, #0x18
1000b9220: 913003e1    	add	x1, sp, #0xc00
1000b9224: 97ff8320    	bl	0x100099ea4 <_array_list.Aligned(machine.machine.Slot,null).ensureTotalCapacity>
1000b9228: 72003c17    	ands	w23, w0, #0xffff
1000b922c: 5400dce1    	b.ne	0x1000badc8 <_machine.machine.Group.execute+0x2388>
1000b9230: a9422688    	ldp	x8, x9, [x20, #0x20]
1000b9234: eb09011f    	cmp	x8, x9
1000b9238: 5400e682    	b.hs	0x1000baf08 <_machine.machine.Group.execute+0x24c8>
1000b923c: 91000509    	add	x9, x8, #0x1
1000b9240: f9001289    	str	x9, [x20, #0x20]
1000b9244: f9400e89    	ldr	x9, [x20, #0x18]
1000b9248: 5280060a    	mov	w10, #0x30              ; =48
1000b924c: 9b0a2508    	madd	x8, x8, x10, x9
1000b9250: f9000113    	str	x19, [x8]
1000b9254: 3900811f    	strb	wzr, [x8, #0x20]
1000b9258: 140002a8    	b	0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b925c: f9420ec8    	ldr	x8, [x22, #0x418]
1000b9260: b4000208    	cbz	x8, 0x1000b92a0 <_machine.machine.Group.execute+0x860>
1000b9264: f9420ac9    	ldr	x9, [x22, #0x410]
1000b9268: 5280160a    	mov	w10, #0xb0              ; =176
1000b926c: 9b0a2508    	madd	x8, x8, x10, x9
1000b9270: 385f8109    	ldurb	w9, [x8, #-0x8]
1000b9274: 36000169    	tbz	w9, #0x0, 0x1000b92a0 <_machine.machine.Group.execute+0x860>
1000b9278: 385d0109    	ldurb	w9, [x8, #-0x30]
1000b927c: 12000929    	and	w9, w9, #0x7
1000b9280: 7100053f    	cmp	w9, #0x1
1000b9284: 540000e1    	b.ne	0x1000b92a0 <_machine.machine.Group.execute+0x860>
1000b9288: f8550102    	ldur	x2, [x8, #-0xb0]
1000b928c: aa1503e0    	mov	x0, x21
1000b9290: aa1603e1    	mov	x1, x22
1000b9294: aa1b03e3    	mov	x3, x27
1000b9298: a94493e5    	ldp	x5, x4, [sp, #0x48]
1000b929c: 94001b27    	bl	0x1000bff38 <_machine.machine.Group.writeRaise>
1000b92a0: 9128a3e0    	add	x0, sp, #0xa28
1000b92a4: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b92a8: 12000103    	and	w3, w8, #0x1
1000b92ac: aa1503e1    	mov	x1, x21
1000b92b0: aa1603e2    	mov	x2, x22
1000b92b4: 94001785    	bl	0x1000bf0c8 <_machine.machine.Group.nextCleanup>
1000b92b8: 7954f3f3    	ldrh	w19, [sp, #0xa78]
1000b92bc: 3500d193    	cbnz	w19, 0x1000bacec <_machine.machine.Group.execute+0x22ac>
1000b92c0: 3969c3e8    	ldrb	w8, [sp, #0xa70]
1000b92c4: 360051a8    	tbz	w8, #0x0, 0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b92c8: 140003a7    	b	0x1000ba164 <_machine.machine.Group.execute+0x1724>
1000b92cc: f9420ec1    	ldr	x1, [x22, #0x418]
1000b92d0: f1000420    	subs	x0, x1, #0x1
1000b92d4: 5400e023    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b92d8: eb01001f    	cmp	x0, x1
1000b92dc: 5400e102    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b92e0: f9420ac8    	ldr	x8, [x22, #0x410]
1000b92e4: 52801609    	mov	w9, #0xb0               ; =176
1000b92e8: 9b092008    	madd	x8, x0, x9, x8
1000b92ec: 3942a109    	ldrb	w9, [x8, #0xa8]
1000b92f0: 3700e209    	tbnz	w9, #0x0, 0x1000baf30 <_machine.machine.Group.execute+0x24f0>
1000b92f4: f9400513    	ldr	x19, [x8, #0x8]
1000b92f8: f9404ec1    	ldr	x1, [x22, #0x98]
1000b92fc: eb01027f    	cmp	x19, x1
1000b9300: 5400e142    	b.hs	0x1000baf28 <_machine.machine.Group.execute+0x24e8>
1000b9304: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9308: 52800909    	mov	w9, #0x48               ; =72
1000b930c: 9b092268    	madd	x8, x19, x9, x8
1000b9310: b9403d18    	ldr	w24, [x8, #0x3c]
1000b9314: 3cc18100    	ldur	q0, [x8, #0x18]
1000b9318: 3cc28101    	ldur	q1, [x8, #0x28]
1000b931c: ad1b07e0    	stp	q0, q1, [sp, #0x360]
1000b9320: b0000ae9    	adrp	x9, 0x100216000 <___anon_78196+0x40>
1000b9324: 91030129    	add	x9, x9, #0xc0
1000b9328: ad400520    	ldp	q0, q1, [x9]
1000b932c: 3c818100    	stur	q0, [x8, #0x18]
1000b9330: 3c828101    	stur	q1, [x8, #0x28]
1000b9334: 913003e0    	add	x0, sp, #0xc00
1000b9338: aa1503e1    	mov	x1, x21
1000b933c: aa1603e2    	mov	x2, x22
1000b9340: 940016ac    	bl	0x1000bedf0 <_machine.machine.Group.endDispatch>
1000b9344: f94603f4    	ldr	x20, [sp, #0xc00]
1000b9348: f94607e3    	ldr	x3, [sp, #0xc08]
1000b934c: f94627e8    	ldr	x8, [sp, #0xc48]
1000b9350: b94c8be7    	ldr	w7, [sp, #0xc88]
1000b9354: b0000ae9    	adrp	x9, 0x100216000 <___anon_78196+0x40>
1000b9358: 91046129    	add	x9, x9, #0x118
1000b935c: ad400520    	ldp	q0, q1, [x9]
1000b9360: ad1c07e0    	stp	q0, q1, [sp, #0x380]
1000b9364: f1000504    	subs	x4, x8, #0x1
1000b9368: 5400db83    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b936c: 910e03e2    	add	x2, sp, #0x380
1000b9370: 913003e8    	add	x8, sp, #0xc00
1000b9374: 9101c106    	add	x6, x8, #0x70
1000b9378: aa1503e0    	mov	x0, x21
1000b937c: aa1603e1    	mov	x1, x22
1000b9380: 52800025    	mov	w5, #0x1                ; =1
1000b9384: 97fffc55    	bl	0x1000b84d8 <_machine.machine.Group.collect>
1000b9388: 72003c17    	ands	w23, w0, #0xffff
1000b938c: 5400ccc1    	b.ne	0x1000bad24 <_machine.machine.Group.execute+0x22e4>
1000b9390: ad5b07e0    	ldp	q0, q1, [sp, #0x360]
1000b9394: 912e83e8    	add	x8, sp, #0xba0
1000b9398: 3c808100    	stur	q0, [x8, #0x8]
1000b939c: 3c818101    	stur	q1, [x8, #0x18]
1000b93a0: f905d3f3    	str	x19, [sp, #0xba0]
1000b93a4: b90bcbf8    	str	w24, [sp, #0xbc8]
1000b93a8: 392fc3ff    	strb	wzr, [sp, #0xbf0]
1000b93ac: 910e03e3    	add	x3, sp, #0x380
1000b93b0: 912e83e4    	add	x4, sp, #0xba0
1000b93b4: aa1503e0    	mov	x0, x21
1000b93b8: aa1603e1    	mov	x1, x22
1000b93bc: aa1403e2    	mov	x2, x20
1000b93c0: 97fffd37    	bl	0x1000b889c <_machine.machine.Group.startCleanup>
1000b93c4: 72003c17    	ands	w23, w0, #0xffff
1000b93c8: 5400cca1    	b.ne	0x1000bad5c <_machine.machine.Group.execute+0x231c>
1000b93cc: d10303a0    	sub	x0, x29, #0xc0
1000b93d0: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b93d4: 12000103    	and	w3, w8, #0x1
1000b93d8: aa1503e1    	mov	x1, x21
1000b93dc: aa1603e2    	mov	x2, x22
1000b93e0: 9400173a    	bl	0x1000bf0c8 <_machine.machine.Group.nextCleanup>
1000b93e4: 785903b7    	ldurh	w23, [x29, #-0x70]
1000b93e8: 35006ef7    	cbnz	w23, 0x1000ba1c4 <_machine.machine.Group.execute+0x1784>
1000b93ec: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
1000b93f0: 3d82abe0    	str	q0, [sp, #0xaa0]
1000b93f4: 3d82afe1    	str	q1, [sp, #0xab0]
1000b93f8: f85803a8    	ldur	x8, [x29, #-0x80]
1000b93fc: f90563e8    	str	x8, [sp, #0xac0]
1000b9400: ad7a03a1    	ldp	q1, q0, [x29, #-0xc0]
1000b9404: 3d82a7e0    	str	q0, [sp, #0xa90]
1000b9408: 3d82a3e1    	str	q1, [sp, #0xa80]
1000b940c: 385883a8    	ldurb	w8, [x29, #-0x78]
1000b9410: 36004748    	tbz	w8, #0x0, 0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b9414: 140003b4    	b	0x1000ba2e4 <_machine.machine.Group.execute+0x18a4>
1000b9418: f9404ec1    	ldr	x1, [x22, #0x98]
1000b941c: f1000420    	subs	x0, x1, #0x1
1000b9420: 1a9f27e8    	cset	w8, lo
1000b9424: 5400d5a3    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9428: eb01001f    	cmp	x0, x1
1000b942c: 5400d682    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b9430: f9404ac9    	ldr	x9, [x22, #0x90]
1000b9434: 5280090a    	mov	w10, #0x48              ; =72
1000b9438: 9b0a7c0a    	mul	x10, x0, x10
1000b943c: f86a6929    	ldr	x9, [x9, x10]
1000b9440: b40017c9    	cbz	x9, 0x1000b9738 <_machine.machine.Group.execute+0xcf8>
1000b9444: 9101812b    	add	x11, x9, #0x60
1000b9448: f9400353    	ldr	x19, [x26]
1000b944c: f940456a    	ldr	x10, [x11, #0x88]
1000b9450: b50017ea    	cbnz	x10, 0x1000b974c <_machine.machine.Group.execute+0xd0c>
1000b9454: 14000227    	b	0x1000b9cf0 <_machine.machine.Group.execute+0x12b0>
1000b9458: 3dc00340    	ldr	q0, [x26]
1000b945c: 3d80bfe0    	str	q0, [sp, #0x2f0]
1000b9460: a9415353    	ldp	x19, x20, [x26, #0x10]
1000b9464: ad400780    	ldp	q0, q1, [x28]
1000b9468: 3d82cbe0    	str	q0, [sp, #0xb20]
1000b946c: 3d82cfe1    	str	q1, [sp, #0xb30]
1000b9470: f9401388    	ldr	x8, [x28, #0x20]
1000b9474: f905a3e8    	str	x8, [sp, #0xb40]
1000b9478: f9420ec8    	ldr	x8, [x22, #0x418]
1000b947c: 5280160c    	mov	w12, #0xb0              ; =176
1000b9480: b400d3c8    	cbz	x8, 0x1000baef8 <_machine.machine.Group.execute+0x24b8>
1000b9484: f9420ac9    	ldr	x9, [x22, #0x410]
1000b9488: 9b0c250a    	madd	x10, x8, x12, x9
1000b948c: 385f814b    	ldurb	w11, [x10, #-0x8]
1000b9490: 360007eb    	tbz	w11, #0x0, 0x1000b958c <_machine.machine.Group.execute+0xb4c>
1000b9494: 9b0c2509    	madd	x9, x8, x12, x9
1000b9498: d102e129    	sub	x9, x9, #0xb8
1000b949c: f1000508    	subs	x8, x8, #0x1
1000b94a0: 5400d2c0    	b.eq	0x1000baef8 <_machine.machine.Group.execute+0x24b8>
1000b94a4: d102c12a    	sub	x10, x9, #0xb0
1000b94a8: 3940012b    	ldrb	w11, [x9]
1000b94ac: aa0a03e9    	mov	x9, x10
1000b94b0: 3707ff6b    	tbnz	w11, #0x0, 0x1000b949c <_machine.machine.Group.execute+0xa5c>
1000b94b4: 91002158    	add	x24, x10, #0x8
1000b94b8: 14000036    	b	0x1000b9590 <_machine.machine.Group.execute+0xb50>
1000b94bc: f9400353    	ldr	x19, [x26]
1000b94c0: f942c7e1    	ldr	x1, [sp, #0x588]
1000b94c4: b4001101    	cbz	x1, 0x1000b96e4 <_machine.machine.Group.execute+0xca4>
1000b94c8: f942c3e0    	ldr	x0, [sp, #0x580]
1000b94cc: 1400008a    	b	0x1000b96f4 <_machine.machine.Group.execute+0xcb4>
1000b94d0: f9404ec1    	ldr	x1, [x22, #0x98]
1000b94d4: f1000420    	subs	x0, x1, #0x1
1000b94d8: 5400d003    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b94dc: eb01001f    	cmp	x0, x1
1000b94e0: 5400d0e2    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b94e4: f9404ac8    	ldr	x8, [x22, #0x90]
1000b94e8: 52800909    	mov	w9, #0x48               ; =72
1000b94ec: 9b09201c    	madd	x28, x0, x9, x8
1000b94f0: 39410788    	ldrb	w8, [x28, #0x41]
1000b94f4: 360059c8    	tbz	w8, #0x0, 0x1000ba02c <_machine.machine.Group.execute+0x15ec>
1000b94f8: f94272c8    	ldr	x8, [x22, #0x4e0]
1000b94fc: eb08001f    	cmp	x0, x8
1000b9500: 54005969    	b.ls	0x1000ba02c <_machine.machine.Group.execute+0x15ec>
1000b9504: f940039a    	ldr	x26, [x28]
1000b9508: b40014da    	cbz	x26, 0x1000b97a0 <_machine.machine.Group.execute+0xd60>
1000b950c: 91018357    	add	x23, x26, #0x60
1000b9510: b9403b9b    	ldr	w27, [x28, #0x38]
1000b9514: f94036e1    	ldr	x1, [x23, #0x68]
1000b9518: eb1b003f    	cmp	x1, x27
1000b951c: 540014e8    	b.hi	0x1000b97b8 <_machine.machine.Group.execute+0xd78>
1000b9520: 14000678    	b	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b9524: 913003e0    	add	x0, sp, #0xc00
1000b9528: aa1503e1    	mov	x1, x21
1000b952c: aa1603e2    	mov	x2, x22
1000b9530: 94001630    	bl	0x1000bedf0 <_machine.machine.Group.endDispatch>
1000b9534: f94603e3    	ldr	x3, [sp, #0xc00]
1000b9538: d10303a0    	sub	x0, x29, #0xc0
1000b953c: 913003e8    	add	x8, sp, #0xc00
1000b9540: 91010104    	add	x4, x8, #0x40
1000b9544: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9548: 12000105    	and	w5, w8, #0x1
1000b954c: aa1503e1    	mov	x1, x21
1000b9550: aa1603e2    	mov	x2, x22
1000b9554: 94001cb1    	bl	0x1000c0818 <_machine.machine.Group.search>
1000b9558: ad7b07a0    	ldp	q0, q1, [x29, #-0xa0]
1000b955c: 3d82bfe0    	str	q0, [sp, #0xaf0]
1000b9560: 3d82c3e1    	str	q1, [sp, #0xb00]
1000b9564: f85803a8    	ldur	x8, [x29, #-0x80]
1000b9568: f9058be8    	str	x8, [sp, #0xb10]
1000b956c: ad7a03a1    	ldp	q1, q0, [x29, #-0xc0]
1000b9570: 3d82bbe0    	str	q0, [sp, #0xae0]
1000b9574: 3d82b7e1    	str	q1, [sp, #0xad0]
1000b9578: 785903b3    	ldurh	w19, [x29, #-0x70]
1000b957c: 3500baf3    	cbnz	w19, 0x1000bacd8 <_machine.machine.Group.execute+0x2298>
1000b9580: 385883a8    	ldurb	w8, [x29, #-0x78]
1000b9584: 36003ba8    	tbz	w8, #0x0, 0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b9588: 140002ff    	b	0x1000ba184 <_machine.machine.Group.execute+0x1744>
1000b958c: d102c158    	sub	x24, x10, #0xb0
1000b9590: b0000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000b9594: 91046108    	add	x8, x8, #0x118
1000b9598: ad400500    	ldp	q0, q1, [x8]
1000b959c: 3d82ebe0    	str	q0, [sp, #0xba0]
1000b95a0: 3d82efe1    	str	q1, [sp, #0xbb0]
1000b95a4: f9402708    	ldr	x8, [x24, #0x48]
1000b95a8: f1000504    	subs	x4, x8, #0x1
1000b95ac: 5400c963    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b95b0: f9400703    	ldr	x3, [x24, #0x8]
1000b95b4: 912e83e2    	add	x2, sp, #0xba0
1000b95b8: aa1503e0    	mov	x0, x21
1000b95bc: aa1603e1    	mov	x1, x22
1000b95c0: 52800025    	mov	w5, #0x1                ; =1
1000b95c4: b0000ae6    	adrp	x6, 0x100216000 <___anon_78196+0x40>
1000b95c8: 910400c6    	add	x6, x6, #0x100
1000b95cc: aa1b03e7    	mov	x7, x27
1000b95d0: 97fffbc2    	bl	0x1000b84d8 <_machine.machine.Group.collect>
1000b95d4: 72003c19    	ands	w25, w0, #0xffff
1000b95d8: 5400bb01    	b.ne	0x1000bad38 <_machine.machine.Group.execute+0x22f8>
1000b95dc: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b95e0: 3d80f3e0    	str	q0, [sp, #0x3c0]
1000b95e4: f945d7e8    	ldr	x8, [sp, #0xba8]
1000b95e8: b1000502    	adds	x2, x8, #0x1
1000b95ec: 5400c762    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b95f0: 912e83e0    	add	x0, sp, #0xba0
1000b95f4: 910f03e1    	add	x1, sp, #0x3c0
1000b95f8: 97fdb038    	bl	0x1000256d8 <_array_list.Aligned(machine.machine.Cleanup,null).ensureTotalCapacity>
1000b95fc: 72003c19    	ands	w25, w0, #0xffff
1000b9600: 5400bba1    	b.ne	0x1000bad74 <_machine.machine.Group.execute+0x2334>
1000b9604: f945d7e8    	ldr	x8, [sp, #0xba8]
1000b9608: f945dbfa    	ldr	x26, [sp, #0xbb0]
1000b960c: eb1a011f    	cmp	x8, x26
1000b9610: 5400c7c2    	b.hs	0x1000baf08 <_machine.machine.Group.execute+0x24c8>
1000b9614: 91000509    	add	x9, x8, #0x1
1000b9618: f905d7e9    	str	x9, [sp, #0xba8]
1000b961c: f945d3f7    	ldr	x23, [sp, #0xba0]
1000b9620: 8b0816e8    	add	x8, x23, x8, lsl #5
1000b9624: b0000ae9    	adrp	x9, 0x100216000 <___anon_78196+0x40>
1000b9628: 911aa129    	add	x9, x9, #0x6a8
1000b962c: ad400520    	ldp	q0, q1, [x9]
1000b9630: ad000500    	stp	q0, q1, [x8]
1000b9634: f9400302    	ldr	x2, [x24]
1000b9638: f9406048    	ldr	x8, [x2, #0xc0]
1000b963c: b1000508    	adds	x8, x8, #0x1
1000b9640: 5400c4c2    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9644: f9006048    	str	x8, [x2, #0xc0]
1000b9648: 3dc0bfe0    	ldr	q0, [sp, #0x2f0]
1000b964c: 3c9403a0    	stur	q0, [x29, #-0xc0]
1000b9650: a93553b3    	stp	x19, x20, [x29, #-0xb0]
1000b9654: 3dc2cbe0    	ldr	q0, [sp, #0xb20]
1000b9658: 3dc2cfe1    	ldr	q1, [sp, #0xb30]
1000b965c: d10303a9    	sub	x9, x29, #0xc0
1000b9660: ad010520    	stp	q0, q1, [x9, #0x20]
1000b9664: f945a3e8    	ldr	x8, [sp, #0xb40]
1000b9668: f8040128    	stur	x8, [x9, #0x40]
1000b966c: 52800068    	mov	w8, #0x3                ; =3
1000b9670: 381903a8    	sturb	w8, [x29, #-0x70]
1000b9674: 912e83e3    	add	x3, sp, #0xba0
1000b9678: d10303a4    	sub	x4, x29, #0xc0
1000b967c: aa1503e0    	mov	x0, x21
1000b9680: aa1603e1    	mov	x1, x22
1000b9684: 97fffc86    	bl	0x1000b889c <_machine.machine.Group.startCleanup>
1000b9688: 72003c19    	ands	w25, w0, #0xffff
1000b968c: 5400b861    	b.ne	0x1000bad98 <_machine.machine.Group.execute+0x2358>
1000b9690: 913003e0    	add	x0, sp, #0xc00
1000b9694: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9698: 12000103    	and	w3, w8, #0x1
1000b969c: aa1503e1    	mov	x1, x21
1000b96a0: aa1603e2    	mov	x2, x22
1000b96a4: 94001689    	bl	0x1000bf0c8 <_machine.machine.Group.nextCleanup>
1000b96a8: 7958a3f9    	ldrh	w25, [sp, #0xc50]
1000b96ac: 35005c39    	cbnz	w25, 0x1000ba230 <_machine.machine.Group.execute+0x17f0>
1000b96b0: 3dc30be0    	ldr	q0, [sp, #0xc20]
1000b96b4: 3dc30fe1    	ldr	q1, [sp, #0xc30]
1000b96b8: 3d82dfe0    	str	q0, [sp, #0xb70]
1000b96bc: 3d82e3e1    	str	q1, [sp, #0xb80]
1000b96c0: f94623e8    	ldr	x8, [sp, #0xc40]
1000b96c4: f905cbe8    	str	x8, [sp, #0xb90]
1000b96c8: 3dc307e0    	ldr	q0, [sp, #0xc10]
1000b96cc: 3dc303e1    	ldr	q1, [sp, #0xc00]
1000b96d0: 3d82dbe0    	str	q0, [sp, #0xb60]
1000b96d4: 3d82d7e1    	str	q1, [sp, #0xb50]
1000b96d8: 397123e8    	ldrb	w8, [sp, #0xc48]
1000b96dc: 360030e8    	tbz	w8, #0x0, 0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b96e0: 14000309    	b	0x1000ba304 <_machine.machine.Group.execute+0x18c4>
1000b96e4: f942cbe1    	ldr	x1, [sp, #0x590]
1000b96e8: f100243f    	cmp	x1, #0x9
1000b96ec: 5400c382    	b.hs	0x1000baf5c <_machine.machine.Group.execute+0x251c>
1000b96f0: 911003e0    	add	x0, sp, #0x400
1000b96f4: 94001b1f    	bl	0x1000c0370 <_machine.machine.stackSize>
1000b96f8: f9013aa0    	str	x0, [x21, #0x270]
1000b96fc: 912743e0    	add	x0, sp, #0x9d0
1000b9700: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9704: 12000107    	and	w7, w8, #0x1
1000b9708: aa1503e1    	mov	x1, x21
1000b970c: aa1603e2    	mov	x2, x22
1000b9710: aa1303e3    	mov	x3, x19
1000b9714: aa1b03e4    	mov	x4, x27
1000b9718: a94497e6    	ldp	x6, x5, [sp, #0x48]
1000b971c: 97fffa28    	bl	0x1000b7fbc <_machine.machine.Group.unwind>
1000b9720: 795443f3    	ldrh	w19, [sp, #0xa20]
1000b9724: 3500aef3    	cbnz	w19, 0x1000bad00 <_machine.machine.Group.execute+0x22c0>
1000b9728: 396863e8    	ldrb	w8, [sp, #0xa18]
1000b972c: f9013abf    	str	xzr, [x21, #0x270]
1000b9730: 36002e48    	tbz	w8, #0x0, 0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b9734: 1400029c    	b	0x1000ba1a4 <_machine.machine.Group.execute+0x1764>
1000b9738: f9423aca    	ldr	x10, [x22, #0x470]
1000b973c: 9101e14b    	add	x11, x10, #0x78
1000b9740: f9400353    	ldr	x19, [x26]
1000b9744: f940456a    	ldr	x10, [x11, #0x88]
1000b9748: b4002d4a    	cbz	x10, 0x1000b9cf0 <_machine.machine.Group.execute+0x12b0>
1000b974c: f940416b    	ldr	x11, [x11, #0x80]
1000b9750: 9100216b    	add	x11, x11, #0x8
1000b9754: 14000004    	b	0x1000b9764 <_machine.machine.Group.execute+0xd24>
1000b9758: 9100516b    	add	x11, x11, #0x14
1000b975c: f100054a    	subs	x10, x10, #0x1
1000b9760: 54002c80    	b.eq	0x1000b9cf0 <_machine.machine.Group.execute+0x12b0>
1000b9764: 3940216c    	ldrb	w12, [x11, #0x8]
1000b9768: 1200058c    	and	w12, w12, #0x3
1000b976c: 7100099f    	cmp	w12, #0x2
1000b9770: 54ffff41    	b.ne	0x1000b9758 <_machine.machine.Group.execute+0xd18>
1000b9774: 297f316d    	ldp	w13, w12, [x11, #-0x8]
1000b9778: 6b1b01bf    	cmp	w13, w27
1000b977c: 7a4c9362    	ccmp	w27, w12, #0x2, ls
1000b9780: 54fffec8    	b.hi	0x1000b9758 <_machine.machine.Group.execute+0xd18>
1000b9784: f940017c    	ldr	x28, [x11]
1000b9788: f940e6b4    	ldr	x20, [x21, #0x1c8]
1000b978c: b4002614    	cbz	x20, 0x1000b9c4c <_machine.machine.Group.execute+0x120c>
1000b9790: b40019a9    	cbz	x9, 0x1000b9ac4 <_machine.machine.Group.execute+0x1084>
1000b9794: 9100c128    	add	x8, x9, #0x30
1000b9798: 9100e129    	add	x9, x9, #0x38
1000b979c: 140000cd    	b	0x1000b9ad0 <_machine.machine.Group.execute+0x1090>
1000b97a0: f9423ac8    	ldr	x8, [x22, #0x470]
1000b97a4: 9101e117    	add	x23, x8, #0x78
1000b97a8: b9403b9b    	ldr	w27, [x28, #0x38]
1000b97ac: f94036e1    	ldr	x1, [x23, #0x68]
1000b97b0: eb1b003f    	cmp	x1, x27
1000b97b4: 5400ba69    	b.ls	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b97b8: f94032e8    	ldr	x8, [x23, #0x60]
1000b97bc: 52800b09    	mov	w9, #0x58               ; =88
1000b97c0: 9ba92368    	umaddl	x8, w27, w9, x8
1000b97c4: f9400d14    	ldr	x20, [x8, #0x18]
1000b97c8: d37dfe88    	lsr	x8, x20, #61
1000b97cc: b5004568    	cbnz	x8, 0x1000ba078 <_machine.machine.Group.execute+0x1638>
1000b97d0: f94017f3    	ldr	x19, [sp, #0x28]
1000b97d4: dac143f3    	xpaci	x19
1000b97d8: d37df299    	lsl	x25, x20, #3
1000b97dc: b4000494    	cbz	x20, 0x1000b986c <_machine.machine.Group.execute+0xe2c>
1000b97e0: a944a2a0    	ldp	x0, x8, [x21, #0x48]
1000b97e4: f9400108    	ldr	x8, [x8]
1000b97e8: aa1903e1    	mov	x1, x25
1000b97ec: 52800062    	mov	w2, #0x3                ; =3
1000b97f0: aa1303e3    	mov	x3, x19
1000b97f4: d63f0100    	blr	x8
1000b97f8: b4004400    	cbz	x0, 0x1000ba078 <_machine.machine.Group.execute+0x1638>
1000b97fc: aa0003f8    	mov	x24, x0
1000b9800: 52801541    	mov	w1, #0xaa               ; =170
1000b9804: aa1903e2    	mov	x2, x25
1000b9808: 94051320    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b980c: f2400b1f    	tst	x24, #0x7
1000b9810: 5400ba01    	b.ne	0x1000baf50 <_machine.machine.Group.execute+0x2510>
1000b9814: f9400b81    	ldr	x1, [x28, #0x10]
1000b9818: eb01029f    	cmp	x20, x1
1000b981c: 5400b962    	b.hs	0x1000baf48 <_machine.machine.Group.execute+0x2508>
1000b9820: d2800008    	mov	x8, #0x0                ; =0
1000b9824: f9400789    	ldr	x9, [x28, #0x8]
1000b9828: 91002129    	add	x9, x9, #0x8
1000b982c: f868792a    	ldr	x10, [x9, x8, lsl #3]
1000b9830: f940614b    	ldr	x11, [x10, #0xc0]
1000b9834: b100056b    	adds	x11, x11, #0x1
1000b9838: 5400b502    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b983c: f900614b    	str	x11, [x10, #0xc0]
1000b9840: f8287b0a    	str	x10, [x24, x8, lsl #3]
1000b9844: 91000508    	add	x8, x8, #0x1
1000b9848: eb08029f    	cmp	x20, x8
1000b984c: 54ffff01    	b.ne	0x1000b982c <_machine.machine.Group.execute+0xdec>
1000b9850: aa1503e0    	mov	x0, x21
1000b9854: aa1603e1    	mov	x1, x22
1000b9858: 97feed6d    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b985c: f94036e1    	ldr	x1, [x23, #0x68]
1000b9860: eb1b003f    	cmp	x1, x27
1000b9864: 54000188    	b.hi	0x1000b9894 <_machine.machine.Group.execute+0xe54>
1000b9868: 140005a6    	b	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b986c: f9400b81    	ldr	x1, [x28, #0x10]
1000b9870: eb01029f    	cmp	x20, x1
1000b9874: 5400b6a2    	b.hs	0x1000baf48 <_machine.machine.Group.execute+0x2508>
1000b9878: 928000f8    	mov	x24, #-0x8              ; =-8
1000b987c: aa1503e0    	mov	x0, x21
1000b9880: aa1603e1    	mov	x1, x22
1000b9884: 97feed62    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b9888: f94036e1    	ldr	x1, [x23, #0x68]
1000b988c: eb1b003f    	cmp	x1, x27
1000b9890: 5400b389    	b.ls	0x1000baf00 <_machine.machine.Group.execute+0x24c0>
1000b9894: 31000766    	adds	w6, w27, #0x1
1000b9898: 5400b202    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b989c: f94032e8    	ldr	x8, [x23, #0x60]
1000b98a0: 52800b09    	mov	w9, #0x58               ; =88
1000b98a4: 9ba92368    	umaddl	x8, w27, w9, x8
1000b98a8: a9401504    	ldp	x4, x5, [x8]
1000b98ac: f90003f4    	str	x20, [sp]
1000b98b0: 910ff3e0    	add	x0, sp, #0x3fc
1000b98b4: aa1503e1    	mov	x1, x21
1000b98b8: aa1603e2    	mov	x2, x22
1000b98bc: aa1a03e3    	mov	x3, x26
1000b98c0: aa1803e7    	mov	x7, x24
1000b98c4: 97ffc40e    	bl	0x1000aa8fc <_machine.machine.Group.nextClause>
1000b98c8: 7947fbf7    	ldrh	w23, [sp, #0x3fc]
1000b98cc: 3500a8d7    	cbnz	w23, 0x1000bade4 <_machine.machine.Group.execute+0x23a4>
1000b98d0: 394ffbe8    	ldrb	w8, [sp, #0x3fe]
1000b98d4: 36000368    	tbz	w8, #0x0, 0x1000b9940 <_machine.machine.Group.execute+0xf00>
1000b98d8: b4000274    	cbz	x20, 0x1000b9924 <_machine.machine.Group.execute+0xee4>
1000b98dc: d280001b    	mov	x27, #0x0               ; =0
1000b98e0: a944eab7    	ldp	x23, x26, [x21, #0x48]
1000b98e4: f87b7b00    	ldr	x0, [x24, x27, lsl #3]
1000b98e8: 97fea03f    	bl	0x1000619e4 <_value.Value.release>
1000b98ec: 9100077b    	add	x27, x27, #0x1
1000b98f0: eb1b029f    	cmp	x20, x27
1000b98f4: 54ffff81    	b.ne	0x1000b98e4 <_machine.machine.Group.execute+0xea4>
1000b98f8: aa1803e0    	mov	x0, x24
1000b98fc: 52801541    	mov	w1, #0xaa               ; =170
1000b9900: aa1903e2    	mov	x2, x25
1000b9904: 940512e1    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b9908: f9400f48    	ldr	x8, [x26, #0x18]
1000b990c: aa1703e0    	mov	x0, x23
1000b9910: aa1803e1    	mov	x1, x24
1000b9914: aa1903e2    	mov	x2, x25
1000b9918: 52800063    	mov	w3, #0x3                ; =3
1000b991c: aa1303e4    	mov	x4, x19
1000b9920: d63f0100    	blr	x8
1000b9924: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9928: 3d807be0    	str	q0, [sp, #0x1e0]
1000b992c: a95e67f4    	ldp	x20, x25, [sp, #0x1e0]
1000b9930: f942c7f7    	ldr	x23, [sp, #0x588]
1000b9934: b40002b7    	cbz	x23, 0x1000b9988 <_machine.machine.Group.execute+0xf48>
1000b9938: f942c3e8    	ldr	x8, [sp, #0x580]
1000b993c: 14000018    	b	0x1000b999c <_machine.machine.Group.execute+0xf5c>
1000b9940: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9944: f1000420    	subs	x0, x1, #0x1
1000b9948: 5400ac83    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b994c: eb01001f    	cmp	x0, x1
1000b9950: 5400ad62    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b9954: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9958: 52800909    	mov	w9, #0x48               ; =72
1000b995c: 9b092008    	madd	x8, x0, x9, x8
1000b9960: b9403d09    	ldr	w9, [x8, #0x3c]
1000b9964: 71000537    	subs	w23, w9, #0x1
1000b9968: 5400ab83    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b996c: f9400108    	ldr	x8, [x8]
1000b9970: b40002a8    	cbz	x8, 0x1000b99c4 <_machine.machine.Group.execute+0xf84>
1000b9974: 91018108    	add	x8, x8, #0x60
1000b9978: f9403d01    	ldr	x1, [x8, #0x78]
1000b997c: eb17003f    	cmp	x1, x23
1000b9980: 540002c8    	b.hi	0x1000b99d8 <_machine.machine.Group.execute+0xf98>
1000b9984: 14000574    	b	0x1000baf54 <_machine.machine.Group.execute+0x2514>
1000b9988: f942cbf7    	ldr	x23, [sp, #0x590]
1000b998c: f10026ff    	cmp	x23, #0x9
1000b9990: 5400af02    	b.hs	0x1000baf70 <_machine.machine.Group.execute+0x2530>
1000b9994: b4ff8b37    	cbz	x23, 0x1000b8af8 <_machine.machine.Group.execute+0xb8>
1000b9998: 911003e8    	add	x8, sp, #0x400
1000b999c: 91008118    	add	x24, x8, #0x20
1000b99a0: f85e0300    	ldur	x0, [x24, #-0x20]
1000b99a4: 38430701    	ldrb	w1, [x24], #0x30
1000b99a8: 910783e2    	add	x2, sp, #0x1e0
1000b99ac: 97feedf9    	bl	0x100075190 <_machine.machine.Slot.release>
1000b99b0: f10006f7    	subs	x23, x23, #0x1
1000b99b4: 54ffff61    	b.ne	0x1000b99a0 <_machine.machine.Group.execute+0xf60>
1000b99b8: f942c7e8    	ldr	x8, [sp, #0x588]
1000b99bc: b5ff8828    	cbnz	x8, 0x1000b8ac0 <_machine.machine.Group.execute+0x80>
1000b99c0: 17fffc4e    	b	0x1000b8af8 <_machine.machine.Group.execute+0xb8>
1000b99c4: f9423ac8    	ldr	x8, [x22, #0x470]
1000b99c8: 9101e108    	add	x8, x8, #0x78
1000b99cc: f9403d01    	ldr	x1, [x8, #0x78]
1000b99d0: eb17003f    	cmp	x1, x23
1000b99d4: 5400ac09    	b.ls	0x1000baf54 <_machine.machine.Group.execute+0x2514>
1000b99d8: f9403908    	ldr	x8, [x8, #0x70]
1000b99dc: 52800609    	mov	w9, #0x30               ; =48
1000b99e0: 9ba922e8    	umaddl	x8, w23, w9, x8
1000b99e4: ad400500    	ldp	q0, q1, [x8]
1000b99e8: 3d824fe0    	str	q0, [sp, #0x930]
1000b99ec: 3d8253e1    	str	q1, [sp, #0x940]
1000b99f0: 3dc00900    	ldr	q0, [x8, #0x20]
1000b99f4: 3d8257e0    	str	q0, [sp, #0x950]
1000b99f8: aa1503e0    	mov	x0, x21
1000b99fc: b0000c61    	adrp	x1, 0x100246000 <___anon_79250+0x38>
1000b9a00: 910d9c21    	add	x1, x1, #0x367
1000b9a04: 52800102    	mov	w2, #0x8                ; =8
1000b9a08: 52800103    	mov	w3, #0x8                ; =8
1000b9a0c: d2800004    	mov	x4, #0x0                ; =0
1000b9a10: 940132a7    	bl	0x1001064ac <_machine.machine.Group.raise>
1000b9a14: 12001c08    	and	w8, w0, #0xff
1000b9a18: 71028d1f    	cmp	w8, #0xa3
1000b9a1c: 54005601    	b.ne	0x1000ba4dc <_machine.machine.Group.execute+0x1a9c>
1000b9a20: 9125a3e0    	add	x0, sp, #0x968
1000b9a24: 9124c3e3    	add	x3, sp, #0x930
1000b9a28: aa1503e1    	mov	x1, x21
1000b9a2c: aa1603e2    	mov	x2, x22
1000b9a30: 97fff5af    	bl	0x1000b70ec <_machine.machine.Group.completeError>
1000b9a34: 7952e3fa    	ldrh	w26, [sp, #0x970]
1000b9a38: 3500a1fa    	cbnz	w26, 0x1000bae74 <_machine.machine.Group.execute+0x2434>
1000b9a3c: f944b7e3    	ldr	x3, [sp, #0x968]
1000b9a40: b94953e5    	ldr	w5, [sp, #0x950]
1000b9a44: b94957e6    	ldr	w6, [sp, #0x954]
1000b9a48: 9125e3e0    	add	x0, sp, #0x978
1000b9a4c: b9405fe8    	ldr	w8, [sp, #0x5c]
1000b9a50: 12000107    	and	w7, w8, #0x1
1000b9a54: aa1503e1    	mov	x1, x21
1000b9a58: aa1603e2    	mov	x2, x22
1000b9a5c: aa1703e4    	mov	x4, x23
1000b9a60: 97fff957    	bl	0x1000b7fbc <_machine.machine.Group.unwind>
1000b9a64: 795393f7    	ldrh	w23, [sp, #0x9c8]
1000b9a68: 3500a237    	cbnz	w23, 0x1000baeac <_machine.machine.Group.execute+0x246c>
1000b9a6c: 396703e8    	ldrb	w8, [sp, #0x9c0]
1000b9a70: 37005568    	tbnz	w8, #0x0, 0x1000ba51c <_machine.machine.Group.execute+0x1adc>
1000b9a74: b4001434    	cbz	x20, 0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b9a78: d280001b    	mov	x27, #0x0               ; =0
1000b9a7c: a944eab7    	ldp	x23, x26, [x21, #0x48]
1000b9a80: f87b7b00    	ldr	x0, [x24, x27, lsl #3]
1000b9a84: 97fe9fd8    	bl	0x1000619e4 <_value.Value.release>
1000b9a88: 9100077b    	add	x27, x27, #0x1
1000b9a8c: eb1b029f    	cmp	x20, x27
1000b9a90: 54ffff81    	b.ne	0x1000b9a80 <_machine.machine.Group.execute+0x1040>
1000b9a94: aa1803e0    	mov	x0, x24
1000b9a98: 52801541    	mov	w1, #0xaa               ; =170
1000b9a9c: aa1903e2    	mov	x2, x25
1000b9aa0: 9405127a    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b9aa4: f9400f48    	ldr	x8, [x26, #0x18]
1000b9aa8: aa1703e0    	mov	x0, x23
1000b9aac: aa1803e1    	mov	x1, x24
1000b9ab0: aa1903e2    	mov	x2, x25
1000b9ab4: 52800063    	mov	w3, #0x3                ; =3
1000b9ab8: aa1303e4    	mov	x4, x19
1000b9abc: d63f0100    	blr	x8
1000b9ac0: 1400008e    	b	0x1000b9cf8 <_machine.machine.Group.execute+0x12b8>
1000b9ac4: f9423ac9    	ldr	x9, [x22, #0x470]
1000b9ac8: 9106c128    	add	x8, x9, #0x1b0
1000b9acc: 9106e129    	add	x9, x9, #0x1b8
1000b9ad0: f9423ed9    	ldr	x25, [x22, #0x478]
1000b9ad4: f94242da    	ldr	x26, [x22, #0x480]
1000b9ad8: f9400137    	ldr	x23, [x9]
1000b9adc: f9400118    	ldr	x24, [x8]
1000b9ae0: aa1403e0    	mov	x0, x20
1000b9ae4: b0000ae1    	adrp	x1, 0x100216000 <___anon_78196+0x40>
1000b9ae8: 912cc021    	add	x1, x1, #0xb30
1000b9aec: 52800162    	mov	w2, #0xb                ; =11
1000b9af0: 97fd1fb4    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9af4: 72003c1f    	tst	w0, #0xffff
1000b9af8: 54000921    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9afc: aa1403e0    	mov	x0, x20
1000b9b00: aa1903e1    	mov	x1, x25
1000b9b04: aa1a03e2    	mov	x2, x26
1000b9b08: 97fd1fae    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b0c: 72003c1f    	tst	w0, #0xffff
1000b9b10: 54000861    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9b14: aa1403e0    	mov	x0, x20
1000b9b18: b0000ae1    	adrp	x1, 0x100216000 <___anon_78196+0x40>
1000b9b1c: 912cec21    	add	x1, x1, #0xb3b
1000b9b20: 52800082    	mov	w2, #0x4                ; =4
1000b9b24: 97fd1fa7    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b28: 72003c1f    	tst	w0, #0xffff
1000b9b2c: 54000781    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9b30: aa1403e0    	mov	x0, x20
1000b9b34: aa1803e1    	mov	x1, x24
1000b9b38: aa1703e2    	mov	x2, x23
1000b9b3c: 97fd1fa1    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b40: 72003c1f    	tst	w0, #0xffff
1000b9b44: 540006c1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9b48: aa1403e0    	mov	x0, x20
1000b9b4c: f0000a21    	adrp	x1, 0x100200000 <_writev+0x100200000>
1000b9b50: 9127cc21    	add	x1, x1, #0x9f3
1000b9b54: 52800022    	mov	w2, #0x1                ; =1
1000b9b58: 97fd1f9a    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b5c: 72003c1f    	tst	w0, #0xffff
1000b9b60: 540005e1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9b64: aa1403e0    	mov	x0, x20
1000b9b68: aa1b03e1    	mov	x1, x27
1000b9b6c: 52800142    	mov	w2, #0xa                ; =10
1000b9b70: 52800003    	mov	w3, #0x0                ; =0
1000b9b74: f0000a24    	adrp	x4, 0x100200000 <_writev+0x100200000>
1000b9b78: 91262084    	add	x4, x4, #0x988
1000b9b7c: 97fd43d8    	bl	0x10000aadc <_Io.Writer.printIntAny__func_56>
1000b9b80: 72003c1f    	tst	w0, #0xffff
1000b9b84: 540004c1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9b88: aa1403e0    	mov	x0, x20
1000b9b8c: b0000ae1    	adrp	x1, 0x100216000 <___anon_78196+0x40>
1000b9b90: 912cfc21    	add	x1, x1, #0xb3f
1000b9b94: 528000a2    	mov	w2, #0x5                ; =5
1000b9b98: 97fd1f8a    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9b9c: 72003c1f    	tst	w0, #0xffff
1000b9ba0: 540003e1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9ba4: aa1403e0    	mov	x0, x20
1000b9ba8: f9402be1    	ldr	x1, [sp, #0x50]
1000b9bac: 52800142    	mov	w2, #0xa                ; =10
1000b9bb0: 52800003    	mov	w3, #0x0                ; =0
1000b9bb4: f0000a24    	adrp	x4, 0x100200000 <_writev+0x100200000>
1000b9bb8: 91262084    	add	x4, x4, #0x988
1000b9bbc: 97fd43c8    	bl	0x10000aadc <_Io.Writer.printIntAny__func_56>
1000b9bc0: 72003c1f    	tst	w0, #0xffff
1000b9bc4: 540002c1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9bc8: aa1403e0    	mov	x0, x20
1000b9bcc: f0000a21    	adrp	x1, 0x100200000 <_writev+0x100200000>
1000b9bd0: 9127cc21    	add	x1, x1, #0x9f3
1000b9bd4: 52800022    	mov	w2, #0x1                ; =1
1000b9bd8: 97fd1f7a    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9bdc: 72003c1f    	tst	w0, #0xffff
1000b9be0: 540001e1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9be4: aa1403e0    	mov	x0, x20
1000b9be8: f94027e1    	ldr	x1, [sp, #0x48]
1000b9bec: 52800142    	mov	w2, #0xa                ; =10
1000b9bf0: 52800003    	mov	w3, #0x0                ; =0
1000b9bf4: f0000a24    	adrp	x4, 0x100200000 <_writev+0x100200000>
1000b9bf8: 91262084    	add	x4, x4, #0x988
1000b9bfc: 97fd43b8    	bl	0x10000aadc <_Io.Writer.printIntAny__func_56>
1000b9c00: 72003c1f    	tst	w0, #0xffff
1000b9c04: 540000c1    	b.ne	0x1000b9c1c <_machine.machine.Group.execute+0x11dc>
1000b9c08: aa1403e0    	mov	x0, x20
1000b9c0c: b0000aa1    	adrp	x1, 0x10020e000 <___anon_49097+0xd0>
1000b9c10: 911c1c21    	add	x1, x1, #0x707
1000b9c14: 528000e2    	mov	w2, #0x7                ; =7
1000b9c18: 97fd1f6a    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9c1c: aa1403e0    	mov	x0, x20
1000b9c20: aa1303e1    	mov	x1, x19
1000b9c24: 52800022    	mov	w2, #0x1                ; =1
1000b9c28: 97fe7e0b    	bl	0x100059454 <_display.writeWith>
1000b9c2c: aa1403e0    	mov	x0, x20
1000b9c30: 90000c41    	adrp	x1, 0x100241000 <___anon_2200+0x6a>
1000b9c34: 91253c21    	add	x1, x1, #0x94f
1000b9c38: 52800022    	mov	w2, #0x1                ; =1
1000b9c3c: 97fd1f61    	bl	0x1000019c0 <_Io.Writer.writeAll>
1000b9c40: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9c44: f1000420    	subs	x0, x1, #0x1
1000b9c48: 1a9f27e8    	cset	w8, lo
1000b9c4c: 37009468    	tbnz	w8, #0x0, 0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9c50: eb01001f    	cmp	x0, x1
1000b9c54: 54009542    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b9c58: d360ff94    	lsr	x20, x28, #32
1000b9c5c: f9404ac9    	ldr	x9, [x22, #0x90]
1000b9c60: 5280090a    	mov	w10, #0x48              ; =72
1000b9c64: 9b0a2417    	madd	x23, x0, x10, x9
1000b9c68: f94012e9    	ldr	x9, [x23, #0x20]
1000b9c6c: eb14013f    	cmp	x9, x20
1000b9c70: 54000329    	b.ls	0x1000b9cd4 <_machine.machine.Group.execute+0x1294>
1000b9c74: f9401ae8    	ldr	x8, [x23, #0x30]
1000b9c78: b5009488    	cbnz	x8, 0x1000baf08 <_machine.machine.Group.execute+0x24c8>
1000b9c7c: f9400ee8    	ldr	x8, [x23, #0x18]
1000b9c80: 5280060a    	mov	w10, #0x30              ; =48
1000b9c84: 9b0a2128    	madd	x8, x9, x10, x8
1000b9c88: f85d0100    	ldur	x0, [x8, #-0x30]
1000b9c8c: 385f0101    	ldurb	w1, [x8, #-0x10]
1000b9c90: 4f05e540    	movi.16b	v0, #0xaa
1000b9c94: ad3e8100    	stp	q0, q0, [x8, #-0x30]
1000b9c98: 3c9f0100    	stur	q0, [x8, #-0x10]
1000b9c9c: f94012e8    	ldr	x8, [x23, #0x20]
1000b9ca0: f1000508    	subs	x8, x8, #0x1
1000b9ca4: 540091a3    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9ca8: f90012e8    	str	x8, [x23, #0x20]
1000b9cac: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9cb0: 3d8303e0    	str	q0, [sp, #0xc00]
1000b9cb4: 913003e2    	add	x2, sp, #0xc00
1000b9cb8: 97feed36    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9cbc: f94012e9    	ldr	x9, [x23, #0x20]
1000b9cc0: eb14013f    	cmp	x9, x20
1000b9cc4: 54fffd88    	b.hi	0x1000b9c74 <_machine.machine.Group.execute+0x1234>
1000b9cc8: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9ccc: f1000420    	subs	x0, x1, #0x1
1000b9cd0: 1a9f27e8    	cset	w8, lo
1000b9cd4: 37009028    	tbnz	w8, #0x0, 0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9cd8: eb01001f    	cmp	x0, x1
1000b9cdc: 54009102    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b9ce0: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9ce4: 52800909    	mov	w9, #0x48               ; =72
1000b9ce8: 9b092008    	madd	x8, x0, x9, x8
1000b9cec: b9003d1c    	str	w28, [x8, #0x3c]
1000b9cf0: aa1303e0    	mov	x0, x19
1000b9cf4: 97fe9f3c    	bl	0x1000619e4 <_value.Value.release>
1000b9cf8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9cfc: 3d80d7e0    	str	q0, [sp, #0x350]
1000b9d00: f941abf3    	ldr	x19, [sp, #0x350]
1000b9d04: f941aff8    	ldr	x24, [sp, #0x358]
1000b9d08: f942c7f4    	ldr	x20, [sp, #0x588]
1000b9d0c: b4000074    	cbz	x20, 0x1000b9d18 <_machine.machine.Group.execute+0x12d8>
1000b9d10: f942c3e8    	ldr	x8, [sp, #0x580]
1000b9d14: 14000006    	b	0x1000b9d2c <_machine.machine.Group.execute+0x12ec>
1000b9d18: f942cbf4    	ldr	x20, [sp, #0x590]
1000b9d1c: f100269f    	cmp	x20, #0x9
1000b9d20: 54008f62    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000b9d24: b4ff6eb4    	cbz	x20, 0x1000b8af8 <_machine.machine.Group.execute+0xb8>
1000b9d28: 911003e8    	add	x8, sp, #0x400
1000b9d2c: 91008117    	add	x23, x8, #0x20
1000b9d30: f85e02e0    	ldur	x0, [x23, #-0x20]
1000b9d34: 384306e1    	ldrb	w1, [x23], #0x30
1000b9d38: 910d43e2    	add	x2, sp, #0x350
1000b9d3c: 97feed15    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9d40: f1000694    	subs	x20, x20, #0x1
1000b9d44: 54ffff61    	b.ne	0x1000b9d30 <_machine.machine.Group.execute+0x12f0>
1000b9d48: f942c7e8    	ldr	x8, [sp, #0x588]
1000b9d4c: b4ff6d68    	cbz	x8, 0x1000b8af8 <_machine.machine.Group.execute+0xb8>
1000b9d50: f942c3f4    	ldr	x20, [sp, #0x580]
1000b9d54: 8b080508    	add	x8, x8, x8, lsl #1
1000b9d58: d37ced17    	lsl	x23, x8, #4
1000b9d5c: aa1403e0    	mov	x0, x20
1000b9d60: 52801541    	mov	w1, #0xaa               ; =170
1000b9d64: aa1703e2    	mov	x2, x23
1000b9d68: 940511c8    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b9d6c: f94017e4    	ldr	x4, [sp, #0x28]
1000b9d70: dac143e4    	xpaci	x4
1000b9d74: f9400f08    	ldr	x8, [x24, #0x18]
1000b9d78: aa1303e0    	mov	x0, x19
1000b9d7c: aa1403e1    	mov	x1, x20
1000b9d80: aa1703e2    	mov	x2, x23
1000b9d84: 52800083    	mov	w3, #0x4                ; =4
1000b9d88: 17fffb5b    	b	0x1000b8af4 <_machine.machine.Group.execute+0xb4>
1000b9d8c: aa1503e0    	mov	x0, x21
1000b9d90: aa1603e1    	mov	x1, x22
1000b9d94: 97feec1e    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000b9d98: f9404ec8    	ldr	x8, [x22, #0x98]
1000b9d9c: b5ffff88    	cbnz	x8, 0x1000b9d8c <_machine.machine.Group.execute+0x134c>
1000b9da0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9da4: 3d80cfe0    	str	q0, [sp, #0x330]
1000b9da8: f9419bf3    	ldr	x19, [sp, #0x330]
1000b9dac: f9419ff6    	ldr	x22, [sp, #0x338]
1000b9db0: f942c7f4    	ldr	x20, [sp, #0x588]
1000b9db4: b4004794    	cbz	x20, 0x1000ba6a4 <_machine.machine.Group.execute+0x1c64>
1000b9db8: f942c3e8    	ldr	x8, [sp, #0x580]
1000b9dbc: 1400023f    	b	0x1000ba6b8 <_machine.machine.Group.execute+0x1c78>
1000b9dc0: f9404ec1    	ldr	x1, [x22, #0x98]
1000b9dc4: f1000420    	subs	x0, x1, #0x1
1000b9dc8: 54008883    	b.lo	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9dcc: eb01001f    	cmp	x0, x1
1000b9dd0: 54008962    	b.hs	0x1000baefc <_machine.machine.Group.execute+0x24bc>
1000b9dd4: f9404ac8    	ldr	x8, [x22, #0x90]
1000b9dd8: 52800909    	mov	w9, #0x48               ; =72
1000b9ddc: 9b092008    	madd	x8, x0, x9, x8
1000b9de0: b9003d1b    	str	w27, [x8, #0x3c]
1000b9de4: f94313e0    	ldr	x0, [sp, #0x620]
1000b9de8: b4000040    	cbz	x0, 0x1000b9df0 <_machine.machine.Group.execute+0x13b0>
1000b9dec: 97fe9efe    	bl	0x1000619e4 <_value.Value.release>
1000b9df0: f94317e0    	ldr	x0, [sp, #0x628]
1000b9df4: f9400ff3    	ldr	x19, [sp, #0x18]
1000b9df8: b4000040    	cbz	x0, 0x1000b9e00 <_machine.machine.Group.execute+0x13c0>
1000b9dfc: 97fe9efa    	bl	0x1000619e4 <_value.Value.release>
1000b9e00: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000b9e04: 3d819be1    	str	q1, [sp, #0x660]
1000b9e08: 3d819fe0    	str	q0, [sp, #0x670]
1000b9e0c: f90343f7    	str	x23, [sp, #0x680]
1000b9e10: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000b9e14: 3d818be1    	str	q1, [sp, #0x620]
1000b9e18: 3d818fe0    	str	q0, [sp, #0x630]
1000b9e1c: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000b9e20: 3d8197e1    	str	q1, [sp, #0x650]
1000b9e24: 3d8193e0    	str	q0, [sp, #0x640]
1000b9e28: 7900927f    	strh	wzr, [x19, #0x48]
1000b9e2c: 52800188    	mov	w8, #0xc                ; =12
1000b9e30: 39010268    	strb	w8, [x19, #0x40]
1000b9e34: 52800048    	mov	w8, #0x2                ; =2
1000b9e38: 39000268    	strb	w8, [x19]
1000b9e3c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000b9e40: 3d804fe0    	str	q0, [sp, #0x130]
1000b9e44: a9535bf3    	ldp	x19, x22, [sp, #0x130]
1000b9e48: f942c7f4    	ldr	x20, [sp, #0x588]
1000b9e4c: b40000f4    	cbz	x20, 0x1000b9e68 <_machine.machine.Group.execute+0x1428>
1000b9e50: f942c3e8    	ldr	x8, [sp, #0x580]
1000b9e54: 1400000a    	b	0x1000b9e7c <_machine.machine.Group.execute+0x143c>
1000b9e58: f902badf    	str	xzr, [x22, #0x570]
1000b9e5c: b0000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000b9e60: 9121c108    	add	x8, x8, #0x870
1000b9e64: 1400022f    	b	0x1000ba720 <_machine.machine.Group.execute+0x1ce0>
1000b9e68: f942cbf4    	ldr	x20, [sp, #0x590]
1000b9e6c: f100269f    	cmp	x20, #0x9
1000b9e70: 540084e2    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000b9e74: b4006474    	cbz	x20, 0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000b9e78: 911003e8    	add	x8, sp, #0x400
1000b9e7c: 91008115    	add	x21, x8, #0x20
1000b9e80: f85e02a0    	ldur	x0, [x21, #-0x20]
1000b9e84: 384306a1    	ldrb	w1, [x21], #0x30
1000b9e88: 9104c3e2    	add	x2, sp, #0x130
1000b9e8c: 97feecc1    	bl	0x100075190 <_machine.machine.Slot.release>
1000b9e90: f1000694    	subs	x20, x20, #0x1
1000b9e94: 54ffff61    	b.ne	0x1000b9e80 <_machine.machine.Group.execute+0x1440>
1000b9e98: f942c7e8    	ldr	x8, [sp, #0x588]
1000b9e9c: b4006328    	cbz	x8, 0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000b9ea0: f942c3f4    	ldr	x20, [sp, #0x580]
1000b9ea4: 8b080508    	add	x8, x8, x8, lsl #1
1000b9ea8: d37ced15    	lsl	x21, x8, #4
1000b9eac: aa1403e0    	mov	x0, x20
1000b9eb0: 52801541    	mov	w1, #0xaa               ; =170
1000b9eb4: aa1503e2    	mov	x2, x21
1000b9eb8: 94051174    	bl	0x1001fe488 <_writev+0x1001fe488>
1000b9ebc: f94017e4    	ldr	x4, [sp, #0x28]
1000b9ec0: dac143e4    	xpaci	x4
1000b9ec4: f9400ec8    	ldr	x8, [x22, #0x18]
1000b9ec8: aa1303e0    	mov	x0, x19
1000b9ecc: aa1403e1    	mov	x1, x20
1000b9ed0: aa1503e2    	mov	x2, x21
1000b9ed4: 52800083    	mov	w3, #0x4                ; =4
1000b9ed8: d63f0100    	blr	x8
1000b9edc: 14000309    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000b9ee0: 3940013c    	ldrb	w28, [x9]
1000b9ee4: 12000b88    	and	w8, w28, #0x7
1000b9ee8: 7100051f    	cmp	w8, #0x1
1000b9eec: 540003a8    	b.hi	0x1000b9f60 <_machine.machine.Group.execute+0x1520>
1000b9ef0: 395a0be8    	ldrb	w8, [sp, #0x682]
1000b9ef4: 36000368    	tbz	w8, #0x0, 0x1000b9f60 <_machine.machine.Group.execute+0x1520>
1000b9ef8: 3dc19be0    	ldr	q0, [sp, #0x660]
1000b9efc: 3dc19fe1    	ldr	q1, [sp, #0x670]
1000b9f00: 3d821fe0    	str	q0, [sp, #0x870]
1000b9f04: 3d8223e1    	str	q1, [sp, #0x880]
1000b9f08: f94343e8    	ldr	x8, [sp, #0x680]
1000b9f0c: f9044be8    	str	x8, [sp, #0x890]
1000b9f10: 3dc18be0    	ldr	q0, [sp, #0x620]
1000b9f14: 3dc18fe1    	ldr	q1, [sp, #0x630]
1000b9f18: 3d820fe0    	str	q0, [sp, #0x830]
1000b9f1c: 3d8213e1    	str	q1, [sp, #0x840]
1000b9f20: 3dc197e0    	ldr	q0, [sp, #0x650]
1000b9f24: 3dc193e1    	ldr	q1, [sp, #0x640]
1000b9f28: 3d821be0    	str	q0, [sp, #0x860]
1000b9f2c: 3d8217e1    	str	q1, [sp, #0x850]
1000b9f30: f9041fff    	str	xzr, [sp, #0x838]
1000b9f34: f9405ad8    	ldr	x24, [x22, #0xb0]
1000b9f38: 910543e0    	add	x0, sp, #0x150
1000b9f3c: 9120c3e2    	add	x2, sp, #0x830
1000b9f40: aa1303e1    	mov	x1, x19
1000b9f44: 94012bfb    	bl	0x100104f30 <_machine.costs.chargeInstruction>
1000b9f48: f940abe8    	ldr	x8, [sp, #0x150]
1000b9f4c: ab140108    	adds	x8, x8, x20
1000b9f50: 54007c42    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9f54: ab080308    	adds	x8, x24, x8
1000b9f58: 54007c02    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000b9f5c: f9005ac8    	str	x8, [x22, #0xb0]
1000b9f60: f94313e0    	ldr	x0, [sp, #0x620]
1000b9f64: b4000040    	cbz	x0, 0x1000b9f6c <_machine.machine.Group.execute+0x152c>
1000b9f68: 97fe9e9f    	bl	0x1000619e4 <_value.Value.release>
1000b9f6c: f94317e0    	ldr	x0, [sp, #0x628]
1000b9f70: b4000040    	cbz	x0, 0x1000b9f78 <_machine.machine.Group.execute+0x1538>
1000b9f74: 97fe9e9c    	bl	0x1000619e4 <_value.Value.release>
1000b9f78: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000b9f7c: 3d819be1    	str	q1, [sp, #0x660]
1000b9f80: 3d819fe0    	str	q0, [sp, #0x670]
1000b9f84: f90343f7    	str	x23, [sp, #0x680]
1000b9f88: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000b9f8c: 3d818be1    	str	q1, [sp, #0x620]
1000b9f90: 3d818fe0    	str	q0, [sp, #0x630]
1000b9f94: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000b9f98: 3d8197e1    	str	q1, [sp, #0x650]
1000b9f9c: 3d8193e0    	str	q0, [sp, #0x640]
1000b9fa0: 39412348    	ldrb	w8, [x26, #0x48]
1000b9fa4: 11001509    	add	w9, w8, #0x5
1000b9fa8: 53010d2a    	ubfx	w10, w9, #1, #3
1000b9fac: 2a090d49    	orr	w9, w10, w9, lsl #3
1000b9fb0: 12000d29    	and	w9, w9, #0xf
1000b9fb4: 51000d2a    	sub	w10, w9, #0x3
1000b9fb8: 7100095f    	cmp	w10, #0x2
1000b9fbc: 540007e3    	b.lo	0x1000ba0b8 <_machine.machine.Group.execute+0x1678>
1000b9fc0: 340007c9    	cbz	w9, 0x1000ba0b8 <_machine.machine.Group.execute+0x1678>
1000b9fc4: 7100193f    	cmp	w9, #0x6
1000b9fc8: 54002181    	b.ne	0x1000ba3f8 <_machine.machine.Group.execute+0x19b8>
1000b9fcc: f9400f58    	ldr	x24, [x26, #0x18]
1000b9fd0: b40021b8    	cbz	x24, 0x1000ba404 <_machine.machine.Group.execute+0x19c4>
1000b9fd4: d2800019    	mov	x25, #0x0               ; =0
1000b9fd8: f9400b53    	ldr	x19, [x26, #0x10]
1000b9fdc: a944d2b7    	ldp	x23, x20, [x21, #0x48]
1000b9fe0: f8797a60    	ldr	x0, [x19, x25, lsl #3]
1000b9fe4: 97fe9e80    	bl	0x1000619e4 <_value.Value.release>
1000b9fe8: 91000739    	add	x25, x25, #0x1
1000b9fec: eb19031f    	cmp	x24, x25
1000b9ff0: 54ffff81    	b.ne	0x1000b9fe0 <_machine.machine.Group.execute+0x15a0>
1000b9ff4: d37df31a    	lsl	x26, x24, #3
1000b9ff8: aa1303e0    	mov	x0, x19
1000b9ffc: 52801541    	mov	w1, #0xaa               ; =170
1000ba000: aa1a03e2    	mov	x2, x26
1000ba004: 94051121    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba008: f94017e4    	ldr	x4, [sp, #0x28]
1000ba00c: dac143e4    	xpaci	x4
1000ba010: f9400e88    	ldr	x8, [x20, #0x18]
1000ba014: aa1703e0    	mov	x0, x23
1000ba018: aa1303e1    	mov	x1, x19
1000ba01c: aa1a03e2    	mov	x2, x26
1000ba020: 52800063    	mov	w3, #0x3                ; =3
1000ba024: d63f0100    	blr	x8
1000ba028: 140000f7    	b	0x1000ba404 <_machine.machine.Group.execute+0x19c4>
1000ba02c: aa1503e0    	mov	x0, x21
1000ba030: aa1603e1    	mov	x1, x22
1000ba034: 97feeb76    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000ba038: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba03c: 3d806be0    	str	q0, [sp, #0x1a0]
1000ba040: a95a5bf3    	ldp	x19, x22, [sp, #0x1a0]
1000ba044: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba048: b40016f4    	cbz	x20, 0x1000ba324 <_machine.machine.Group.execute+0x18e4>
1000ba04c: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba050: 140000ba    	b	0x1000ba338 <_machine.machine.Group.execute+0x18f8>
1000ba054: 52800008    	mov	w8, #0x0                ; =0
1000ba058: 14000002    	b	0x1000ba060 <_machine.machine.Group.execute+0x1620>
1000ba05c: 52800028    	mov	w8, #0x1                ; =1
1000ba060: f9400fea    	ldr	x10, [sp, #0x18]
1000ba064: 7900915f    	strh	wzr, [x10, #0x48]
1000ba068: 52800189    	mov	w9, #0xc                ; =12
1000ba06c: 39010149    	strb	w9, [x10, #0x40]
1000ba070: 39000148    	strb	w8, [x10]
1000ba074: 140002a3    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba078: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba07c: 3d806fe0    	str	q0, [sp, #0x1b0]
1000ba080: 911003e0    	add	x0, sp, #0x400
1000ba084: 9106c3e1    	add	x1, sp, #0x1b0
1000ba088: 9400284e    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000ba08c: 528000a8    	mov	w8, #0x5                ; =5
1000ba090: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba094: 79009128    	strh	w8, [x9, #0x48]
1000ba098: 1400029a    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba09c: 394682c8    	ldrb	w8, [x22, #0x1a0]
1000ba0a0: 7100051f    	cmp	w8, #0x1
1000ba0a4: 5400180c    	b.gt	0x1000ba3a4 <_machine.machine.Group.execute+0x1964>
1000ba0a8: 35001888    	cbnz	w8, 0x1000ba3b8 <_machine.machine.Group.execute+0x1978>
1000ba0ac: 90000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000ba0b0: 91230108    	add	x8, x8, #0x8c0
1000ba0b4: 1400019b    	b	0x1000ba720 <_machine.machine.Group.execute+0x1ce0>
1000ba0b8: f9400340    	ldr	x0, [x26]
1000ba0bc: 97fe9e4a    	bl	0x1000619e4 <_value.Value.release>
1000ba0c0: 140000d1    	b	0x1000ba404 <_machine.machine.Group.execute+0x19c4>
1000ba0c4: f9400353    	ldr	x19, [x26]
1000ba0c8: f9404ec8    	ldr	x8, [x22, #0x98]
1000ba0cc: b40000c8    	cbz	x8, 0x1000ba0e4 <_machine.machine.Group.execute+0x16a4>
1000ba0d0: aa1503e0    	mov	x0, x21
1000ba0d4: aa1603e1    	mov	x1, x22
1000ba0d8: 97feeb4d    	bl	0x100074e0c <_machine.machine.Group.popFrame>
1000ba0dc: f9404ec8    	ldr	x8, [x22, #0x98]
1000ba0e0: b5ffff88    	cbnz	x8, 0x1000ba0d0 <_machine.machine.Group.execute+0x1690>
1000ba0e4: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba0e8: 7900913f    	strh	wzr, [x9, #0x48]
1000ba0ec: 52800168    	mov	w8, #0xb                ; =11
1000ba0f0: 39010128    	strb	w8, [x9, #0x40]
1000ba0f4: f9000133    	str	x19, [x9]
1000ba0f8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba0fc: 3d80d3e0    	str	q0, [sp, #0x340]
1000ba100: f941a3f3    	ldr	x19, [sp, #0x340]
1000ba104: f941a7f6    	ldr	x22, [sp, #0x348]
1000ba108: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba10c: b4002734    	cbz	x20, 0x1000ba5f0 <_machine.machine.Group.execute+0x1bb0>
1000ba110: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba114: 1400013c    	b	0x1000ba604 <_machine.machine.Group.execute+0x1bc4>
1000ba118: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba11c: 3d80cbe0    	str	q0, [sp, #0x320]
1000ba120: f94193f3    	ldr	x19, [sp, #0x320]
1000ba124: f94197f6    	ldr	x22, [sp, #0x328]
1000ba128: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba12c: b40027d4    	cbz	x20, 0x1000ba624 <_machine.machine.Group.execute+0x1be4>
1000ba130: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba134: 14000141    	b	0x1000ba638 <_machine.machine.Group.execute+0x1bf8>
1000ba138: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba13c: 7900911f    	strh	wzr, [x8, #0x48]
1000ba140: 3901011f    	strb	wzr, [x8, #0x40]
1000ba144: f9000113    	str	x19, [x8]
1000ba148: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba14c: 3d8063e0    	str	q0, [sp, #0x180]
1000ba150: a9585bf3    	ldp	x19, x22, [sp, #0x180]
1000ba154: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba158: b4002f54    	cbz	x20, 0x1000ba740 <_machine.machine.Group.execute+0x1d00>
1000ba15c: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba160: 1400017d    	b	0x1000ba754 <_machine.machine.Group.execute+0x1d14>
1000ba164: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba168: 3d80abe0    	str	q0, [sp, #0x2a0]
1000ba16c: f94153f3    	ldr	x19, [sp, #0x2a0]
1000ba170: f94157f6    	ldr	x22, [sp, #0x2a8]
1000ba174: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba178: b4002ff4    	cbz	x20, 0x1000ba774 <_machine.machine.Group.execute+0x1d34>
1000ba17c: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba180: 14000182    	b	0x1000ba788 <_machine.machine.Group.execute+0x1d48>
1000ba184: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba188: 3d80bbe0    	str	q0, [sp, #0x2e0]
1000ba18c: f94173f3    	ldr	x19, [sp, #0x2e0]
1000ba190: f94177f6    	ldr	x22, [sp, #0x2e8]
1000ba194: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba198: b4003394    	cbz	x20, 0x1000ba808 <_machine.machine.Group.execute+0x1dc8>
1000ba19c: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba1a0: 1400019f    	b	0x1000ba81c <_machine.machine.Group.execute+0x1ddc>
1000ba1a4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba1a8: 3d80a3e0    	str	q0, [sp, #0x280]
1000ba1ac: f94143f3    	ldr	x19, [sp, #0x280]
1000ba1b0: f94147f6    	ldr	x22, [sp, #0x288]
1000ba1b4: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba1b8: b4003754    	cbz	x20, 0x1000ba8a0 <_machine.machine.Group.execute+0x1e60>
1000ba1bc: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba1c0: 140001bd    	b	0x1000ba8b4 <_machine.machine.Group.execute+0x1e74>
1000ba1c4: f941cfe8    	ldr	x8, [sp, #0x398]
1000ba1c8: b5006a08    	cbnz	x8, 0x1000baf08 <_machine.machine.Group.execute+0x24c8>
1000ba1cc: f941cbe8    	ldr	x8, [sp, #0x390]
1000ba1d0: b4000208    	cbz	x8, 0x1000ba210 <_machine.machine.Group.execute+0x17d0>
1000ba1d4: a944e2b3    	ldp	x19, x24, [x21, #0x48]
1000ba1d8: d37be914    	lsl	x20, x8, #5
1000ba1dc: f941c3f6    	ldr	x22, [sp, #0x380]
1000ba1e0: aa1603e0    	mov	x0, x22
1000ba1e4: 52801541    	mov	w1, #0xaa               ; =170
1000ba1e8: aa1403e2    	mov	x2, x20
1000ba1ec: 940510a7    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba1f0: f94017e4    	ldr	x4, [sp, #0x28]
1000ba1f4: dac143e4    	xpaci	x4
1000ba1f8: f9400f08    	ldr	x8, [x24, #0x18]
1000ba1fc: aa1303e0    	mov	x0, x19
1000ba200: aa1603e1    	mov	x1, x22
1000ba204: aa1403e2    	mov	x2, x20
1000ba208: 52800063    	mov	w3, #0x3                ; =3
1000ba20c: d63f0100    	blr	x8
1000ba210: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba214: 3d80afe0    	str	q0, [sp, #0x2b0]
1000ba218: 911003e0    	add	x0, sp, #0x400
1000ba21c: 910ac3e1    	add	x1, sp, #0x2b0
1000ba220: 940027e8    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000ba224: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba228: 79009117    	strh	w23, [x8, #0x48]
1000ba22c: 14000235    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba230: f945dfe8    	ldr	x8, [sp, #0xbb8]
1000ba234: b50066a8    	cbnz	x8, 0x1000baf08 <_machine.machine.Group.execute+0x24c8>
1000ba238: a944eeb6    	ldp	x22, x27, [x21, #0x48]
1000ba23c: d37beb58    	lsl	x24, x26, #5
1000ba240: aa1703e0    	mov	x0, x23
1000ba244: 52801541    	mov	w1, #0xaa               ; =170
1000ba248: aa1803e2    	mov	x2, x24
1000ba24c: 9405108f    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba250: f94017e4    	ldr	x4, [sp, #0x28]
1000ba254: dac143e4    	xpaci	x4
1000ba258: f9400f68    	ldr	x8, [x27, #0x18]
1000ba25c: aa1603e0    	mov	x0, x22
1000ba260: aa1703e1    	mov	x1, x23
1000ba264: aa1803e2    	mov	x2, x24
1000ba268: 52800063    	mov	w3, #0x3                ; =3
1000ba26c: aa0403fa    	mov	x26, x4
1000ba270: d63f0100    	blr	x8
1000ba274: b4000294    	cbz	x20, 0x1000ba2c4 <_machine.machine.Group.execute+0x1884>
1000ba278: d2800018    	mov	x24, #0x0               ; =0
1000ba27c: a944deb6    	ldp	x22, x23, [x21, #0x48]
1000ba280: f8787a60    	ldr	x0, [x19, x24, lsl #3]
1000ba284: 97fe9dd8    	bl	0x1000619e4 <_value.Value.release>
1000ba288: 91000718    	add	x24, x24, #0x1
1000ba28c: eb18029f    	cmp	x20, x24
1000ba290: 54ffff81    	b.ne	0x1000ba280 <_machine.machine.Group.execute+0x1840>
1000ba294: d37df294    	lsl	x20, x20, #3
1000ba298: aa1303e0    	mov	x0, x19
1000ba29c: 52801541    	mov	w1, #0xaa               ; =170
1000ba2a0: aa1403e2    	mov	x2, x20
1000ba2a4: 94051079    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba2a8: f9400ee8    	ldr	x8, [x23, #0x18]
1000ba2ac: aa1603e0    	mov	x0, x22
1000ba2b0: aa1303e1    	mov	x1, x19
1000ba2b4: aa1403e2    	mov	x2, x20
1000ba2b8: 52800063    	mov	w3, #0x3                ; =3
1000ba2bc: aa1a03e4    	mov	x4, x26
1000ba2c0: d63f0100    	blr	x8
1000ba2c4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba2c8: 3d80c3e0    	str	q0, [sp, #0x300]
1000ba2cc: 911003e0    	add	x0, sp, #0x400
1000ba2d0: 910c03e1    	add	x1, sp, #0x300
1000ba2d4: 940027bb    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000ba2d8: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba2dc: 79009119    	strh	w25, [x8, #0x48]
1000ba2e0: 14000208    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba2e4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba2e8: 3d80b3e0    	str	q0, [sp, #0x2c0]
1000ba2ec: f94163f3    	ldr	x19, [sp, #0x2c0]
1000ba2f0: f94167f6    	ldr	x22, [sp, #0x2c8]
1000ba2f4: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba2f8: b4003214    	cbz	x20, 0x1000ba938 <_machine.machine.Group.execute+0x1ef8>
1000ba2fc: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba300: 14000193    	b	0x1000ba94c <_machine.machine.Group.execute+0x1f0c>
1000ba304: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba308: 3d80c7e0    	str	q0, [sp, #0x310]
1000ba30c: f9418bf3    	ldr	x19, [sp, #0x310]
1000ba310: f9418ff6    	ldr	x22, [sp, #0x318]
1000ba314: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba318: b40035d4    	cbz	x20, 0x1000ba9d0 <_machine.machine.Group.execute+0x1f90>
1000ba31c: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba320: 140001b1    	b	0x1000ba9e4 <_machine.machine.Group.execute+0x1fa4>
1000ba324: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba328: f100269f    	cmp	x20, #0x9
1000ba32c: 54005f02    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba330: b4000354    	cbz	x20, 0x1000ba398 <_machine.machine.Group.execute+0x1958>
1000ba334: 911003e8    	add	x8, sp, #0x400
1000ba338: 91008115    	add	x21, x8, #0x20
1000ba33c: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba340: 384306a1    	ldrb	w1, [x21], #0x30
1000ba344: 910683e2    	add	x2, sp, #0x1a0
1000ba348: 97feeb92    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba34c: f1000694    	subs	x20, x20, #0x1
1000ba350: 54ffff61    	b.ne	0x1000ba33c <_machine.machine.Group.execute+0x18fc>
1000ba354: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba358: b4000208    	cbz	x8, 0x1000ba398 <_machine.machine.Group.execute+0x1958>
1000ba35c: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba360: 8b080508    	add	x8, x8, x8, lsl #1
1000ba364: d37ced15    	lsl	x21, x8, #4
1000ba368: aa1403e0    	mov	x0, x20
1000ba36c: 52801541    	mov	w1, #0xaa               ; =170
1000ba370: aa1503e2    	mov	x2, x21
1000ba374: 94051045    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba378: f94017e4    	ldr	x4, [sp, #0x28]
1000ba37c: dac143e4    	xpaci	x4
1000ba380: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba384: aa1303e0    	mov	x0, x19
1000ba388: aa1403e1    	mov	x1, x20
1000ba38c: aa1503e2    	mov	x2, x21
1000ba390: 52800083    	mov	w3, #0x4                ; =4
1000ba394: d63f0100    	blr	x8
1000ba398: 90000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000ba39c: 9125a108    	add	x8, x8, #0x968
1000ba3a0: 140000e0    	b	0x1000ba720 <_machine.machine.Group.execute+0x1ce0>
1000ba3a4: 7100091f    	cmp	w8, #0x2
1000ba3a8: 54005bc1    	b.ne	0x1000baf20 <_machine.machine.Group.execute+0x24e0>
1000ba3ac: 90000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000ba3b0: 91244108    	add	x8, x8, #0x910
1000ba3b4: 140000db    	b	0x1000ba720 <_machine.machine.Group.execute+0x1ce0>
1000ba3b8: 6f00e400    	movi.2d	v0, #0000000000000000
1000ba3bc: ad0c82c0    	stp	q0, q0, [x22, #0x190]
1000ba3c0: 911683e0    	add	x0, sp, #0x5a0
1000ba3c4: aa1503e1    	mov	x1, x21
1000ba3c8: aa1603e2    	mov	x2, x22
1000ba3cc: 94013273    	bl	0x100106d98 <_machine.machine.Group.landedCancel>
1000ba3d0: 3dc173e0    	ldr	q0, [sp, #0x5c0]
1000ba3d4: 3dc177e1    	ldr	q1, [sp, #0x5d0]
1000ba3d8: f9400fe8    	ldr	x8, [sp, #0x18]
1000ba3dc: ad010500    	stp	q0, q1, [x8, #0x20]
1000ba3e0: 3dc17be0    	ldr	q0, [sp, #0x5e0]
1000ba3e4: 3d801100    	str	q0, [x8, #0x40]
1000ba3e8: 3dc16fe0    	ldr	q0, [sp, #0x5b0]
1000ba3ec: 3dc16be1    	ldr	q1, [sp, #0x5a0]
1000ba3f0: ad000101    	stp	q1, q0, [x8]
1000ba3f4: 140001c3    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba3f8: 12000d08    	and	w8, w8, #0xf
1000ba3fc: 7100351f    	cmp	w8, #0xd
1000ba400: 54005902    	b.hs	0x1000baf20 <_machine.machine.Group.execute+0x24e0>
1000ba404: a9449fe8    	ldp	x8, x7, [sp, #0x48]
1000ba408: b90003e8    	str	w8, [sp]
1000ba40c: 912283e0    	add	x0, sp, #0x8a0
1000ba410: aa1503e1    	mov	x1, x21
1000ba414: aa1603e2    	mov	x2, x22
1000ba418: aa1c03e3    	mov	x3, x28
1000ba41c: a94313e5    	ldp	x5, x4, [sp, #0x30]
1000ba420: aa1b03e6    	mov	x6, x27
1000ba424: 940024f1    	bl	0x1000c37e8 <_machine.machine.Group.limitFault>
1000ba428: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba42c: 3d805be0    	str	q0, [sp, #0x160]
1000ba430: a9565bf3    	ldp	x19, x22, [sp, #0x160]
1000ba434: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba438: b4000074    	cbz	x20, 0x1000ba444 <_machine.machine.Group.execute+0x1a04>
1000ba43c: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba440: 14000006    	b	0x1000ba458 <_machine.machine.Group.execute+0x1a18>
1000ba444: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba448: f100269f    	cmp	x20, #0x9
1000ba44c: 54005602    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba450: b4000354    	cbz	x20, 0x1000ba4b8 <_machine.machine.Group.execute+0x1a78>
1000ba454: 911003e8    	add	x8, sp, #0x400
1000ba458: 91008115    	add	x21, x8, #0x20
1000ba45c: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba460: 384306a1    	ldrb	w1, [x21], #0x30
1000ba464: 910583e2    	add	x2, sp, #0x160
1000ba468: 97feeb4a    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba46c: f1000694    	subs	x20, x20, #0x1
1000ba470: 54ffff61    	b.ne	0x1000ba45c <_machine.machine.Group.execute+0x1a1c>
1000ba474: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba478: b4000208    	cbz	x8, 0x1000ba4b8 <_machine.machine.Group.execute+0x1a78>
1000ba47c: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba480: 8b080508    	add	x8, x8, x8, lsl #1
1000ba484: d37ced15    	lsl	x21, x8, #4
1000ba488: aa1403e0    	mov	x0, x20
1000ba48c: 52801541    	mov	w1, #0xaa               ; =170
1000ba490: aa1503e2    	mov	x2, x21
1000ba494: 94050ffd    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba498: f94017e4    	ldr	x4, [sp, #0x28]
1000ba49c: dac143e4    	xpaci	x4
1000ba4a0: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba4a4: aa1303e0    	mov	x0, x19
1000ba4a8: aa1403e1    	mov	x1, x20
1000ba4ac: aa1503e2    	mov	x2, x21
1000ba4b0: 52800083    	mov	w3, #0x4                ; =4
1000ba4b4: d63f0100    	blr	x8
1000ba4b8: 3dc233e0    	ldr	q0, [sp, #0x8c0]
1000ba4bc: 3dc237e1    	ldr	q1, [sp, #0x8d0]
1000ba4c0: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba4c4: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba4c8: f94473e8    	ldr	x8, [sp, #0x8e0]
1000ba4cc: f9002128    	str	x8, [x9, #0x40]
1000ba4d0: 3dc22fe0    	ldr	q0, [sp, #0x8b0]
1000ba4d4: 3dc22be1    	ldr	q1, [sp, #0x8a0]
1000ba4d8: 14000188    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000ba4dc: 7100151f    	cmp	w8, #0x5
1000ba4e0: 54005201    	b.ne	0x1000baf20 <_machine.machine.Group.execute+0x24e0>
1000ba4e4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba4e8: 3d807fe0    	str	q0, [sp, #0x1f0]
1000ba4ec: 9107c3e2    	add	x2, sp, #0x1f0
1000ba4f0: aa1803e0    	mov	x0, x24
1000ba4f4: aa1403e1    	mov	x1, x20
1000ba4f8: 97fee706    	bl	0x100074110 <_machine.machine.releaseAll>
1000ba4fc: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba500: 3d8083e0    	str	q0, [sp, #0x200]
1000ba504: 911003e0    	add	x0, sp, #0x400
1000ba508: 910803e1    	add	x1, sp, #0x200
1000ba50c: 9400272d    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000ba510: 90000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000ba514: 9126e108    	add	x8, x8, #0x9b8
1000ba518: 14000082    	b	0x1000ba720 <_machine.machine.Group.execute+0x1ce0>
1000ba51c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba520: 3d8097e0    	str	q0, [sp, #0x250]
1000ba524: 910943e2    	add	x2, sp, #0x250
1000ba528: aa1803e0    	mov	x0, x24
1000ba52c: aa1403e1    	mov	x1, x20
1000ba530: 97fee6f8    	bl	0x100074110 <_machine.machine.releaseAll>
1000ba534: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba538: 3d809be0    	str	q0, [sp, #0x260]
1000ba53c: 911003e0    	add	x0, sp, #0x400
1000ba540: 910983e1    	add	x1, sp, #0x260
1000ba544: 9400271f    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000ba548: 911a23ea    	add	x10, sp, #0x688
1000ba54c: ad588540    	ldp	q0, q1, [x10, #0x310]
1000ba550: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba554: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba558: f944dfe8    	ldr	x8, [sp, #0x9b8]
1000ba55c: f9002128    	str	x8, [x9, #0x40]
1000ba560: ad578141    	ldp	q1, q0, [x10, #0x2f0]
1000ba564: 14000165    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000ba568: f94313e0    	ldr	x0, [sp, #0x620]
1000ba56c: b4000040    	cbz	x0, 0x1000ba574 <_machine.machine.Group.execute+0x1b34>
1000ba570: 97fe9d1d    	bl	0x1000619e4 <_value.Value.release>
1000ba574: f94317e0    	ldr	x0, [sp, #0x628]
1000ba578: f9401bf3    	ldr	x19, [sp, #0x30]
1000ba57c: b4000040    	cbz	x0, 0x1000ba584 <_machine.machine.Group.execute+0x1b44>
1000ba580: 97fe9d19    	bl	0x1000619e4 <_value.Value.release>
1000ba584: ad4303e1    	ldp	q1, q0, [sp, #0x60]
1000ba588: 3d819be1    	str	q1, [sp, #0x660]
1000ba58c: 3d819fe0    	str	q0, [sp, #0x670]
1000ba590: f90343f7    	str	x23, [sp, #0x680]
1000ba594: ad4403e1    	ldp	q1, q0, [sp, #0x80]
1000ba598: 3d818be1    	str	q1, [sp, #0x620]
1000ba59c: 3d818fe0    	str	q0, [sp, #0x630]
1000ba5a0: ad4503e1    	ldp	q1, q0, [sp, #0xa0]
1000ba5a4: 3d8197e1    	str	q1, [sp, #0x650]
1000ba5a8: 3d8193e0    	str	q0, [sp, #0x640]
1000ba5ac: a9449fe8    	ldp	x8, x7, [sp, #0x48]
1000ba5b0: b90003e8    	str	w8, [sp]
1000ba5b4: 9123a3e0    	add	x0, sp, #0x8e8
1000ba5b8: aa1503e1    	mov	x1, x21
1000ba5bc: aa1603e2    	mov	x2, x22
1000ba5c0: 52800043    	mov	w3, #0x2                ; =2
1000ba5c4: f9401fe4    	ldr	x4, [sp, #0x38]
1000ba5c8: aa1303e5    	mov	x5, x19
1000ba5cc: aa1b03e6    	mov	x6, x27
1000ba5d0: 94002486    	bl	0x1000c37e8 <_machine.machine.Group.limitFault>
1000ba5d4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000ba5d8: 3d805fe0    	str	q0, [sp, #0x170]
1000ba5dc: a9575bf3    	ldp	x19, x22, [sp, #0x170]
1000ba5e0: f942c7f4    	ldr	x20, [sp, #0x588]
1000ba5e4: b4002434    	cbz	x20, 0x1000baa68 <_machine.machine.Group.execute+0x2028>
1000ba5e8: f942c3e8    	ldr	x8, [sp, #0x580]
1000ba5ec: 14000124    	b	0x1000baa7c <_machine.machine.Group.execute+0x203c>
1000ba5f0: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba5f4: f100269f    	cmp	x20, #0x9
1000ba5f8: 540048a2    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba5fc: b4002834    	cbz	x20, 0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba600: 911003e8    	add	x8, sp, #0x400
1000ba604: 91008115    	add	x21, x8, #0x20
1000ba608: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba60c: 384306a1    	ldrb	w1, [x21], #0x30
1000ba610: 910d03e2    	add	x2, sp, #0x340
1000ba614: 97feeadf    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba618: f1000694    	subs	x20, x20, #0x1
1000ba61c: 54ffff61    	b.ne	0x1000ba608 <_machine.machine.Group.execute+0x1bc8>
1000ba620: 17fffe1e    	b	0x1000b9e98 <_machine.machine.Group.execute+0x1458>
1000ba624: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba628: f100269f    	cmp	x20, #0x9
1000ba62c: 54004702    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba630: b4000354    	cbz	x20, 0x1000ba698 <_machine.machine.Group.execute+0x1c58>
1000ba634: 911003e8    	add	x8, sp, #0x400
1000ba638: 91008115    	add	x21, x8, #0x20
1000ba63c: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba640: 384306a1    	ldrb	w1, [x21], #0x30
1000ba644: 910c83e2    	add	x2, sp, #0x320
1000ba648: 97feead2    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba64c: f1000694    	subs	x20, x20, #0x1
1000ba650: 54ffff61    	b.ne	0x1000ba63c <_machine.machine.Group.execute+0x1bfc>
1000ba654: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba658: b4000208    	cbz	x8, 0x1000ba698 <_machine.machine.Group.execute+0x1c58>
1000ba65c: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba660: 8b080508    	add	x8, x8, x8, lsl #1
1000ba664: d37ced15    	lsl	x21, x8, #4
1000ba668: aa1403e0    	mov	x0, x20
1000ba66c: 52801541    	mov	w1, #0xaa               ; =170
1000ba670: aa1503e2    	mov	x2, x21
1000ba674: 94050f85    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba678: f94017e4    	ldr	x4, [sp, #0x28]
1000ba67c: dac143e4    	xpaci	x4
1000ba680: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba684: aa1303e0    	mov	x0, x19
1000ba688: aa1403e1    	mov	x1, x20
1000ba68c: aa1503e2    	mov	x2, x21
1000ba690: 52800083    	mov	w3, #0x4                ; =4
1000ba694: d63f0100    	blr	x8
1000ba698: 90000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000ba69c: 91282108    	add	x8, x8, #0xa08
1000ba6a0: 14000020    	b	0x1000ba720 <_machine.machine.Group.execute+0x1ce0>
1000ba6a4: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba6a8: f100269f    	cmp	x20, #0x9
1000ba6ac: 54004302    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba6b0: b4000354    	cbz	x20, 0x1000ba718 <_machine.machine.Group.execute+0x1cd8>
1000ba6b4: 911003e8    	add	x8, sp, #0x400
1000ba6b8: 91008115    	add	x21, x8, #0x20
1000ba6bc: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba6c0: 384306a1    	ldrb	w1, [x21], #0x30
1000ba6c4: 910cc3e2    	add	x2, sp, #0x330
1000ba6c8: 97feeab2    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba6cc: f1000694    	subs	x20, x20, #0x1
1000ba6d0: 54ffff61    	b.ne	0x1000ba6bc <_machine.machine.Group.execute+0x1c7c>
1000ba6d4: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba6d8: b4000208    	cbz	x8, 0x1000ba718 <_machine.machine.Group.execute+0x1cd8>
1000ba6dc: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba6e0: 8b080508    	add	x8, x8, x8, lsl #1
1000ba6e4: d37ced15    	lsl	x21, x8, #4
1000ba6e8: aa1403e0    	mov	x0, x20
1000ba6ec: 52801541    	mov	w1, #0xaa               ; =170
1000ba6f0: aa1503e2    	mov	x2, x21
1000ba6f4: 94050f65    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba6f8: f94017e4    	ldr	x4, [sp, #0x28]
1000ba6fc: dac143e4    	xpaci	x4
1000ba700: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba704: aa1303e0    	mov	x0, x19
1000ba708: aa1403e1    	mov	x1, x20
1000ba70c: aa1503e2    	mov	x2, x21
1000ba710: 52800083    	mov	w3, #0x4                ; =4
1000ba714: d63f0100    	blr	x8
1000ba718: 90000ae8    	adrp	x8, 0x100216000 <___anon_78196+0x40>
1000ba71c: 91296108    	add	x8, x8, #0xa58
1000ba720: ad410500    	ldp	q0, q1, [x8, #0x20]
1000ba724: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba728: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba72c: 3dc01100    	ldr	q0, [x8, #0x40]
1000ba730: 3d801120    	str	q0, [x9, #0x40]
1000ba734: ad400101    	ldp	q1, q0, [x8]
1000ba738: ad000121    	stp	q1, q0, [x9]
1000ba73c: 140000f1    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba740: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba744: f100269f    	cmp	x20, #0x9
1000ba748: 54003e22    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba74c: b4001db4    	cbz	x20, 0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000ba750: 911003e8    	add	x8, sp, #0x400
1000ba754: 91008115    	add	x21, x8, #0x20
1000ba758: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba75c: 384306a1    	ldrb	w1, [x21], #0x30
1000ba760: 910603e2    	add	x2, sp, #0x180
1000ba764: 97feea8b    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba768: f1000694    	subs	x20, x20, #0x1
1000ba76c: 54ffff61    	b.ne	0x1000ba758 <_machine.machine.Group.execute+0x1d18>
1000ba770: 17fffdca    	b	0x1000b9e98 <_machine.machine.Group.execute+0x1458>
1000ba774: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba778: f100269f    	cmp	x20, #0x9
1000ba77c: 54003c82    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba780: b4000354    	cbz	x20, 0x1000ba7e8 <_machine.machine.Group.execute+0x1da8>
1000ba784: 911003e8    	add	x8, sp, #0x400
1000ba788: 91008115    	add	x21, x8, #0x20
1000ba78c: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba790: 384306a1    	ldrb	w1, [x21], #0x30
1000ba794: 910a83e2    	add	x2, sp, #0x2a0
1000ba798: 97feea7e    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba79c: f1000694    	subs	x20, x20, #0x1
1000ba7a0: 54ffff61    	b.ne	0x1000ba78c <_machine.machine.Group.execute+0x1d4c>
1000ba7a4: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba7a8: b4000208    	cbz	x8, 0x1000ba7e8 <_machine.machine.Group.execute+0x1da8>
1000ba7ac: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba7b0: 8b080508    	add	x8, x8, x8, lsl #1
1000ba7b4: d37ced15    	lsl	x21, x8, #4
1000ba7b8: aa1403e0    	mov	x0, x20
1000ba7bc: 52801541    	mov	w1, #0xaa               ; =170
1000ba7c0: aa1503e2    	mov	x2, x21
1000ba7c4: 94050f31    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba7c8: f94017e4    	ldr	x4, [sp, #0x28]
1000ba7cc: dac143e4    	xpaci	x4
1000ba7d0: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba7d4: aa1303e0    	mov	x0, x19
1000ba7d8: aa1403e1    	mov	x1, x20
1000ba7dc: aa1503e2    	mov	x2, x21
1000ba7e0: 52800083    	mov	w3, #0x4                ; =4
1000ba7e4: d63f0100    	blr	x8
1000ba7e8: 911a23ea    	add	x10, sp, #0x688
1000ba7ec: ad5e0540    	ldp	q0, q1, [x10, #0x3c0]
1000ba7f0: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba7f4: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba7f8: f94537e8    	ldr	x8, [sp, #0xa68]
1000ba7fc: f9002128    	str	x8, [x9, #0x40]
1000ba800: ad5d0141    	ldp	q1, q0, [x10, #0x3a0]
1000ba804: 140000bd    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000ba808: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba80c: f100269f    	cmp	x20, #0x9
1000ba810: 540037e2    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba814: b4000354    	cbz	x20, 0x1000ba87c <_machine.machine.Group.execute+0x1e3c>
1000ba818: 911003e8    	add	x8, sp, #0x400
1000ba81c: 91008115    	add	x21, x8, #0x20
1000ba820: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba824: 384306a1    	ldrb	w1, [x21], #0x30
1000ba828: 910b83e2    	add	x2, sp, #0x2e0
1000ba82c: 97feea59    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba830: f1000694    	subs	x20, x20, #0x1
1000ba834: 54ffff61    	b.ne	0x1000ba820 <_machine.machine.Group.execute+0x1de0>
1000ba838: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba83c: b4000208    	cbz	x8, 0x1000ba87c <_machine.machine.Group.execute+0x1e3c>
1000ba840: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba844: 8b080508    	add	x8, x8, x8, lsl #1
1000ba848: d37ced15    	lsl	x21, x8, #4
1000ba84c: aa1403e0    	mov	x0, x20
1000ba850: 52801541    	mov	w1, #0xaa               ; =170
1000ba854: aa1503e2    	mov	x2, x21
1000ba858: 94050f0c    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba85c: f94017e4    	ldr	x4, [sp, #0x28]
1000ba860: dac143e4    	xpaci	x4
1000ba864: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba868: aa1303e0    	mov	x0, x19
1000ba86c: aa1403e1    	mov	x1, x20
1000ba870: aa1503e2    	mov	x2, x21
1000ba874: 52800083    	mov	w3, #0x4                ; =4
1000ba878: d63f0100    	blr	x8
1000ba87c: 3dc2bfe0    	ldr	q0, [sp, #0xaf0]
1000ba880: 3dc2c3e1    	ldr	q1, [sp, #0xb00]
1000ba884: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba888: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba88c: f9458be8    	ldr	x8, [sp, #0xb10]
1000ba890: f9002128    	str	x8, [x9, #0x40]
1000ba894: 3dc2bbe0    	ldr	q0, [sp, #0xae0]
1000ba898: 3dc2b7e1    	ldr	q1, [sp, #0xad0]
1000ba89c: 14000097    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000ba8a0: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba8a4: f100269f    	cmp	x20, #0x9
1000ba8a8: 54003322    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba8ac: b4000354    	cbz	x20, 0x1000ba914 <_machine.machine.Group.execute+0x1ed4>
1000ba8b0: 911003e8    	add	x8, sp, #0x400
1000ba8b4: 91008115    	add	x21, x8, #0x20
1000ba8b8: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba8bc: 384306a1    	ldrb	w1, [x21], #0x30
1000ba8c0: 910a03e2    	add	x2, sp, #0x280
1000ba8c4: 97feea33    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba8c8: f1000694    	subs	x20, x20, #0x1
1000ba8cc: 54ffff61    	b.ne	0x1000ba8b8 <_machine.machine.Group.execute+0x1e78>
1000ba8d0: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba8d4: b4000208    	cbz	x8, 0x1000ba914 <_machine.machine.Group.execute+0x1ed4>
1000ba8d8: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba8dc: 8b080508    	add	x8, x8, x8, lsl #1
1000ba8e0: d37ced15    	lsl	x21, x8, #4
1000ba8e4: aa1403e0    	mov	x0, x20
1000ba8e8: 52801541    	mov	w1, #0xaa               ; =170
1000ba8ec: aa1503e2    	mov	x2, x21
1000ba8f0: 94050ee6    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba8f4: f94017e4    	ldr	x4, [sp, #0x28]
1000ba8f8: dac143e4    	xpaci	x4
1000ba8fc: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba900: aa1303e0    	mov	x0, x19
1000ba904: aa1403e1    	mov	x1, x20
1000ba908: aa1503e2    	mov	x2, x21
1000ba90c: 52800083    	mov	w3, #0x4                ; =4
1000ba910: d63f0100    	blr	x8
1000ba914: 3dc27fe0    	ldr	q0, [sp, #0x9f0]
1000ba918: 3dc283e1    	ldr	q1, [sp, #0xa00]
1000ba91c: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba920: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba924: f9450be8    	ldr	x8, [sp, #0xa10]
1000ba928: f9002128    	str	x8, [x9, #0x40]
1000ba92c: 3dc27be0    	ldr	q0, [sp, #0x9e0]
1000ba930: 3dc277e1    	ldr	q1, [sp, #0x9d0]
1000ba934: 14000071    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000ba938: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba93c: f100269f    	cmp	x20, #0x9
1000ba940: 54002e62    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba944: b4000354    	cbz	x20, 0x1000ba9ac <_machine.machine.Group.execute+0x1f6c>
1000ba948: 911003e8    	add	x8, sp, #0x400
1000ba94c: 91008115    	add	x21, x8, #0x20
1000ba950: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba954: 384306a1    	ldrb	w1, [x21], #0x30
1000ba958: 910b03e2    	add	x2, sp, #0x2c0
1000ba95c: 97feea0d    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba960: f1000694    	subs	x20, x20, #0x1
1000ba964: 54ffff61    	b.ne	0x1000ba950 <_machine.machine.Group.execute+0x1f10>
1000ba968: f942c7e8    	ldr	x8, [sp, #0x588]
1000ba96c: b4000208    	cbz	x8, 0x1000ba9ac <_machine.machine.Group.execute+0x1f6c>
1000ba970: f942c3f4    	ldr	x20, [sp, #0x580]
1000ba974: 8b080508    	add	x8, x8, x8, lsl #1
1000ba978: d37ced15    	lsl	x21, x8, #4
1000ba97c: aa1403e0    	mov	x0, x20
1000ba980: 52801541    	mov	w1, #0xaa               ; =170
1000ba984: aa1503e2    	mov	x2, x21
1000ba988: 94050ec0    	bl	0x1001fe488 <_writev+0x1001fe488>
1000ba98c: f94017e4    	ldr	x4, [sp, #0x28]
1000ba990: dac143e4    	xpaci	x4
1000ba994: f9400ec8    	ldr	x8, [x22, #0x18]
1000ba998: aa1303e0    	mov	x0, x19
1000ba99c: aa1403e1    	mov	x1, x20
1000ba9a0: aa1503e2    	mov	x2, x21
1000ba9a4: 52800083    	mov	w3, #0x4                ; =4
1000ba9a8: d63f0100    	blr	x8
1000ba9ac: 3dc2abe0    	ldr	q0, [sp, #0xaa0]
1000ba9b0: 3dc2afe1    	ldr	q1, [sp, #0xab0]
1000ba9b4: f9400fe9    	ldr	x9, [sp, #0x18]
1000ba9b8: ad010520    	stp	q0, q1, [x9, #0x20]
1000ba9bc: f94563e8    	ldr	x8, [sp, #0xac0]
1000ba9c0: f9002128    	str	x8, [x9, #0x40]
1000ba9c4: 3dc2a7e0    	ldr	q0, [sp, #0xa90]
1000ba9c8: 3dc2a3e1    	ldr	q1, [sp, #0xa80]
1000ba9cc: 1400004b    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000ba9d0: f942cbf4    	ldr	x20, [sp, #0x590]
1000ba9d4: f100269f    	cmp	x20, #0x9
1000ba9d8: 540029a2    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000ba9dc: b4000354    	cbz	x20, 0x1000baa44 <_machine.machine.Group.execute+0x2004>
1000ba9e0: 911003e8    	add	x8, sp, #0x400
1000ba9e4: 91008115    	add	x21, x8, #0x20
1000ba9e8: f85e02a0    	ldur	x0, [x21, #-0x20]
1000ba9ec: 384306a1    	ldrb	w1, [x21], #0x30
1000ba9f0: 910c43e2    	add	x2, sp, #0x310
1000ba9f4: 97fee9e7    	bl	0x100075190 <_machine.machine.Slot.release>
1000ba9f8: f1000694    	subs	x20, x20, #0x1
1000ba9fc: 54ffff61    	b.ne	0x1000ba9e8 <_machine.machine.Group.execute+0x1fa8>
1000baa00: f942c7e8    	ldr	x8, [sp, #0x588]
1000baa04: b4000208    	cbz	x8, 0x1000baa44 <_machine.machine.Group.execute+0x2004>
1000baa08: f942c3f4    	ldr	x20, [sp, #0x580]
1000baa0c: 8b080508    	add	x8, x8, x8, lsl #1
1000baa10: d37ced15    	lsl	x21, x8, #4
1000baa14: aa1403e0    	mov	x0, x20
1000baa18: 52801541    	mov	w1, #0xaa               ; =170
1000baa1c: aa1503e2    	mov	x2, x21
1000baa20: 94050e9a    	bl	0x1001fe488 <_writev+0x1001fe488>
1000baa24: f94017e4    	ldr	x4, [sp, #0x28]
1000baa28: dac143e4    	xpaci	x4
1000baa2c: f9400ec8    	ldr	x8, [x22, #0x18]
1000baa30: aa1303e0    	mov	x0, x19
1000baa34: aa1403e1    	mov	x1, x20
1000baa38: aa1503e2    	mov	x2, x21
1000baa3c: 52800083    	mov	w3, #0x4                ; =4
1000baa40: d63f0100    	blr	x8
1000baa44: 3dc2dfe0    	ldr	q0, [sp, #0xb70]
1000baa48: 3dc2e3e1    	ldr	q1, [sp, #0xb80]
1000baa4c: f9400fe9    	ldr	x9, [sp, #0x18]
1000baa50: ad010520    	stp	q0, q1, [x9, #0x20]
1000baa54: f945cbe8    	ldr	x8, [sp, #0xb90]
1000baa58: f9002128    	str	x8, [x9, #0x40]
1000baa5c: 3dc2dbe0    	ldr	q0, [sp, #0xb60]
1000baa60: 3dc2d7e1    	ldr	q1, [sp, #0xb50]
1000baa64: 14000025    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000baa68: f942cbf4    	ldr	x20, [sp, #0x590]
1000baa6c: f100269f    	cmp	x20, #0x9
1000baa70: 540024e2    	b.hs	0x1000baf0c <_machine.machine.Group.execute+0x24cc>
1000baa74: b4000354    	cbz	x20, 0x1000baadc <_machine.machine.Group.execute+0x209c>
1000baa78: 911003e8    	add	x8, sp, #0x400
1000baa7c: 91008115    	add	x21, x8, #0x20
1000baa80: f85e02a0    	ldur	x0, [x21, #-0x20]
1000baa84: 384306a1    	ldrb	w1, [x21], #0x30
1000baa88: 9105c3e2    	add	x2, sp, #0x170
1000baa8c: 97fee9c1    	bl	0x100075190 <_machine.machine.Slot.release>
1000baa90: f1000694    	subs	x20, x20, #0x1
1000baa94: 54ffff61    	b.ne	0x1000baa80 <_machine.machine.Group.execute+0x2040>
1000baa98: f942c7e8    	ldr	x8, [sp, #0x588]
1000baa9c: b4000208    	cbz	x8, 0x1000baadc <_machine.machine.Group.execute+0x209c>
1000baaa0: f942c3f4    	ldr	x20, [sp, #0x580]
1000baaa4: 8b080508    	add	x8, x8, x8, lsl #1
1000baaa8: d37ced15    	lsl	x21, x8, #4
1000baaac: aa1403e0    	mov	x0, x20
1000baab0: 52801541    	mov	w1, #0xaa               ; =170
1000baab4: aa1503e2    	mov	x2, x21
1000baab8: 94050e74    	bl	0x1001fe488 <_writev+0x1001fe488>
1000baabc: f94017e4    	ldr	x4, [sp, #0x28]
1000baac0: dac143e4    	xpaci	x4
1000baac4: f9400ec8    	ldr	x8, [x22, #0x18]
1000baac8: aa1303e0    	mov	x0, x19
1000baacc: aa1403e1    	mov	x1, x20
1000baad0: aa1503e2    	mov	x2, x21
1000baad4: 52800083    	mov	w3, #0x4                ; =4
1000baad8: d63f0100    	blr	x8
1000baadc: 911a23ea    	add	x10, sp, #0x688
1000baae0: ad540540    	ldp	q0, q1, [x10, #0x280]
1000baae4: f9400fe9    	ldr	x9, [sp, #0x18]
1000baae8: ad010520    	stp	q0, q1, [x9, #0x20]
1000baaec: f94497e8    	ldr	x8, [sp, #0x928]
1000baaf0: f9002128    	str	x8, [x9, #0x40]
1000baaf4: ad530141    	ldp	q1, q0, [x10, #0x260]
1000baaf8: ad000121    	stp	q1, q0, [x9]
1000baafc: 7900913f    	strh	wzr, [x9, #0x48]
1000bab00: f85983a8    	ldur	x8, [x29, #-0x68]
1000bab04: 90000f89    	adrp	x9, 0x1002aa000 <___anon_158753+0x70>
1000bab08: f9409529    	ldr	x9, [x9, #0x128]
1000bab0c: f9400129    	ldr	x9, [x9]
1000bab10: eb08013f    	cmp	x9, x8
1000bab14: 54002081    	b.ne	0x1000baf24 <_machine.machine.Group.execute+0x24e4>
1000bab18: 913443ff    	add	sp, sp, #0xd10
1000bab1c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1000bab20: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1000bab24: a94357f6    	ldp	x22, x21, [sp, #0x30]
1000bab28: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1000bab2c: a94167fa    	ldp	x26, x25, [sp, #0x10]
1000bab30: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1000bab34: d65f03c0    	ret
1000bab38: 7102929f    	cmp	w20, #0xa4
1000bab3c: 540003e0    	b.eq	0x1000babb8 <_machine.machine.Group.execute+0x2178>
1000bab40: 7102969f    	cmp	w20, #0xa5
1000bab44: 54000b01    	b.ne	0x1000baca4 <_machine.machine.Group.execute+0x2264>
1000bab48: b9405fe8    	ldr	w8, [sp, #0x5c]
1000bab4c: 36000268    	tbz	w8, #0x0, 0x1000bab98 <_machine.machine.Group.execute+0x2158>
1000bab50: 9103c3e0    	add	x0, sp, #0xf0
1000bab54: 911883e2    	add	x2, sp, #0x620
1000bab58: aa1303e1    	mov	x1, x19
1000bab5c: 940128f5    	bl	0x100104f30 <_machine.costs.chargeInstruction>
1000bab60: f9407be8    	ldr	x8, [sp, #0xf0]
1000bab64: f940fec9    	ldr	x9, [x22, #0x1f8]
1000bab68: ab090108    	adds	x8, x8, x9
1000bab6c: 54001b62    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000bab70: f9405ac9    	ldr	x9, [x22, #0xb0]
1000bab74: ab080128    	adds	x8, x9, x8
1000bab78: 54001b02    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000bab7c: f9407fe9    	ldr	x9, [sp, #0xf8]
1000bab80: f9005ac8    	str	x8, [x22, #0xb0]
1000bab84: f9405ec8    	ldr	x8, [x22, #0xb8]
1000bab88: ab090108    	adds	x8, x8, x9
1000bab8c: 54001a62    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000bab90: f9005ec8    	str	x8, [x22, #0xb8]
1000bab94: f900fedf    	str	xzr, [x22, #0x1f8]
1000bab98: 911883e0    	add	x0, sp, #0x620
1000bab9c: 940025e3    	bl	0x1000c4328 <_machine.costs.Measures.release>
1000baba0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baba4: 3d8043e0    	str	q0, [sp, #0x100]
1000baba8: 911003e0    	add	x0, sp, #0x400
1000babac: 910403e1    	add	x1, sp, #0x100
1000babb0: 94002584    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000babb4: 17fffd3e    	b	0x1000ba0ac <_machine.machine.Group.execute+0x166c>
1000babb8: b9405fe8    	ldr	w8, [sp, #0x5c]
1000babbc: 36000268    	tbz	w8, #0x0, 0x1000bac08 <_machine.machine.Group.execute+0x21c8>
1000babc0: 910343e0    	add	x0, sp, #0xd0
1000babc4: 911883e2    	add	x2, sp, #0x620
1000babc8: aa1303e1    	mov	x1, x19
1000babcc: 940128d9    	bl	0x100104f30 <_machine.costs.chargeInstruction>
1000babd0: f9406be8    	ldr	x8, [sp, #0xd0]
1000babd4: f940fec9    	ldr	x9, [x22, #0x1f8]
1000babd8: ab090108    	adds	x8, x8, x9
1000babdc: 540017e2    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000babe0: f9405ac9    	ldr	x9, [x22, #0xb0]
1000babe4: ab080128    	adds	x8, x9, x8
1000babe8: 54001782    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000babec: f9406fe9    	ldr	x9, [sp, #0xd8]
1000babf0: f9005ac8    	str	x8, [x22, #0xb0]
1000babf4: f9405ec8    	ldr	x8, [x22, #0xb8]
1000babf8: ab090108    	adds	x8, x8, x9
1000babfc: 540016e2    	b.hs	0x1000baed8 <_machine.machine.Group.execute+0x2498>
1000bac00: f9005ec8    	str	x8, [x22, #0xb8]
1000bac04: f900fedf    	str	xzr, [x22, #0x1f8]
1000bac08: 911883e0    	add	x0, sp, #0x620
1000bac0c: 940025c7    	bl	0x1000c4328 <_machine.costs.Measures.release>
1000bac10: 3946a2c8    	ldrb	w8, [x22, #0x1a8]
1000bac14: 36001728    	tbz	w8, #0x0, 0x1000baef8 <_machine.machine.Group.execute+0x24b8>
1000bac18: 394682c8    	ldrb	w8, [x22, #0x1a0]
1000bac1c: 7100051f    	cmp	w8, #0x1
1000bac20: 54000f8c    	b.gt	0x1000bae10 <_machine.machine.Group.execute+0x23d0>
1000bac24: 35001008    	cbnz	w8, 0x1000bae24 <_machine.machine.Group.execute+0x23e4>
1000bac28: 90000af3    	adrp	x19, 0x100216000 <___anon_78196+0x40>
1000bac2c: 91230273    	add	x19, x19, #0x8c0
1000bac30: 14000084    	b	0x1000bae40 <_machine.machine.Group.execute+0x2400>
1000bac34: 911883e0    	add	x0, sp, #0x620
1000bac38: 940025bc    	bl	0x1000c4328 <_machine.costs.Measures.release>
1000bac3c: 3954eea8    	ldrb	w8, [x21, #0x53b]
1000bac40: 360015c8    	tbz	w8, #0x0, 0x1000baef8 <_machine.machine.Group.execute+0x24b8>
1000bac44: 3954eaa3    	ldrb	w3, [x21, #0x53a]
1000bac48: 790a76bf    	strh	wzr, [x21, #0x53a]
1000bac4c: a9449fe8    	ldp	x8, x7, [sp, #0x48]
1000bac50: b90003e8    	str	w8, [sp]
1000bac54: 911fa3e0    	add	x0, sp, #0x7e8
1000bac58: aa1503e1    	mov	x1, x21
1000bac5c: aa1603e2    	mov	x2, x22
1000bac60: f9401fe4    	ldr	x4, [sp, #0x38]
1000bac64: aa1c03e5    	mov	x5, x28
1000bac68: aa1b03e6    	mov	x6, x27
1000bac6c: 940022df    	bl	0x1000c37e8 <_machine.machine.Group.limitFault>
1000bac70: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bac74: 3d8047e0    	str	q0, [sp, #0x110]
1000bac78: 911003e0    	add	x0, sp, #0x400
1000bac7c: 910443e1    	add	x1, sp, #0x110
1000bac80: 94002550    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000bac84: 911a23ea    	add	x10, sp, #0x688
1000bac88: ad4c0540    	ldp	q0, q1, [x10, #0x180]
1000bac8c: f9400fe9    	ldr	x9, [sp, #0x18]
1000bac90: ad010520    	stp	q0, q1, [x9, #0x20]
1000bac94: f94417e8    	ldr	x8, [sp, #0x828]
1000bac98: f9002128    	str	x8, [x9, #0x40]
1000bac9c: ad4b0141    	ldp	q1, q0, [x10, #0x160]
1000baca0: 17ffff96    	b	0x1000baaf8 <_machine.machine.Group.execute+0x20b8>
1000baca4: 911883e0    	add	x0, sp, #0x620
1000baca8: 940025a0    	bl	0x1000c4328 <_machine.costs.Measures.release>
1000bacac: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bacb0: 3d804be0    	str	q0, [sp, #0x120]
1000bacb4: 911003e0    	add	x0, sp, #0x400
1000bacb8: 910483e1    	add	x1, sp, #0x120
1000bacbc: 94002541    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000bacc0: f9400fe8    	ldr	x8, [sp, #0x18]
1000bacc4: 79009114    	strh	w20, [x8, #0x48]
1000bacc8: 17ffff8e    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000baccc: f9400fe8    	ldr	x8, [sp, #0x18]
1000bacd0: 79009100    	strh	w0, [x8, #0x48]
1000bacd4: 17ffff8b    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000bacd8: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bacdc: 3d80b7e0    	str	q0, [sp, #0x2d0]
1000bace0: 911003e0    	add	x0, sp, #0x400
1000bace4: 910b43e1    	add	x1, sp, #0x2d0
1000bace8: 1400000b    	b	0x1000bad14 <_machine.machine.Group.execute+0x22d4>
1000bacec: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bacf0: 3d80a7e0    	str	q0, [sp, #0x290]
1000bacf4: 911003e0    	add	x0, sp, #0x400
1000bacf8: 910a43e1    	add	x1, sp, #0x290
1000bacfc: 14000006    	b	0x1000bad14 <_machine.machine.Group.execute+0x22d4>
1000bad00: f9013abf    	str	xzr, [x21, #0x270]
1000bad04: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad08: 3d809fe0    	str	q0, [sp, #0x270]
1000bad0c: 911003e0    	add	x0, sp, #0x400
1000bad10: 9109c3e1    	add	x1, sp, #0x270
1000bad14: 9400252b    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000bad18: f9400fe8    	ldr	x8, [sp, #0x18]
1000bad1c: 79009113    	strh	w19, [x8, #0x48]
1000bad20: 17ffff78    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000bad24: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad28: 3d80f7e0    	str	q0, [sp, #0x3d0]
1000bad2c: 910e03e0    	add	x0, sp, #0x380
1000bad30: 910f43e1    	add	x1, sp, #0x3d0
1000bad34: 1400000e    	b	0x1000bad6c <_machine.machine.Group.execute+0x232c>
1000bad38: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad3c: 3d80ebe0    	str	q0, [sp, #0x3a0]
1000bad40: 912e83e0    	add	x0, sp, #0xba0
1000bad44: 910e83e1    	add	x1, sp, #0x3a0
1000bad48: 97feebab    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bad4c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad50: 3d80efe0    	str	q0, [sp, #0x3b0]
1000bad54: 910ec3e2    	add	x2, sp, #0x3b0
1000bad58: 14000018    	b	0x1000badb8 <_machine.machine.Group.execute+0x2378>
1000bad5c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad60: 3d80fbe0    	str	q0, [sp, #0x3e0]
1000bad64: 910e03e0    	add	x0, sp, #0x380
1000bad68: 910f83e1    	add	x1, sp, #0x3e0
1000bad6c: 97feeba2    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bad70: 17fffd28    	b	0x1000ba210 <_machine.machine.Group.execute+0x17d0>
1000bad74: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad78: 3d80f7e0    	str	q0, [sp, #0x3d0]
1000bad7c: 912e83e0    	add	x0, sp, #0xba0
1000bad80: 910f43e1    	add	x1, sp, #0x3d0
1000bad84: 97feeb9c    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000bad88: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad8c: 3d80fbe0    	str	q0, [sp, #0x3e0]
1000bad90: 910f83e2    	add	x2, sp, #0x3e0
1000bad94: 14000009    	b	0x1000badb8 <_machine.machine.Group.execute+0x2378>
1000bad98: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bad9c: 3d80dbe0    	str	q0, [sp, #0x360]
1000bada0: 912e83e0    	add	x0, sp, #0xba0
1000bada4: 910d83e1    	add	x1, sp, #0x360
1000bada8: 97feeb93    	bl	0x100075bf4 <_array_list.Aligned(machine.machine.Cleanup,null).deinit>
1000badac: 3cc482a0    	ldur	q0, [x21, #0x48]
1000badb0: 3d80e3e0    	str	q0, [sp, #0x380]
1000badb4: 910e03e2    	add	x2, sp, #0x380
1000badb8: aa1303e0    	mov	x0, x19
1000badbc: aa1403e1    	mov	x1, x20
1000badc0: 97fee4d4    	bl	0x100074110 <_machine.machine.releaseAll>
1000badc4: 17fffd40    	b	0x1000ba2c4 <_machine.machine.Group.execute+0x1884>
1000badc8: aa1303e0    	mov	x0, x19
1000badcc: 97fe9b06    	bl	0x1000619e4 <_value.Value.release>
1000badd0: 3cc482a0    	ldur	q0, [x21, #0x48]
1000badd4: 3d8067e0    	str	q0, [sp, #0x190]
1000badd8: 911003e0    	add	x0, sp, #0x400
1000baddc: 910643e1    	add	x1, sp, #0x190
1000bade0: 17fffd10    	b	0x1000ba220 <_machine.machine.Group.execute+0x17e0>
1000bade4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bade8: 3d8073e0    	str	q0, [sp, #0x1c0]
1000badec: 910703e2    	add	x2, sp, #0x1c0
1000badf0: aa1803e0    	mov	x0, x24
1000badf4: aa1403e1    	mov	x1, x20
1000badf8: 97fee4c6    	bl	0x100074110 <_machine.machine.releaseAll>
1000badfc: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae00: 3d8077e0    	str	q0, [sp, #0x1d0]
1000bae04: 911003e0    	add	x0, sp, #0x400
1000bae08: 910743e1    	add	x1, sp, #0x1d0
1000bae0c: 17fffd05    	b	0x1000ba220 <_machine.machine.Group.execute+0x17e0>
1000bae10: 7100091f    	cmp	w8, #0x2
1000bae14: 54000861    	b.ne	0x1000baf20 <_machine.machine.Group.execute+0x24e0>
1000bae18: 90000af3    	adrp	x19, 0x100216000 <___anon_78196+0x40>
1000bae1c: 91244273    	add	x19, x19, #0x910
1000bae20: 14000008    	b	0x1000bae40 <_machine.machine.Group.execute+0x2400>
1000bae24: 6f00e400    	movi.2d	v0, #0000000000000000
1000bae28: ad0c82c0    	stp	q0, q0, [x22, #0x190]
1000bae2c: 911e63f3    	add	x19, sp, #0x798
1000bae30: 911e63e0    	add	x0, sp, #0x798
1000bae34: aa1503e1    	mov	x1, x21
1000bae38: aa1603e2    	mov	x2, x22
1000bae3c: 94012fd7    	bl	0x100106d98 <_machine.machine.Group.landedCancel>
1000bae40: f9400ff4    	ldr	x20, [sp, #0x18]
1000bae44: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae48: 3d803be0    	str	q0, [sp, #0xe0]
1000bae4c: 911003e0    	add	x0, sp, #0x400
1000bae50: 910383e1    	add	x1, sp, #0xe0
1000bae54: 940024db    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000bae58: ad410660    	ldp	q0, q1, [x19, #0x20]
1000bae5c: ad010680    	stp	q0, q1, [x20, #0x20]
1000bae60: 3dc01260    	ldr	q0, [x19, #0x40]
1000bae64: 3d801280    	str	q0, [x20, #0x40]
1000bae68: ad400261    	ldp	q1, q0, [x19]
1000bae6c: ad000281    	stp	q1, q0, [x20]
1000bae70: 17ffff24    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000bae74: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae78: 3d8087e0    	str	q0, [sp, #0x210]
1000bae7c: 910843e2    	add	x2, sp, #0x210
1000bae80: aa1803e0    	mov	x0, x24
1000bae84: aa1403e1    	mov	x1, x20
1000bae88: 97fee4a2    	bl	0x100074110 <_machine.machine.releaseAll>
1000bae8c: 3cc482a0    	ldur	q0, [x21, #0x48]
1000bae90: 3d808be0    	str	q0, [sp, #0x220]
1000bae94: 911003e0    	add	x0, sp, #0x400
1000bae98: 910883e1    	add	x1, sp, #0x220
1000bae9c: 940024c9    	bl	0x1000c41c0 <_machine.machine.Operands.release>
1000baea0: f9400fe8    	ldr	x8, [sp, #0x18]
1000baea4: 7900911a    	strh	w26, [x8, #0x48]
1000baea8: 17ffff16    	b	0x1000bab00 <_machine.machine.Group.execute+0x20c0>
1000baeac: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baeb0: 3d808fe0    	str	q0, [sp, #0x230]
1000baeb4: 9108c3e2    	add	x2, sp, #0x230
1000baeb8: aa1803e0    	mov	x0, x24
1000baebc: aa1403e1    	mov	x1, x20
1000baec0: 97fee494    	bl	0x100074110 <_machine.machine.releaseAll>
1000baec4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baec8: 3d8093e0    	str	q0, [sp, #0x240]
1000baecc: 911003e0    	add	x0, sp, #0x400
1000baed0: 910903e1    	add	x1, sp, #0x240
1000baed4: 17fffcd3    	b	0x1000ba220 <_machine.machine.Group.execute+0x17e0>
1000baed8: 9404e8f4    	bl	0x1001f52a8 <_debug.FullPanic((function 'defaultPanic')).integerOverflow>
1000baedc: 911883e0    	add	x0, sp, #0x620
1000baee0: 94002512    	bl	0x1000c4328 <_machine.costs.Measures.release>
1000baee4: 3cc482a0    	ldur	q0, [x21, #0x48]
1000baee8: 3d8033e0    	str	q0, [sp, #0xc0]
1000baeec: 911003e0    	add	x0, sp, #0x400
1000baef0: 910303e1    	add	x1, sp, #0xc0
1000baef4: 17ffff72    	b	0x1000bacbc <_machine.machine.Group.execute+0x227c>
1000baef8: 9404d18a    	bl	0x1001ef520 <_debug.FullPanic((function 'defaultPanic')).unwrapNull>
1000baefc: 9404e8f7    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf00: aa1b03e0    	mov	x0, x27
1000baf04: 9404e8f5    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf08: 9404d13e    	bl	0x1001ef400 <_debug.FullPanic((function 'defaultPanic')).reachedUnreachable>
1000baf0c: aa1403e0    	mov	x0, x20
1000baf10: 52800101    	mov	w1, #0x8                ; =8
1000baf14: 9404e8f1    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf18: aa0203e0    	mov	x0, x2
1000baf1c: 9404e8ef    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf20: 9404d168    	bl	0x1001ef4c0 <_debug.FullPanic((function 'defaultPanic')).corruptSwitch>
1000baf24: 94050cae    	bl	0x1001fe1dc <_writev+0x1001fe1dc>
1000baf28: aa1303e0    	mov	x0, x19
1000baf2c: 9404e8eb    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf30: 52800020    	mov	w0, #0x1                ; =1
1000baf34: 52800001    	mov	w1, #0x0                ; =0
1000baf38: 9404f070    	bl	0x1001f70f8 <_debug.FullPanic((function 'defaultPanic')).inactiveUnionField__func_1432>
1000baf3c: aa1303e0    	mov	x0, x19
1000baf40: 52801221    	mov	w1, #0x91               ; =145
1000baf44: 9404e8e5    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf48: 91000680    	add	x0, x20, #0x1
1000baf4c: 9404e8e3    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf50: 9404d267    	bl	0x1001ef8ec <_debug.FullPanic((function 'defaultPanic')).incorrectAlignment>
1000baf54: aa1703e0    	mov	x0, x23
1000baf58: 9404e8e0    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf5c: aa0103e0    	mov	x0, x1
1000baf60: 52800101    	mov	w1, #0x8                ; =8
1000baf64: 9404e8dd    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>
1000baf68: 9404d013    	bl	0x1001eefb4 <_debug.FullPanic((function 'defaultPanic')).forLenMismatch>
1000baf6c: 9404e8e6    	bl	0x1001f5304 <_debug.FullPanic((function 'defaultPanic')).startGreaterThanEnd>
1000baf70: aa1703e0    	mov	x0, x23
1000baf74: 52800101    	mov	w1, #0x8                ; =8
1000baf78: 9404e8d8    	bl	0x1001f52d8 <_debug.FullPanic((function 'defaultPanic')).outOfBounds>

